# demo-in-a-box

**IMPORTANT NOTE: This is a work in progress. If you run anything be aware this has not been tested and may delete files you don't want to delete.**

## Deployment Options

* Multipass
* App AMI (or AMI + provided user script)

## How it works (proposed)

* Setup "clone" scripts from the relevant repositories
  * That way we have history for the demos preserved here, but further development can be done in the separate repos
  * Exceptions
    * Any github private (to subset of users) repos that don't need to be changed
    * Places where we only need a subset of the rep and/or it's unlikely to change
      * **cicd**: Subset of field-demos, unlikely to change (copied from AutoRem-Pi)
      * **BackEnd Demo**: Single jar, unlikely to change
* Multipass stand-alone on MAC
  * install git, terraform, multipasst
  * clone the repo
  * go to ```demo-in-a-box/multipass/terraform_multipass```
  * do
    * ```terraform init```
    * ```terraform apply```
  * creates the box from scratch; ***some downloads will be made***; after about 2 minutes you have the demo-in-a-box in multipass running.
  * access on HTTP port 8081 of the multipass demo-in-a-box IP
  * shut everything down with ```terraform destroy```

## Demos

* Back-end Demo
  * Requirements: Docker, OTel Collector, Direct to back-end
  * Source: JAR file
  * Cloud Run function (convert to simple Python flask server)
* Front-end Demo
  * Source: Hipster Shop
    * Need to confirm actual branches
      * Main: [https://github.com/signalfx/microservices-demo/tree/pmrum-shop](https://github.com/signalfx/microservices-demo/tree/pmrum-shop)
      * RUM is using pieter's update on harnit's container for the custom metrics
      * Profiling:  pieter's add-profiling
        Updates on adservice are running Pieters container
      * RUM loadgen: build the rumloadgen container as provided in the frontend/containers/rumloadgen and deploy in repository
       (can provide a custom ip for the frontend by setting the IP in the env variable RUM_FRONTEND_IP in the deployment for rumloadgen)
      * TODO: Need to add database visibility
  * Requirement: K3s, OTel Collector
* CICD
  * Dockerfile available
    * needs a redis server; could be a second container
    * enviroment variables for realm and token have to be set; see [CICD Readme](cicd/Readme.md)
  * Docker Compose yml available
    * brings everything; incl. a redis container
    * enviroment variables for realm and token have to be set; see [CICD Readme](cicd/Readme.md)
  * K8s yaml -- IN THE WORKS
* IMM Datagen
  * Source: [https://github.com/signalfx/o11y-datagen](https://github.com/signalfx/o11y-datagen)
  * Requirement: Docker, Direct to back-end
  * Provide a few configs
  * Instructions to customize

## Other dependencies

* OTel Collector
* K3s
* docker

## Questions

* Can we send loadgen for "single-span rum traces" to improve tag spotlight?

## Parking Lot

* CICD Original Source, for reference
  * Source: Autorem-sender
    * [https://github.com/harnitsignalfx/autorem-sender](https://github.com/harnitsignalfx/autorem-sender)
  * Source: Autorem-listener
    * [https://github.com/harnitsignalfx/autorem-sender](https://github.com/harnitsignalfx/autorem-listener)
  * Cloud Run function (convert to simple Python flask server)

## Meeting minutes

* [https://docs.google.com/document/d/1xcHCYk0jSi9NdRyBJidZzVlxpaplodSz_squNuz6HW0/edit#](https://docs.google.com/document/d/1xcHCYk0jSi9NdRyBJidZzVlxpaplodSz_squNuz6HW0/edit#)
