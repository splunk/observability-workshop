#!/bin/bash -x
cd /home/splunk/demo-in-a-box/manager
python3 -m venv venv
echo $PWD
activate () {
    . $PWD/venv/bin/activate
}
activate
pip3 install -r requirements.txt --upgrade
nohup flask --app manager-api run -p 8082 --host=0.0.0.0
