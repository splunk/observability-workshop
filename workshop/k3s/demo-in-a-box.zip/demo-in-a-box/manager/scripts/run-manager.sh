#!/bin/bash -x
cd /home/splunk/demo-in-a-box/manager
echo $PWD
activate () {
    . $PWD/venv/bin/activate
}
activate
nohup streamlit run app.py --server.port=8083
