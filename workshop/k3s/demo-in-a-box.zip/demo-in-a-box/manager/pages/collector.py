from calendar import c
import time

import streamlit as st  # type: ignore
from lib import splunk as demo  # type: ignore

if "helm_repo_updated" not in st.session_state:
    st.session_state.helm_repo_updated = False

demo.page_header("Manage OpenTelemetry Collector")

dm = demo.DemoManager()

current = dm.current_demo()

if "current_demo_is_none" not in st.session_state:
    st.session_state.current_demo_is_none = False

st.session_state.current_demo_is_none = True if current["name"] == "None" else False

menu = st.popover("🧭 Menu")

menu.page_link(
  "manager-ui.py", 
  label="Demonstration Use Cases", 
  icon="💼", 
  use_container_width=True
)

menu.page_link(
    "pages/collector.py",
    label="Manage OpenTelemetry Collector",
    icon="🔭",
    use_container_width=True
)

if "collector_running" not in st.session_state:
    dm.check_status(status="status.phase=Running")

if "disable_form" not in st.session_state:
    st.session_state["disable_form"] = True


def enable_form():
    st.session_state["disable_form"] = False


def click_button():
    if not st.session_state.collector_running:
        status_updates.empty()
        with status_updates.status(
            "Starting the collector...", expanded=False
        ) as status:
            status.write("Running `helm install` command...")
            st.code(dm.start_collector()[0], language="text")
            time.sleep(5)
            dm.check_status()
            status.update(label="Collector started", state="complete")

    elif st.session_state.collector_running:
        status_updates.empty()
        with status_updates.status(
            "Stopping the collector...", expanded=False
        ) as status:
            status.write("Running `helm delete` command...")
            status.code(dm.stop_collector()[0], language="text")
            time.sleep(5)
            dm.check_status()
            status.update(label="Collector stopped", state="complete")


col1, col2 = st.columns([1, 3])

with col1:
    st.subheader("Configuration", anchor=False)

    values = dm.get_collector_config()
    # if values is None:
    #    instance = os.environ.get("INSTANCE")
    #    values = ["", "", "", "", "", instance]

    with st.form("config_form"):
        st.session_state["valid_inputs_received"] = False
        realm = st.text_input(
            ":blue[Splunk Observability Cloud Realm]",
            value=values[1],
            disabled=st.session_state["disable_form"],
        )
        ingest_token = st.text_input(
            ":blue[Splunk Observability Cloud Ingest Token]",
            type="password",
            value=values[2],
            disabled=st.session_state["disable_form"],
        )
        rum_token = st.text_input(
            ":blue[Splunk Observability Cloud RUM Token]",
            type="password",
            value=values[3],
            disabled=st.session_state["disable_form"],
        )
        hec_url = st.text_input(
            ":blue[Splunk Cloud HEC URL]",
            value=values[4],
            placeholder="Splunk HEC URL",
            disabled=st.session_state["disable_form"],
        )
        hec_token = st.text_input(
            ":blue[Splunk Cloud HEC Token]",
            type="password",
            value=values[5],
            placeholder="Splunk HEC Token",
            disabled=st.session_state["disable_form"],
        )
        splunk_index = st.text_input(
            ":blue[Splunk Cloud Index]",
            value=values[6],
            placeholder="Splunk Index",
            disabled=st.session_state["disable_form"],
        )
        instance = st.text_input(
            ":blue[Instance Name]",
            value=values[7],
            disabled=True,
        )

        if st.session_state["disable_form"] is True:
            update_form = st.form_submit_button("Update", on_click=enable_form, disabled=st.session_state.collector_running)

        if st.session_state["disable_form"] is False:
            save_config = st.form_submit_button(label="Save", type="primary")

            if save_config:
                if (
                    realm == "" or realm is None
                    or ingest_token == "" or ingest_token is None
                    or rum_token == "" or rum_token is None
                    or instance == "" or instance is None
                ):
                    st.error("All fields are required.")
                    st.stop()
                else:
                    st.session_state["valid_inputs_received"] = True

                st.session_state["disable_form"] = True

                sql_result = dm.save_collector_config(
                    realm,
                    ingest_token,
                    rum_token,
                    hec_url,
                    hec_token,
                    splunk_index,
                    instance
                )
                
                st.toast(sql_result[0])
                time.sleep(2)
                st.rerun()

with col2:
    st.subheader("Status", anchor=False)

    # height = 180 if st.session_state.collector_running else 0

    with st.container(border=True):
        toggle_text = "Start" if not st.session_state.collector_running else "Stop"
        toggle_color = "green" if not st.session_state.collector_running else "red"
        st.toggle(
            f":{toggle_color}[**{toggle_text}**] the Collector",
            on_change=click_button,
            value=st.session_state.collector_running, disabled=st.session_state.current_demo_is_none
        )
        status = dm.check_status()

        if not status.empty:
            st.dataframe(status, use_container_width=True, hide_index=True)

    if st.session_state.collector_running:
        with st.container(border=True, height=455):
            logs, code = dm.get_agent_logs()

            if code == 0:
                st.code(logs, language="log")
            else:
                st.error(logs)


status_updates = st.container(border=True)
status_updates.write("**Status**")

if st.session_state.helm_repo_updated is False:
    status = st.toast("Updating Helm repository...")
    result, retuncode = dm.update_helm_repo()
    if retuncode == 0:
        st.session_state.helm_repo_updated = True
        status.toast("Helm repository updated successfully!")
    else:
        st.toast(result)

if st.secrets.debug:
    with st.container(border=True):
        st.json(st.session_state)
