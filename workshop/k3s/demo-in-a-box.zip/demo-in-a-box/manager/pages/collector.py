import os
import time

import streamlit as st  # type: ignore
from lib import splunk as demo  # type: ignore

demo.page_header("Manage OpenTelemetry Collector")

dm = demo.DemoManager()

menu = st.popover("🧭 Menu")

menu.page_link("app.py", label="Home", icon="🏠", use_container_width=True)

if "collector_running" not in st.session_state:
    dm.check_status(status="status.phase=Running")


def click_button():
    if not st.session_state.collector_running:
        with col2.status("Starting the collector...", expanded=True) as status:
            status.write("Running `helm install` command...")
            st.code(dm.start_collector())
            time.sleep(3)
            dm.check_status()
            status.update(label="Collector started", state="complete")
    elif st.session_state.collector_running:
        with col2.status("Stopping the collector...", expanded=True) as status:
            st.write("Running `helm delete` command...")
            st.code(dm.stop_collector())
            time.sleep(2)
            dm.check_status()
            status.update(label="Collector stopped", state="complete")


col1, col2 = st.columns([1, 3])

with col1:
    st.header("Configuration")

    values = dm.get_collector_config()
    if values is None:
        instance = os.environ.get("INSTANCE")
        values = ["", "", "", "", "", instance]
    with st.form("config_form"):
        st.session_state["valid_inputs_received"] = False
        realm = st.text_input("Realm", value=values[1])
        ingest_token = st.text_input("Ingest Token", type="password", value=values[2])
        rum_token = st.text_input("RUM Token", type="password", value=values[3])
        hec_url = st.text_input("HEC URL", value=values[4])
        hec_token = st.text_input("HEC Token", type="password", value=values[5])
        instance = st.text_input("Instance", value=values[6])
        save_config = st.form_submit_button(label="Save", type="primary")

    if save_config:
        dm.save_collector_config(
            realm, ingest_token, rum_token, hec_url, hec_token, instance
        )
        st.session_state["valid_inputs_received"] = True

with col2:
    st.header("Status")
    with st.container(border=True):
        toggle_text = "Start" if not st.session_state.collector_running else "Stop"
        st.toggle(
            f"**{toggle_text}** the Collector",
            on_change=click_button,
            value=st.session_state.collector_running,
        )
        status = dm.check_status()
        if not status.empty:
            st.table(status)
