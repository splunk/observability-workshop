import time

from flask.cli import F
import streamlit as st  # type: ignore
from lib import splunk as demo  # type: ignore


demo.page_header("Demonstration Status")

dm = demo.DemoManager()

current = dm.current_demo()

menu = st.popover("🧭 Menu")

menu.page_link(
  "manager-ui.py", 
  label="Demonstration Use Cases", 
  icon="💼", 
  use_container_width=True
)

menu.page_link(
    "pages/collector.py",
    label="Manage OpenTelemetry Collector",
    icon="🔭",
    use_container_width=True
)

menu.page_link(
    "pages/status.py",
    label="Demonstration Status",
    icon="🔭",
    use_container_width=True
)

if "collector_running" not in st.session_state:
    dm.check_status(status="status.phase=Running")

def show_logs(pod_name):
    rhs.empty()
    with rhs.caption(f"Fetching logs for {pod_name}..."):
        logs, code = dm.get_pod_logs(pod_name)
        if code == 0:
            rhs.code(logs, language="log")
        else:
            rhs.error(logs)
        #st.success(f"Logs fetched for {pod_name}")

col1, col2 = st.columns([2, 3])

with col1:
    st.subheader("Pod Status", anchor=False)
    with st.container(border=True, height=700):
        demo_dict = dm.demo_status()
        for x, y in demo_dict.items():
            with st.container(border=False):
                status_col1, status_col2, status_col3 = st.columns([4, 1, 1])
                status_col1.write(f"{x}")
                status_col2.write(f"{y}")
                status_col3.button("Logs", key=f"{x}", on_click=show_logs, args=(x,))
                st.html("<style> .my_divider { margin: 0.2em 0px !important; }</style><hr class='my_divider'>")

with col2:
    st.subheader("Pod Logs", anchor=False)
    rhs = st.container(border=True, height=700)

if st.secrets.debug:
    with st.container(border=True):
        st.json(st.session_state)
