import streamlit as st  # type: ignore
from lib import splunk as demo  # type: ignore

demo.page_header("Demonstration Status")

dm = demo.DemoManager()

current = dm.current_demo()

menu = st.popover("🧭 Menu")

menu.page_link(
  "manager-ui.py", 
  label="Demonstration Use Cases", 
  icon="💼", 
  use_container_width=True
)

menu.page_link(
    "pages/collector.py",
    label="Manage OpenTelemetry Collector",
    icon="🔭",
    use_container_width=True
)

menu.page_link(
    "pages/status.py",
    label="Demonstration Status",
    icon="🔭",
    use_container_width=True
)

if "collector_running" not in st.session_state:
    dm.check_status(status="status.phase=Running")

if "pod_name" not in st.session_state:
    st.session_state.pod_name = False

def show_logs(pod_name):
    st.session_state.pod_name = pod_name
    with rhs.caption(f"Logs for **:blue[{pod_name}]**"):
        logs, code = dm.get_pod_logs(st.session_state.pod_name)
    
        if code == 0:
            log_container.code(logs, language="log")
        else:
            log_container.error(logs)

col1, col2 = st.columns([1, 2])

with col1:
    st.subheader(":blue[Pod Status]", anchor=False)
    with st.container(border=True, height=700):
        demo_dict = dm.demo_status()

        if not demo_dict:
            st.info("**No pods found**")
        else:
            for pod, state in demo_dict.items():
                with st.container(border=False):
                    status_col1, status_col2, status_col3 = st.columns([3, 2, 1])
                    status_col1.write(f"{pod}")

                    if state == "Running":
                        #status_col1.write(f":green[{pod}]")
                        status_col2.write(f":green[{state}]")
                    else:
                        #status_col1.write(f":orange[{pod}]")
                        status_col2.write(f":orange[{state}]")

                    status_col3.button("Logs", key=f"{pod}", on_click=show_logs, args=(pod,))
                    st.html("<style> .my_divider { margin: 0.2em 0px !important; }</style><hr class='my_divider'>")

with col2:
    st.subheader(f":blue[Pod Logs]", anchor=False)
    rhs = st.container(border=True, height=700)
    log_container = rhs.container(border=False, height=600)
    if st.session_state.pod_name is not False:
        rhs.button("Refresh logs", type="primary", on_click=show_logs, args=(st.session_state.pod_name,))

if st.secrets.debug:
    with st.container(border=True):
        st.json(st.session_state)
