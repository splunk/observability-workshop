from os import path

import pandas as pd  # type: ignore
import streamlit as st  # type: ignore
from lib import splunk as demo  # type: ignore
from waitress import serve  # type: ignore

demo.page_header("Manage OpenTelemetry Collector")

dm = demo.DemoManager()

menu = st.popover("🧭 Menu")

menu.page_link(
  "app.py", 
  label="Home", 
  icon="🏠", 
  use_container_width=True
)

menu.page_link(
    "pages/collector.py",
    label="Manage OpenTelemetry Collector",
    icon="🔭",
    use_container_width=True
)

menubar = st.empty()
placeholder = st.empty()
placeholder.header("Demo-in-a-Box")

if not hasattr(st, 'already_started_server'):
    # Hack the fact that Python modules (like st) only load once to
    # keep track of whether this file already ran.
    st.already_started_server = True

    st.write('''
        The first time this script executes it will run forever because it's
        running a Flask server.

        Just close this browser tab and open a new one to see your Streamlit
        app.
    ''')

    from flask import Flask, request

    app = Flask(__name__)


    @app.route("/saveConfig", methods=["GET", "POST"])
    def saveConfig():
        get_hec_url = request.form.get("hec_url")
        
        if (get_hec_url is None or get_hec_url == ""):
            hec_url = f"https://ingest.{request.form.get('realm')}.signalfx.com/v1/log"
            hec_token = request.form.get("ingest_token")
        else:
            hec_url = get_hec_url
            hec_token = request.form.get("hec_token")

        sql = dm.save_collector_config(
            request.form.get("realm"),
            request.form.get("ingest_token"),
            request.form.get("rum_token"),
            hec_url,
            hec_token,
            request.form.get("instance"),
        )
        return "Config saved", 200


    @app.route("/startCollector", methods=["GET", "POST"])
    def startCollector():
        dm.start_collector()
        return "Collector started", 200

    #app.run(port=8081)
    serve(app, host='0.0.0.0', port=8081)


def ocm():
    with placeholder.container():
        st.write("Optimize Cloud Monitoring")
def ioc():
    with placeholder.container():
        st.write("Understand Impact of Changes")

def dpim():
    with placeholder.container():
        st.write("Debug Problems in Microservices")
    
def eso():
    with placeholder.container():
        st.write("Enable Self-Service Observability")
    
def oee():
    with placeholder.container():
        st.write("Optimize End-User Experiences")

status = st.empty()

with menubar.container(border=True):
    collecter_status = dm.check_status()
    if collecter_status.empty:
        st.toast("Collector is not running")
    else:
        st.toast("Collector is running")
    options = ("Optimize Cloud Monitoring", "Understand Impact of Changes", "Debug Problems in Microservices", "Enable Self-Service Observability", "Optimize End-User Experiences")
    index = st.radio("Use Case", range(len(options)), format_func=lambda x: options[x], horizontal=True)

    if index == 0:
        ocm()
    elif index == 1:
        ioc()
    elif index == 2:
        dpim()
    elif index == 3:
        eso()
    elif index == 4: 
        oee()
