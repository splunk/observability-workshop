from os import path

import streamlit as st  # type: ignore
from flask import Flask, request  # type: ignore
from lib import splunk as demo  # type: ignore
from waitress import serve  # type: ignore

dm = demo.DemoManager()

app = Flask(__name__)


@app.route("/saveConfig", methods=["GET", "POST"])
def saveConfig():
    get_hec_url = request.form.get("hec_url")
    
    if (get_hec_url is None or get_hec_url == ""):
        hec_url = f"https://ingest.{request.form.get('realm')}.signalfx.com/v1/log"
        hec_token = request.form.get("ingest_token")
    else:
        hec_url = get_hec_url
        hec_token = request.form.get("hec_token")

    sql = dm.save_collector_config(
        request.form.get("realm"),
        request.form.get("ingest_token"),
        request.form.get("rum_token"),
        hec_url,
        hec_token,
        request.form.get("instance"),
    )
    return "Config saved", 200


@app.route("/startCollector", methods=["GET", "POST"])
def startCollector():
    dm.start_collector()
    return "Collector started", 200

app.run(port=8081)
#serve(app, host='0.0.0.0', port=8081)
