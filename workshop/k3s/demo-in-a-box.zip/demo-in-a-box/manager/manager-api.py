from os import path

#import streamlit as st  # type: ignore
from flask import Flask, request  # type: ignore
from lib import splunk as demo  # type: ignore
from waitress import serve  # type: ignore

dm = demo.DemoManager()

app = Flask(__name__)


@app.route("/saveConfig", methods=["POST"])
def saveConfig():
    get_hec_url = request.form.get("hec_url")
    
    if (get_hec_url is None or get_hec_url == ""):
        hec_url = f"https://ingest.{request.form.get('realm')}.signalfx.com/v1/log"
        hec_token = request.form.get("ingest_token")
        splunk_index = "main"
    else:
        hec_url = get_hec_url
        hec_token = request.form.get("hec_token")
        splunk_index = request.form.get("splunk_index")
    try: 
        sql = dm.save_collector_config(
            request.form.get("realm"),
            request.form.get("ingest_token"),
            request.form.get("rum_token"),
            hec_url,
            hec_token,
            splunk_index,
            request.form.get("instance"),
        )
        return "Success", 200
    except Exception as e:
        return e, 500


@app.route("/startCollector", methods=["GET"])
def startCollector():
    response, code = dm.start_collector()

    if code == 0:
        return "Success", 200
    else:
        return response, 500


@app.route("/stopCollector", methods=["GET"])
def stopCollector():
    response, code = dm.stop_collector()

    if code == 0:
        return "Success", 200
    else:
        return response, 500


@app.route("/startFrontendDemo", methods=["GET"])
def startFrontendDemo():
    response, returncode = dm.deploy_demo("frontend-1")
    
    if returncode == 0:
        return "Success", 200
    else:
        return response, 500


if __name__ == "__main__":
    app.run(port=8081, debug=True)
    #serve(app, host='0.0.0.0', port=8081)

