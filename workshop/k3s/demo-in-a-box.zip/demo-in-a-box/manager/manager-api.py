from flask import Flask, request  # type: ignore
from lib import splunk as demo  # type: ignore
from waitress import serve  # type: ignore

dm = demo.DemoManager()

app = Flask(__name__)


@app.route("/", methods=["GET"])
def index():
    return f"Demo-in-a-Box v{demo.VERSION} - OK"


def validaye_form_data(data):
    errors = {}

    if "realm" not in data:
        errors["realm"] = "Realm is required"
    if "ingest_token" not in data:
        errors["ingest_token"] = "Ingest token is required"
    if "instance" not in data:
        errors["instance"] = "Instance is required"
    return errors


@app.route("/saveConfig", methods=["POST"])
def saveConfig():
    try:
        form_data = request.form

        errors = validaye_form_data(form_data)
        if errors:
            return errors, 400

        get_hec_url = request.form.get("hec_url")

        if get_hec_url is None or get_hec_url == "":
            hec_url = f"https://ingest.{request.form.get('realm')}.signalfx.com/v1/log"
            hec_token = request.form.get("ingest_token")
            splunk_index = "main"
        else:
            hec_url = get_hec_url
            hec_token = request.form.get("hec_token")
            splunk_index = request.form.get("splunk_index")

        sql = dm.save_collector_config(
            request.form.get("realm"),
            request.form.get("ingest_token"),
            request.form.get("rum_token"),
            hec_url,
            hec_token,
            splunk_index,
            request.form.get("instance"),
        )

        return sql
    except Exception as e:
        return str(e), 500


if __name__ == "__main__":
    # app.run(port=8082, debug=True)
    serve(app, host="0.0.0.0", port=8082)
