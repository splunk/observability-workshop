import time

import streamlit as st  # type: ignore
from lib import splunk as demo  # type: ignore

if "helm_repo_initialized" not in st.session_state:
    st.session_state.helm_repo_initialized = True

if "helm_repo_updated" not in st.session_state:
    st.session_state.helm_repo_updated = False

demo.page_header("Manage OpenTelemetry Collector")

dm = demo.DemoManager()

demos = dm.available_demos()
current_demo = dm.current_demo()
config = dm.get_collector_config()

menu = st.popover("🧭 Menu")

menu.page_link(
  "manager-ui.py", 
  label="Demonstration Use Cases", 
  icon="💼", 
  use_container_width=True
)

menu.page_link(
    "pages/collector.py",
    label="Manage OpenTelemetry Collector",
    icon="🔭",
    use_container_width=True
)

menu.page_link(
    "pages/status.py",
    label="Demonstration Status",
    icon="🔭",
    use_container_width=True
)

status_updates = st.container()

def deploy_demo(name, deployment):
    status_updates.empty()

    with status_updates.status(
        f"Deploying `{name}` demo...", expanded=False
    ) as status:
        if deployment != current_demo["name"]:
            delete, returncode = dm.delete_demo(current_demo["name"])
            if returncode != 1:
                status.code(delete)
        status.caption(f"Patching Kubernetes secrets...")
        secret = dm.patch_deployment_secrets(config["instance"], name)
        status.code(secret[0])
        dm.update_current_demo(name, deployment)
        deploy = dm.deploy_demo(name, deployment)
        status.code(deploy[0])
        start_collector = dm.start_collector()
        status.code(start_collector[0])
        time.sleep(5)
        status.update(label=f"Deployed `{name}` demonstration!", state="complete")


def stop_demo(name, deployment):
    status_updates.empty()

    with status_updates.status(
        f"Stopping `{name}` demo...", expanded=False
    ) as status:
        status.caption("`helm delete` OpenTelemetry Collector")
        stop_collector, returncode = dm.stop_collector()
        status.code(stop_collector)
        status.caption(f"Deleting `{deployment}` deployment...")
        delete, returncode = dm.delete_demo(deployment)
        status.code(delete)
        dm.update_current_demo("None", "None")
        time.sleep(5)
        status.update(label=f"Deleted `{name}` demonstration!", state="complete")

demo_placeholder = st.empty()

n_cols = 4
n_rows = 1 + len(demos) // int(n_cols)
rows = [st.container() for _ in range(n_rows)]
cols_per_row = [r.columns(n_cols) for r in rows]
cols = [column for row in cols_per_row for column in row]

count = 0

with demo_placeholder.container():
    for demo in demos:
        if demo["name"] != "None":
            environment = f"{config['instance']}-{demo['name']}"
            
        with cols[count]:
            with st.container(border=True):
                st.write(f":blue[**{demo['use-case']}**]")
                st.html("<style> .my_divider { margin: 0.2em 0px !important; }</style><hr class='my_divider'>")
                st.caption(f"Environment:  \n**:violet[{environment}]**")
                st.html("<style> .my_divider { margin: 0.2em 0px !important; }</style><hr class='my_divider'>")

                with st.container(height=180, border=False):
                    st.caption(f":orange[{demo['description']}]")
                if current_demo["name"] == demo["name"]:
                    st.button(f"Stop", key=demo["use-case"], type="primary", on_click=stop_demo, args=(demo["name"], demo["deployment"]))
                else:
                    st.button(f"Deploy", key=demo["use-case"], on_click=deploy_demo, args=(demo["name"], demo["deployment"], ), help=f"Deploy the **:blue[{demo['use-case']}]** demonstration. The environment in Observability Cloud will be named **:violet[{environment}]**.")

            count += 1

if st.secrets.debug:
    st.json(st.session_state)