import time
from calendar import c
from os import name, path
import json
import pandas as pd  # type: ignore
import streamlit as st  # type: ignore
from lib import splunk as demo  # type: ignore

if "helm_repo_initialized" not in st.session_state:
    st.session_state.helm_repo_initialized = False

if "helm_repo_updated" not in st.session_state:
    st.session_state.helm_repo_updated = False


demo.page_header("Manage OpenTelemetry Collector")

dm = demo.DemoManager()

demos = dm.available_demos()

current_demo = dm.current_demo()

menu = st.popover("🧭 Menu")

menu.page_link(
  "manager-ui.py", 
  label="Home", 
  icon="🏠", 
  use_container_width=True
)

menu.page_link(
    "pages/collector.py",
    label="Manage OpenTelemetry Collector",
    icon="🔭",
    use_container_width=True
)

current = dm.current_demo()

status_updates = st.container()

def deploy_demo(name):
    status_updates.empty()
    values = dm.get_collector_config()

    with status_updates.status(
        f"Stopping {current['name']} demo...", expanded=True
    ) as status:
        if name != current["name"]:
            delete, returncode = dm.delete_demo(current["name"])
            if returncode != 1:
                status.code(delete)
        status.caption(f"Patching secrets..")
        secret, secretcode = dm.patch_secret(values[7], name)
        status.caption(secret)
        dm.update_current_demo(name)
        deploy, returncode = dm.deploy_demo(name)
        
        status.code(deploy)
        start_collector, returncode = dm.start_collector()
        status.code(start_collector)
        time.sleep(3)
        status.update(label=f"{name} deployed...", state="complete")

def stop_demo(demo_type):
    status_updates.empty()
    with status_updates.status(
        f"Stopping {demo_type} demo...", expanded=True
    ) as status:
        delete, returncode = dm.delete_demo(demo_type)
        status.code(delete)
        #time.sleep(3)
        stop_collector, returncode = dm.stop_collector()
        status.code(stop_collector)
        time.sleep(3)
        status.update(label=f"{demo_type} stopped", state="complete")
collecter_status = dm.check_status()

if collecter_status.empty:
    status_updates.error(":red[**OpenTelemetry Collector is not running!**]")
else:
    status_updates.success(":green[**OpenTelemetry Collector is running!**]")
    #options = ("Optimize Cloud Monitoring", "Understand Impact of Changes", "Debug Problems in Microservices", "Enable Self-Service Observability", "Optimize End-User Experiences")
    #index = st.radio("Use Case", range(len(options)), format_func=lambda x: options[x], horizontal=True)

demo_placeholder = st.empty()

n_cols = 5
n_rows = 1 + len(demos) // int(n_cols)
rows = [st.container() for _ in range(n_rows)]
cols_per_row = [r.columns(n_cols) for r in rows]
cols = [column for row in cols_per_row for column in row]

count = 0

with demo_placeholder.container():
    for demo in demos:
        with cols[count]:
            with st.container(border=True):
                st.caption(f":blue[**{demo['use-case']}**]")
                st.caption(f"**Deployment:** {demo['name']}.yaml")
                with st.expander("Description", expanded=False):
                    st.caption(demo['description'])
                #st.caption(f"**Namespace:** {demo['name']}")

                if current["name"] == demo["name"]:
                    st.button(f"Stop", key=demo["use-case"], type="primary", on_click=stop_demo, args=(demo["name"],))
                else:
                    st.button(f"Deploy", key=demo["use-case"], on_click=deploy_demo, args=(demo["name"],))

            count += 1

if st.secrets.debug:
    st.json(st.session_state)