import time

import streamlit as st  # type: ignore
from lib import splunk as demo  # type: ignore

if "helm_repo_initialized" not in st.session_state:
    st.session_state.helm_repo_initialized = True

if "helm_repo_updated" not in st.session_state:
    st.session_state.helm_repo_updated = False

demo.page_header("Manage OpenTelemetry Collector")

dm = demo.DemoManager()

available_demos = dm.available_demos()
current_demo = dm.current_demo()
config = dm.get_collector_config()

status_updates = st.container()

def deploy_demo(name, deployment):
    status_updates.empty()

    with status_updates.status(
        f"Deploying `{name}` demo...", expanded=True
    ) as status:
        #st.write(f"Deployment: {deployment}")
        #st.write(f"Current Demo Name: {current_demo['name']}")
        #st.write(f"Current Demo Deployment: {current_demo['deployment']}")
        if name != current_demo["name"] and current_demo["name"] != "None":
            status.update(label=f"Deleting `{current_demo['name']}` deployment...")
            delete, returncode = dm.delete_demo(current_demo["deployment"])
            time.sleep(5)
            if returncode != 1:
                status.code(delete)
        status.update(label=f"Patching Kubernetes secrets...")
        secret = dm.patch_deployment_secrets(config["instance"], name)
        time.sleep(1)
        status.code(secret[0])
        dm.update_current_demo(name, deployment)
        status.update(label=f"Deploying `{name}` demonstration...")
        deploy = dm.deploy_demo(name, deployment)
        time.sleep(5)
        status.code(deploy[0])
        status.update(label=f"Starting OpenTelemetry Collector...")
        start_collector = dm.start_collector()
        status.code(start_collector[0])
        status.update(label=f"Waiting for OpenTelemetry Collector to start...")
        time.sleep(10)
        status.update(label=f"Deployed `{name}` demonstration!", state="complete", expanded=False)


def stop_demo(name, deployment):
    status_updates.empty()

    with status_updates.status(
        f"Stopping `{name}` demo...", expanded=True
    ) as status:
        status.update(label="`helm delete` OpenTelemetry Collector")
        stop_collector, returncode = dm.stop_collector()
        time.sleep(2)
        status.code(stop_collector)
        status.update(label=f"Deleting `{deployment}` deployment...")
        delete, returncode = dm.delete_demo(deployment)
        time.sleep(2)
        status.code(delete)
        dm.update_current_demo("None", "None")
        time.sleep(5)
        status.update(label=f"Deleted `{name}` demonstration!", state="complete", expanded=False)

demo_placeholder = st.empty()

n_cols = 4
n_rows = 1 + len(available_demos) // int(n_cols)
rows = [st.container() for _ in range(n_rows)]
cols_per_row = [r.columns(n_cols) for r in rows]
cols = [column for row in cols_per_row for column in row]

count = 0

with demo_placeholder.container():
    for demo in available_demos:
        if demo["name"] != "None":
            environment = f"{config['instance']}-{demo['name']}"
            
        with cols[count]:
            with st.container(border=True):
                st.write(f":blue[**{demo['use-case']}**]")
                st.html("<style> .my_divider { margin: 0.2em 0px !important; }</style><hr class='my_divider'>")
                st.caption(f"Environment:  \n**:violet[{environment}]**")
                st.html("<style> .my_divider { margin: 0.2em 0px !important; }</style><hr class='my_divider'>")

                with st.container(height=180, border=False):
                    st.caption(f":orange[{demo['description']}]")
                if current_demo["name"] == demo["name"]:
                    st.button(f"Stop", key=demo["use-case"], type="primary", on_click=stop_demo, args=(demo["name"], demo["deployment"]))
                else:
                    st.button(f"Deploy", key=demo["use-case"], on_click=deploy_demo, args=(demo["name"], demo["deployment"], ), help=f"Deploy the **:blue[{demo['use-case']}]** demonstration. The environment in Observability Cloud will be named **:violet[{environment}]**.")

            count += 1

if st.secrets.debug:
    st.json(st.session_state)