from os import path

import pandas as pd  # type: ignore
import streamlit as st  # type: ignore
from lib import splunk as demo  # type: ignore

if "helm_repos_updated" not in st.session_state:
    st.session_state.helm_repos_updated = False

demo.page_header("Manage OpenTelemetry Collector")

dm = demo.DemoManager()

menu = st.popover("🧭 Menu")

menu.page_link(
  "manager-ui.py", 
  label="Home", 
  icon="🏠", 
  use_container_width=True
)

menu.page_link(
    "pages/collector.py",
    label="Manage OpenTelemetry Collector",
    icon="🔭",
    use_container_width=True
)

menubar = st.empty()
placeholder = st.empty()

col1, col2 = st.columns([2, 3])


def ocm():
    with col1.container(border=True):
        st.subheader("Optimize Cloud Monitoring")
        st.write("This use case is for ITOps teams managing hybrid infrastructure that need to troubleshoot cloud-native performance issues, by correlating real-time metrics with logs to troubleshoot faster, improve MTTD/MTTR, and optimize costs.")
        st.write('''
            **Splunk Observability Cloud, Splunk Infrastructure Monitoring (IM)**
            * Log Observer Connect
            * Unified identity
            * Real-time streaming analytics
            * OOTB content - navigators and dashboards - for:
              * Kubernetes
              * Cloud-native IaaS/PaaS services (AWS, Azure, GCP)
              * Serverless functions
            * AutoDetect detectors and alerts
        ''')

        ocm_deploy = st.button("Deploy OCM")
        
        if ocm_deploy:
            dm.deploy_demo("frontend")


def ioc():
    with col1.container(border=True):
        st.subheader("Understand Impact of Changes")
        st.write("This use case helps SREs identify the impact of planned and unplanned changes to their environment so that they can address issues quickly to ensure performance of key customer transactions.")
        st.write('''
            **Splunk Platform**
            * Log Observer Connect

            **Splunk Infrastructure Monitoring**
            * Kubernetes Navigator
            * Logs in dashboards

            **Splunk APM**
            * Service Map
            * Business Workflows
            * Tag Spotlight
            * Trace Analyzer
            * OpenTelemetry
        ''')


def dpim():
    with col1.container(border=True):
        st.subheader("Debug Problems in Microservices")
        st.write("This use case helps software developers to make debugging problems in microservices easier, faster, and more cost-effective for platform engineering teams rolling out standardized tooling. ")
        st.write('''
            **Splunk Platform**
            * Log Observer Connect

            **Splunk Infrastructure Monitoring**
            * Custom Metrics 
            * SignalFlow
            * SLO Monitoring
            * Logs in dashboards

            **Splunk APM**
            * Tag Spotlight
            * Trace Analyzer
            * Service Centric Views
            * OpenTelemetry
        ''')


def eso():
    with col1.container(border=True):
        st.subheader("Enable Self-Service Observability")
        st.write("This use case helps platform engineering (or central tools) teams enable engineers with self-service observability tooling at scale, so developers and SREs can spend less time managing their toolchain and more time building and delivering cool software.")
        st.write('''
            **Splunk Observability Cloud**
            * OpenTelemetry standardization
            * RBAC, SSO and access tokens
            * Metrics Pipeline Management
            * Mirrored dashboards
            * Terraform support, Observability-as-code
            * Cloud Processor
        ''')


def oee():
    with col1.container(border=True):
        st.subheader("Optimize End-User Experiences")
        st.write("This use case helps engineering teams understand the user experience of their applications, and helps them identify and resolve user experience issues in order to better engage their customers and drive better results for their organization.")
        st.write('''
            **Splunk RUM**
            * Tag Spotlight
            * Session Replay
            * OpenTelemetry
            * Connection to APM

            **Splunk Synthetic Monitoring**
            * 40+ performance metrics focused on user experience
            * 50+ testing locations
            * Simple workflows for setting up Synthetics tests
            * Private Locations
            ''')


status = st.empty()

with menubar.container(border=True):
    collecter_status = dm.check_status()
    if collecter_status.empty:
        st.toast("OpenTelemetry Collector is not running!")
    else:
        st.toast("Collector is running")
    options = ("Optimize Cloud Monitoring", "Understand Impact of Changes", "Debug Problems in Microservices", "Enable Self-Service Observability", "Optimize End-User Experiences")
    index = st.radio("Use Case", range(len(options)), format_func=lambda x: options[x], horizontal=True)

    if index == 0:
        ocm()
    elif index == 1:
        ioc()
    elif index == 2:
        dpim()
    elif index == 3:
        eso()
    elif index == 4: 
        oee()

with col2.container(border=True, height=300):
    st.subheader("Demo Status")
    st.write("Demo is currently running...")

st.json(st.session_state)