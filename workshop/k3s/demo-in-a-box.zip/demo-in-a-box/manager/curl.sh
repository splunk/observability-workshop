curl -X POST http://localhost:8081/saveConfig \
  -d "realm=eu0&ingest_token=wSgTADmdeTvrZBfHy3GPNA&rum_token=XVZtGmYfvn2uQe9razgZbg&instance=diab"

curl -X GET http://localhost:8081/startCollector
