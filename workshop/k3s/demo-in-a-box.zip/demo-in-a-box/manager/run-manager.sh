#!/bin/bash
cd /home/splunk/demo-in-a-box/manager
python3 -m venv venv
echo $PWD
activate () {
    . $PWD/venv/bin/activate
}
nohup streamlit run app.py --server.port=8082