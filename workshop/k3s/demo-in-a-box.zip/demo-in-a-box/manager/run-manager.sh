#!/bin/bash
cd /home/splunk/demo-in-a-box/manager
python3 -m venv venv
source ./venv/bin/activate
pip3 install -r requirements.txt --upgrade
nohup streamlit run app.py --server.port=8082