import sqlite3
import subprocess
import time
from datetime import datetime
from sqlite3 import Error

import kr8s  # type: ignore
import pandas as pd  # type: ignore
import streamlit as st  # type: ignore
from kr8s.objects import Pod  # type: ignore
from kr8s.objects import objects_from_files  # type: ignore

year = datetime.now().year

VERSION = "1.0.0"
CAPTION = f"© {year} Splunk Inc. All rights reserved. **Demo-in-a-Box v{VERSION}**"


class DemoManager:


    def __init__(self):
        if st.session_state.helm_repos_updated is False:
            subprocess.check_output(
                [
                    "helm",
                    "repo",
                    "add",
                    "splunk-otel-collector-chart",
                    "https://signalfx.github.io/splunk-otel-collector-chart",
                ]
            )
            subprocess.check_output(["helm", "repo", "update"], text=True)
            st.toast("Helm repositories updated")
            st.session_state.helm_repos_updated = True


    def check_status(self, status=""):
        selector = {"app": "splunk-otel-collector"}

        df = pd.DataFrame(columns=["Namespace", "Name", "Status", "HostIP"])
        pods = kr8s.get(
            "pods", namespace="default", label_selector=selector, field_selector=status
        )

        for pod in pods:
            row = [pod.namespace, pod.name, pod.status.phase, pod.status.hostIP]
            df.loc[len(df.index)] = row

        if df.empty:
            st.session_state.collector_running = False
        else:
            st.session_state.collector_running = True

        return df


    def get_collector_config(self):
        con = sql_connection()
        if con is not None:
            cur = con.cursor()
            cur.execute("SELECT * FROM collector WHERE id = 1")

            return cur.fetchone()


    def save_collector_config(
        self, realm, ingest_token, rum_token, hec_url, hec_token, instance
    ):
        con = sql_connection()
        if con is not None:
            cur = con.cursor()
            cur.execute(
                "UPDATE collector SET realm = ?, ingest_token = ?, rum_token = ?, hec_url = ?, hec_token = ?, instance = ? WHERE id = 1",
                (realm, ingest_token, rum_token, hec_url, hec_token, instance),
            )
            con.commit()


    def start_collector(self):
        con = sql_connection()
        if con is not None:
            cur = con.cursor()
            cur.execute("SELECT * FROM collector WHERE id = 1")

            result = cur.fetchone()
            realm = result[1]
            ingest_token = result[2]
            rum_token = result[3]
            hec_url = result[4]
            hec_token = result[5]
            instance = result[6]
        try:
            result = subprocess.check_output(
                [
                    "helm",
                    "install",
                    "splunk-otel-collector",
                    f"--set=splunkObservability.realm={realm}",
                    f"--set=splunkObservability.accessToken={ingest_token}",
                    f"--set=clusterName={instance}-k3s-cluster",
                    "--set=logsEngine=otel",
                    f"--set=environment={instance}-workshop",
                    "--set=splunkObservability.profilingEnabled=true",
                    
                    "splunk-otel-collector-chart/splunk-otel-collector",
                ],
                text=True,
            )
        except Exception as e:
            return str(e)
        return str(result)


    def stop_collector(self):
        try:
            result = subprocess.check_output(
                ["helm", "delete", "splunk-otel-collector", "-n", "default"], text=True
            )
            time.sleep(3)
        except Exception as e:
            return str(e)
        return str(result)



    def get_agent_logs(self):
        logs = ""
        selector = {"component": "otel-collector-agent"}
        pods = kr8s.get("pods", namespace="default", label_selector=selector)
        for pod in pods:
            name = pod.name
        
            if name is not None:
                pod = Pod.get(name, namespace="default")
                for line in pod.logs():
                    logs += line + "\n"
                
        return logs
        

    def deploy_demo(self, demo):
        try:
            deployment = f"deployments/{demo}.yaml"
            resources = objects_from_files(deployment)
            for r in resources:
                print(r)
                r.create()
            return "200"
        except Exception as e:
            return str(e)

def page_header(title, is_home=False):
    st.set_page_config(
        page_title=f"{title} - Demo in a Box",
        page_icon=None,
        layout="wide",
        initial_sidebar_state="auto",
        menu_items={"About": f"**Demo in a Box - Version {VERSION}**"},
    )

    # with open( "app/style.css" ) as css:
    #    st.markdown( f'<style>{css.read()}</style>' , unsafe_allow_html= True)

    st.image("images/splunk-corp-logo-w-rgb.png", width=130)
    st.caption(CAPTION)


def sql_connection():
    try:
        con = sqlite3.connect("manager.db")
        return con
    except Error:
        print(Error)


def sql_table(con):
    cursorObj = con.cursor()
    cursorObj.execute(
        "CREATE TABLE if not exists collector(id integer PRIMARY KEY, realm, ingest_token, rum_token, hec_url, hec_token, instance)"
    )
    cursorObj.execute(
        "CREATE TABLE if not exists demo(id integer PRIMARY KEY, name, state)"
    )
    cursorObj.execute(
        "INSERT OR IGNORE INTO collector VALUES(1, 'eu0', 'ing', 'api', 'url', 'token', 'ins')"
    )
    cursorObj.execute("INSERT OR IGNORE INTO demo VALUES(1, '', '')")

    con.commit()


con = sql_connection()
sql_table(con)
