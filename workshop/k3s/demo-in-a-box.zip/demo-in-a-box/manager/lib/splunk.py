import json
import pathlib
import sqlite3
import subprocess
from datetime import datetime
from sqlite3 import Error, connect

import kr8s  # type: ignore
import pandas as pd  # type: ignore
import streamlit as st  # type: ignore
import yaml
from kr8s.objects import Pod  # type: ignore
from kr8s.objects import objects_from_files  # type: ignore

year = datetime.now().year

VERSION = "3.0.0"
CAPTION = f"© {year} Splunk Inc. All rights reserved. **Demo-in-a-Box v{VERSION}**"


def sql_connection():
    con = sqlite3.connect("manager.sqlite3")
    con.row_factory = sqlite3.Row
    return con


def sql_table(con):
    cursorObj = con.cursor()
    cursorObj.execute(
        "CREATE TABLE if not exists collector(id integer PRIMARY KEY, realm, ingest_token, rum_token, hec_url, hec_token, splunk_index, instance)"
    )
    cursorObj.execute(
        "CREATE TABLE if not exists current_demo(id integer PRIMARY KEY, name)"
    )
    cursorObj.execute(
        "INSERT OR IGNORE INTO collector VALUES(1, 'realm', 'ingest_token', 'rum_token', 'hec_url', 'hec_token', 'splunk_index', 'instance')"
    )
    cursorObj.execute("INSERT OR IGNORE INTO current_demo VALUES(1, NULL)")
    con.commit()


con = sql_connection()
sql_table(con)


class DemoManager:

    def __init__(self):
        self.version = VERSION

    def available_demos(self):
        demo_dict = []
        with open(f"{pathlib.Path().resolve()}/demos.yaml", "r") as yamlfile:
            demos = yaml.safe_load_all(yamlfile)

            for demo in demos:
                demo_dict.append(demo)

        return demo_dict

    # def initialize_helm_repo(self):
    #    if st.session_state.helm_repo_initialized is False:
    #        try:
    #            result = subprocess.run(
    #                [
    #                    "helm",
    #                    "repo",
    #                    "add",
    #                    "splunk-otel-collector-chart",
    #                    "https://signalfx.github.io/splunk-otel-collector-chart",
    #                ],
    #                check=True,
    #                text=True,
    #                capture_output=True,
    #            )
    #            return result.stdout, result.returncode
    #        except subprocess.CalledProcessError as e:
    #            return e.stderr, e.returncode

    def update_helm_repo(self):
        if st.session_state.helm_repo_updated is False:
            try:
                result = subprocess.run(
                    ["helm", "repo", "update"],
                    check=True,
                    text=True,
                    capture_output=True,
                )
                return result.stdout, result.returncode
            except subprocess.CalledProcessError as e:
                return e.stderr, e.returncode
        else:
            return "Helm repo already updated!", 0

    def check_status(self, status=""):
        selector = {"app": "splunk-otel-collector"}

        df = pd.DataFrame(columns=["Namespace", "Name", "Status", "HostIP"])
        pods = kr8s.get(
            "pods", namespace="default", label_selector=selector, field_selector=status
        )

        for pod in pods:
            row = [pod.namespace, pod.name, pod.status.phase, pod.status.hostIP]
            df.loc[len(df.index)] = row

        if df.empty:
            st.session_state.collector_running = False
        else:
            st.session_state.collector_running = True

        return df

    def get_collector_config(self):
        con = sql_connection()
        cur = con.cursor()
        cur.execute("SELECT * FROM collector WHERE id = 1")
        return cur.fetchone()

    def save_collector_config(
        self, realm, ingest_token, rum_token, hec_url, hec_token, splunk_index, instance
    ):
        con = sql_connection()
        cur = con.cursor()

        try:
            cur.execute(
                "UPDATE collector SET realm = ?, ingest_token = ?, rum_token = ?, hec_url = ?, hec_token = ?, splunk_index = ?, instance = ? WHERE id = 1",
                (
                    realm,
                    ingest_token,
                    rum_token,
                    hec_url,
                    hec_token,
                    splunk_index,
                    instance,
                ),
            )
            con.commit()
            self.patch_collector_secrets(realm, rum_token)
            return "OpenTelemetry configuration saved!", 200
        except Exception as e:
            con.rollback()
            return "Failed to save configuration", 500
        finally:
            con.close()

    def start_collector(self):
        con = sql_connection()
        cur = con.cursor()
        cur.execute("SELECT * FROM collector WHERE id = 1")
        result = cur.fetchone()
        cur.execute("SELECT * FROM current_demo WHERE id = 1")
        current_demo = cur.fetchone()

        try:
            result = subprocess.run(
                [
                    "helm",
                    "install",
                    "splunk-otel-collector",
                    f"--set=splunkObservability.realm={result['realm']}",
                    f"--set=splunkObservability.accessToken={result['ingest_token']}",
                    f"--set=clusterName={result['instance']}-k3s-cluster",
                    "--set=logsEngine=otel",
                    f"--set=environment={result['instance']}-{current_demo['name']}",
                    "--set=splunkObservability.profilingEnabled=true",
                    f"--set=splunkPlatform.endpoint={result['hec_url']}",
                    f"--set=splunkPlatform.token={result['hec_token']}",
                    f"--set=splunkPlatform.index={result['splunk_index']}",
                    "splunk-otel-collector-chart/splunk-otel-collector",
                    "-f",
                    f"{pathlib.Path().resolve()}/opentelemetry-collector/values.yaml",
                ],
                check=True,
                text=True,
                capture_output=True,
            )
            return result.stdout, result.returncode
        except subprocess.CalledProcessError as e:
            return e.stderr, e.returncode

    def stop_collector(self):
        try:
            result = subprocess.run(
                ["helm", "delete", "splunk-otel-collector", "-n", "default"],
                check=True,
                text=True,
                capture_output=True,
            )
            return result.stdout, result.returncode
        except subprocess.CalledProcessError as e:
            return e.stderr, e.returncode

    st.cache_data(ttl=300)
    def get_agent_logs(self):
        selector = {"component": "otel-collector-agent"}
        pods = kr8s.get("pods", namespace="default", label_selector=selector)
        for pod in pods:
            name = pod.name

        if name is not None:
            try:
                logs = subprocess.run(
                    ["kubectl", "logs", name, "-n", "default", "--tail=500"],
                    check=True,
                    text=True,
                    capture_output=True,
                )
                return logs.stdout, logs.returncode
            except subprocess.CalledProcessError as e:
                return e.stderr, e.returncode
        else:
            return "No pod logs available!", 1

    def patch_deployment_secrets(self, instance, current_demo):
        current_instance = instance + "-" + current_demo
        command1 = {
            "stringData": {
                "instance": current_instance,
                "deployment": "deployment.environment=" + current_instance,
                "app": current_instance + "-store",
            }
        }
        try:
            result = subprocess.run(
                [
                    "kubectl",
                    "patch",
                    "secret",
                    "splunk-secrets",
                    "-p %s" % str(json.dumps(command1)),
                ],
                check=True,
                text=True,
                capture_output=True,
            )
            return result.stdout, result.returncode
        except subprocess.CalledProcessError as e:
            return e.stderr, e.returncode

    def patch_collector_secrets(self, realm, rum_token):
        command1 = {
            "stringData": {
                "realm": realm,
                "rum_token": rum_token,
            }
        }
        try:
            result = subprocess.run(
                [
                    "kubectl",
                    "patch",
                    "secret",
                    "splunk-secrets",
                    "-p %s" % str(json.dumps(command1)),
                ],
                check=True,
                text=True,
                capture_output=True,
            )
            return result.stdout, result.returncode
        except subprocess.CalledProcessError as e:
            return e.stderr, e.returncode

    def deploy_demo(self, demo):
        try:
            deployment_file = f"{pathlib.Path().resolve()}/deployments/{demo}.yaml"
            result = subprocess.run(
                ["kubectl", "apply", "-f", f"{deployment_file}"],
                check=True,
                text=True,
                capture_output=True,
            )

            if result.returncode == 0:
                con = sql_connection()
                cur = con.cursor()
                cur.execute(
                    "UPDATE current_demo SET name = ? WHERE id = 1",
                    (demo,),
                )
                con.commit()

            return result.stdout, result.returncode
        except subprocess.CalledProcessError as e:
            return e.stderr

    def delete_demo(self, demo):
        try:
            deployment_file = f"deployments/{demo}.yaml"
            result = subprocess.run(
                ["kubectl", "delete", "-f", f"{deployment_file}"],
                check=True,
                text=True,
                capture_output=True,
            )

            if result.returncode == 0:
                con = sql_connection()
                cur = con.cursor()
                cur.execute(
                    "UPDATE current_demo SET name = NULL WHERE id = 1",
                )
                con.commit()

            return result.stdout, result.returncode
        except subprocess.CalledProcessError as e:
            return e.stderr, e.returncode

    def current_demo(self):
        con = sql_connection()
        cur = con.cursor()
        cur.execute("SELECT name FROM current_demo WHERE id = 1")
        return cur.fetchone()

    def update_current_demo(self, demo):
        con = sql_connection()
        cur = con.cursor()
        cur.execute(
            "UPDATE current_demo SET name = ? WHERE id = 1",
            (demo,),
        )
        con.commit()


def page_header(title, is_home=False):
    st.set_page_config(
        page_title=f"{title} - Demo-in-a-Box",
        page_icon=None,
        layout="wide",
        initial_sidebar_state="auto",
        menu_items={"About": f"**Demo in a Box - Version {VERSION}**"},
    )

    # with open( "app/style.css" ) as css:
    #    st.markdown( f'<style>{css.read()}</style>' , unsafe_allow_html= True)

    st.image("images/splunk-corp-logo-w-rgb.png", width=130)
    st.caption(CAPTION)
