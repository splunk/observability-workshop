#!/bin/bash

# turn on bash's job control
set -m

#Set redis parameter
redis-cli -h $REDIS_HOST -p $REDIS_PORT config set notify-keyspace-events KEA 
  
# Start the primary process and put it in the background
#python3 /app/sender.py > arlogs/sender-log.txt 2>&1 &
python3 /app/sender.py &

# Start the helper process

python3 /app/listener.py 

