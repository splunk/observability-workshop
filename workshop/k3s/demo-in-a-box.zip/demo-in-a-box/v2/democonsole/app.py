import os
import re
import subprocess
from glob import glob
from os.path import exists
from pathlib import Path
from threading import Event, Thread
from time import sleep

import requests
import yaml  # type: ignore
from agentstatus import AgentStatus
from demostatus import DemoStatus
from flask import Flask, render_template, request  # type: ignore
from flask_socketio import SocketIO  # type: ignore
from servicestatus import ServiceStatus

from demos import Demos

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app)
numClients = 0
MAXLOOPDBSTARTUP=10

rootDirectory = os.path.abspath(os.path.join(app.root_path, os.pardir))

backendSecondaryStart = True
dbQuerySecondaryStart = True

thread = Thread()
thread_stop_event = Event()

config = {}
def APP_VERSION():
    return "SOCD 2.1.0"

def sendData():
  global config
  demos = Demos()
  loadConfig()

  while not thread_stop_event.isSet():
    global numClients
    global backendSecondaryStart
    global dbQuerySecondaryStart

    print(f'clients: {numClients}')
    if numClients > 0:
      status = demos.updateStatus()
      if (1==1):
        socketio.emit('debugInfo', {'msg': status}, namespace='/connection')

      agentStatus = demos.getAgentStatus()
      if (agentStatus == AgentStatus.DOWN):
        socketio.emit('showConfig', {}, namespace='/connection')
      if (agentStatus == AgentStatus.STARTING):
        socketio.emit('showConfig', {'status': 'starting'}, namespace='/connection')   
      if (agentStatus == AgentStatus.UP):
        socketio.emit('showDemos', {}, namespace='/connection')

        # If any demos terminating, just wait
        if not demos.anyDemosTerminating():
          if (demos.backendStatus() == DemoStatus.UP):
            if (not backendSecondaryStart):
              backendSecondaryStart = True
              startBackendDemo()
            socketio.emit('backendDemo', {'status': 'up'}, namespace='/connection')
          else:
            socketio.emit('backendDemo', {'status': 'down'}, namespace='/connection')
          if (demos.frontendStatus() == DemoStatus.UP):
            socketio.emit('frontendDemo', {'status': 'up'}, namespace='/connection')
          else:
            socketio.emit('frontendDemo', {'status': 'down'}, namespace='/connection')
          if (demos.profilingStatus() == DemoStatus.UP):
            socketio.emit('profilingDemo', {'status': 'up'}, namespace='/connection')
          else:
            socketio.emit('profilingDemo', {'status': 'down'}, namespace='/connection')
          if (demos.astroStatus() == DemoStatus.UP):
            socketio.emit('astroDemo', {'status': 'up'}, namespace='/connection')
          else:
            socketio.emit('astroDemo', {'status': 'down'}, namespace='/connection')
      socketio.sleep(8)
      continue
  socketio.sleep(8)

@app.route('/', methods=['GET', 'POST'])
def root():
  print(request.method)
  # TODO: No longer posting to root any more to start demos; need to update
  if request.method == 'GET':
    return render_template('index.html', form=request.form)

  return render_template('index.html')

@socketio.on('connect', namespace='/connection')
def client_connect(str):
  global thread
  print('client connected')
  global numClients
  numClients += 1

  if not thread.is_alive():
    print('starting thread')
    thread = socketio.start_background_task(sendData)

@socketio.on('disconnect', namespace='/connection')
def client_disconnect():
  print('client disconnected')
  global numClients
  numClients -= 1

@app.route('/saveConfig', methods=['GET', 'POST'])
def saveConfig(): 
  global config
  demos = Demos()
  config.clear()
  config['realm'] = request.form.get('realm')
  config['accessToken'] = request.form.get('accessToken')
  config['rumAccessToken'] = request.form.get('rumAccessToken')
  config['environment'] = request.form.get('environment')
  HECURL = request.form.get('HECUrl')
  if HECURL == None or HECURL == '': #if the HECUrl is not set then we are using the default
    config['HECUrl'] = 'https://ingest.' + config['realm'] + '.signalfx.com/v1/log'
    config['HECToken'] = config['accessToken']
  else:
    config['HECUrl'] = HECURL
    config['HECToken'] = request.form.get('HECToken')
  config['loadgenLocation'] = request.form.get('loadgenLocation')

  isDBUP=False  
  for startDBCheck in range(MAXLOOPDBSTARTUP): #try to see if the DB's are up if not bail with warning
    result = demos.checkServicesRunning()
    if ( result == ServiceStatus.DOWN):
      initDB_Setup(config)
      print("Starting DataBases...")
    elif ( result == ServiceStatus.STARTING ):
      print("waiting on DataBases... " + str(MAXLOOPDBSTARTUP-startDBCheck) ) 
    elif ( result == ServiceStatus.UP ):   
      isDBUP = True
      break #lets hurry on
    socketio.sleep(8)  # wait for the DB's to come up
     
  if (isDBUP == False):    #Databases/Services are not up at this Point Error... bail with error
    raise Exception( "Services not started in time... !!!!")
 
  saveConfigFile(config)
  startCollector()
  return {}

@app.route('/startCollector', methods=['GET', 'POST'])
def startCollector():
  global rootDirector
  demos = Demos()
  otelColPath          = os.path.join(rootDirectory, 'hack', 'otel', 'otelcol-base.yaml')
  otelColPathDefaults  = os.path.join(rootDirectory, 'hack', 'otel', 'splunk-defaults.yaml')
  otelColHECUrl        = '--set=splunkPlatform.endpoint=' +  config['HECUrl']
  otelColHECToken       = '--set=splunkPlatform.token='   +  config['HECToken']
  if exists(otelColPath):
    agentStatus = demos.getAgentStatus()
    if (agentStatus == AgentStatus.DOWN):
     subprocess.run(['helm', 'install', 'splunk-otel-collector',
                     '--set=splunkObservability.profilingEnabled=true', 
                     '--set=splunkObservability.infrastructureMonitoringEventsEnabled=true', 
                     otelColHECUrl, otelColHECToken,
                     '--set=splunkPlatform.metricsIndex=k8s-metrics',
                     '--set=splunkPlatform.index=main',
                     '--set=agent.enabled=true',
                     '--set=gateway.replicaCount=1',
                     '--set=gateway.resources.limits.cpu=500m',
                     '--set=gateway.resources.limits.memory=1Gi',
                     '--set=clusterReceiver.enabled=true',
                     #'--version=0.80.0',
                     'splunk-otel-collector-chart/splunk-otel-collector',
                    '-f',  otelColPath, '-f', otelColPathDefaults])
    else:
      print ("Collector is still starting up or UP")    
  else:
    print ("Waiting on config to be written")  
  return {}

@app.route('/stopCollector', methods=['GET', 'POST'])
def stopCollector():
  #Stopping all demo's first
  subprocess.run(['kubectl', "delete", '-f', os.path.join(rootDirectory, 'hack', 'yaml')])
  #removing collecter with Helm uninstall
  print(f"uninstalling splunk-otel-collector")
  subprocess.run(['helm', 'uninstall', 'splunk-otel-collector'])
  print("removing old config")  
  subprocess.run(['rm', "-rf", os.path.join(rootDirectory, 'hack')]) 
  return {}

@app.route('/startdemo', methods=['GET', 'POST'])
def startdemo():
  if (request.args['demo']== 'backend'):
    # Need to signify the demo has a secondary start
    global backendSecondaryStart
    backendSecondaryStart = False
  
  deployApp(True, request.args['demo'])
  return {}

@app.route('/stopdemo', methods=['GET', 'POST'])
def stopdemo():
  deployApp(False, request.args['demo'])
  return {}

@app.route('/toggledemo', methods=['GET', 'POST'])
def toggledemo():
  demo = request.args['demo']
  state = request.args['state']
  if ((demo != '') and (state != '')):
    toggleDemo(demo, state)
  return {}

@app.route('/version', methods=['GET', 'POST'])
def version():
  global version
  retval  = "{version: " + APP_VERSION() + "}"
  return retval

def deployApp(isDeploy, demo):
  op = 'apply'
  if (not isDeploy):
    op = 'delete'
  global rootDirectory
  demoyaml = "demoinabox-" + demo + ".yaml"
  # if demo == "astro":
  #   print("astronomy shop demo being installed")
  subprocess.run(['kubectl', op, '-f', os.path.join(rootDirectory, 'hack','yaml', demoyaml)])
   
def toggleDemo(demo, state):
  if (demo == 'backend' ):
    if state == '1':
      # Rollback demo
      ret = requests.post('http://localhost:8080/demo/api/env/ecf8fcd5-3966-4d5e-a3ac-4e9d7e883cc5/stopAction/DemoScenario/QmFkIGRlcGxveW1lbnQ=')
    else:
      # Deploy v2
      ret = requests.post('http://localhost:8080/demo/api/env/ecf8fcd5-3966-4d5e-a3ac-4e9d7e883cc5/startAction/DemoScenario/QmFkIGRlcGxveW1lbnQ=')
  if ( demo == 'db-query' ):
    if state == '1':
      # Rollback demo
      ret = requests.post('http://localhost:8088/demo/api/env/4705cfc1-3796-4853-a06c-0edfa016bc73/stopAction/DemoScenario/QmFkIGRlcGxveW1lbnQ=')
    else:
      # Deploy v2
      ret = requests.post('http://localhost:8088/demo/api/env/4705cfc1-3796-4853-a06c-0edfa016bc73/startAction/DemoScenario/QmFkIGRlcGxveW1lbnQ=') 
  if (demo == 'frontend'):
    if (state == 'default'):
      subprocess.run(['kubectl', 'apply', '-f', os.path.join(rootDirectory, 'hack','yaml', 'demoinabox-frontend.yaml')])
    if (state == 'errors'):
      subprocess.run(['kubectl', 'apply', '-f', os.path.join(rootDirectory, 'hack','yaml', 'demoinabox-noerror-paymentservice.yaml')])
  if (demo == 'profiling'):
      if state == 'default':
        subprocess.run(['kubectl', 'apply', '-f', os.path.join(rootDirectory, 'hack','yaml', 'demoinabox-profiling.yaml')])
      else:
        subprocess.run(['kubectl', 'apply', '-f', os.path.join(rootDirectory, 'hack', 'yaml', 'demoinabox-profiling-off.yaml')])
  
def startBackendDemo():
  print('Backend Secondary Start')
  while (1 == 1):
    try:
      ret = requests.get('http://localhost:8080')
      print(ret.text)
      break
    except:
      # Connection not up yet
      print("not up yet")
    sleep(5)
  # Start the backend demo
  ret = requests.post('http://localhost:8080/demo/api/env/ecf8fcd5-3966-4d5e-a3ac-4e9d7e883cc5/start/DemoScenario')
  #subprocess.run(['curl', '-X', 'POST', 'http://localhost:8080/demo/api/env/ecf8fcd5-3966-4d5e-a3ac-4e9d7e883cc5/startAction/DemoScenario/QmFkIGRlcGxveW1lbnQ='])

def startDBQueryDemo():
  print('DBQuery Secondary Start')
  while (1 == 1):
    try:
      ret = requests.get('http://localhost:8088')
      print(ret.text)
      break
    except:
      # Connection not up yet
      print("not up yet")
    sleep(5)
  # Start the dbQuery demo in roll back mode
  ret = requests.post('http://localhost:8088/demo/api/env/4705cfc1-3796-4853-a06c-0edfa016bc73/start/DemoScenario')
  #ret = requests.post('http://localhost:8088/demo/api/env/4705cfc1-3796-4853-a06c-0edfa016bc73/startaction/DemoScenario/QmFkIGRlcGxveW1lbnQ=')  
  
def processConfig(sourceFile, destinationFile, replacements):
  global config
  with open(sourceFile) as inputFile:
    with open(destinationFile, 'w') as outputFile:
      for line in inputFile:
        if '{{' in line:
          for old, new in replacements.items():
            if (old != '{{loadgenLocation}}'):
              line = line.replace(old, config[new])
            else:
              if (config[new] == 'local'):
                line = line.replace('{{provider}}', '')
              else:
                line = line.replace('{{provider}}', 'aws')
        outputFile.write(line)

def processConfigs(config):
  templateFilePath = f'{rootDirectory}'
  destinationFilePath = f'{rootDirectory}/hack'
  scriptFilePath = f'{destinationFilePath}/scripts'
  yamlFilePath = f'{destinationFilePath}/yaml'
  if not exists( scriptFilePath) or not exists(yamlFilePath):
     os.makedirs(f'{rootDirectory}/hack/scripts', exist_ok=True) #just to be sure create scripts directory
     os.makedirs(f'{rootDirectory}/hack/yaml', exist_ok=True) #just to be sure create yaml directory
 
  replacements = { \
    r'{{token}}': r'accessToken', \
    r'{{environment}}': r'environment', \
    r'{{app_name}}': r'environment', \
    r'{{rum_app_name}}': r'environment', \
    r'{{rum_environment}}': r'environment', \
    r'{{realm}}': r'realm', \
    r'{{rum_token}}': r'rumAccessToken', \
    r'{{loadgenLocation}}': r'loadgenLocation', \
    r'{{hec_url}}': r'HECUrl', \
    r'{{hec_token}}': r'HECToken', \
    #r'{{mysqlip}}': r'mysqlip', \
    #r'{{redisip}}': r'redisip', \
    #r'{{redishost}}': r'redishost', \
    }
  #Processing files for the otel collector
  processConfig(f'{templateFilePath}/demos/otel-collector/otelcol-base.yaml', f'{destinationFilePath}/otel/otelcol-base.yaml', replacements)
  processConfig(f'{templateFilePath}/demos/otel-collector/splunk-defaults.yaml', f'{destinationFilePath}/otel/splunk-defaults.yaml', replacements)
  #Processing files extra-services folder
  processConfig(f'{templateFilePath}/demos/extra-services/mysql.yaml', f'{destinationFilePath}/yaml/mysql.yaml', replacements)
  processConfig(f'{templateFilePath}/demos/extra-services/redis.yaml', f'{destinationFilePath}/yaml/redis.yaml', replacements)
  #Processing files for the Backend Demo
  processConfig(f'{templateFilePath}/demos/backend/demoinabox-backend.yaml', f'{destinationFilePath}/yaml/demoinabox-backend.yaml', replacements)
  # Processing files for the Front End Demo
  processConfig(f'{templateFilePath}/demos/frontend/demoinabox-frontend.yaml', f'{destinationFilePath}/yaml/demoinabox-frontend.yaml', replacements)
  processConfig(f'{templateFilePath}/demos/frontend/demoinabox-noerror-paymentservice.yaml', f'{destinationFilePath}/yaml/demoinabox-noerror-paymentservice.yaml', replacements)
  processConfig(f'{templateFilePath}/demos/frontend/demoinabox-frontend-setup.sh', f'{scriptFilePath}/demoinabox-frontend-setup.sh', replacements)
  processConfig(f'{templateFilePath}/demos/frontend/demoinabox-frontend-stop.sh', f'{scriptFilePath}/demoinabox-frontend-stop.sh', replacements)
  # Processing  files for profiling demo
  processConfig(f'{templateFilePath}/demos/profiling/demoinabox-profiling.yaml', f'{destinationFilePath}/yaml/demoinabox-profiling.yaml', replacements)
  processConfig(f'{templateFilePath}/demos/profiling/demoinabox-profiling-off.yaml', f'{destinationFilePath}/yaml/demoinabox-profiling-off.yaml', replacements)
  # Processing  files for db-query demo
  #processConfig(f'{templateFilePath}/demos/db-query/demoinabox-db-query.yaml', f'{destinationFilePath}/yaml/demoinabox-db-query.yaml', replacements)
  # Processing  files for cicd demo
  #processConfig(f'{templateFilePath}/demos/cicd/demoinabox-cicd.yaml', f'{destinationFilePath}/yaml/demoinabox-cicd.yaml', replacements)
  # Processing  files for Astronomy shop  demo
  processConfig(f'{templateFilePath}/demos/astronomy/demoinabox-astro.yaml', f'{destinationFilePath}/yaml/demoinabox-astro.yaml', replacements)
  
  if (config['loadgenLocation'] == 'local'):
    demos = Demos()
    ip = demos.getIPAddress()
    with open(f'{destinationFilePath}/demoinabox-frontend.yaml', 'a') as outputFile:
      outputFile.write('        env:\n')
      outputFile.write('          - name: RUM_FRONTEND_IP\n')
      outputFile.write('            value: "192.168.7.234"\n')

def saveConfigFile(config):
  #global config
  #demos = Demos()
  # Check if we have written the config files and created folder before
  configFilePath = f'{rootDirectory}/hack/otel/config.yaml'
  if not exists(configFilePath):
    # create the required folders
    os.makedirs(f'{rootDirectory}/hack', exist_ok=True)
    os.makedirs(f'{rootDirectory}/hack/otel', exist_ok=True)
    os.makedirs(f'{rootDirectory}/hack/scripts', exist_ok=True)
    configFile = Path(configFilePath)
    configFile.touch(exist_ok=True)
  # Write the config file
  with open(configFilePath, 'w+') as stream:
    try:
      yaml.dump(config, stream)
    except:
      print("Failed to save config file")
    
  processConfigs(config)
    
def loadConfig():
  global config

  configFilePath = f'{rootDirectory}/hack/otel/config.yaml'
  if exists(configFilePath):
    configFile = open(configFilePath)
    config = yaml.load(configFile, Loader=yaml.FullLoader)
    processConfigs(config)
    socketio.emit('setConfig', config, namespace='/connection')

def initDB_Setup(config):
    subprocess.run(['kubectl', 'apply', '-f', os.path.join(rootDirectory, 'demos','extra-services', 'mysql.yaml')])  
    subprocess.run(['kubectl', 'apply', '-f', os.path.join(rootDirectory, 'demos','extra-services','redis.yaml')])  

if __name__ == '__main__':
  #loadConfig()
  socketio.run(app)
