# This is the code for the CICD demo within the demo-in-a-box environment

It consists of a listener to initiate data output for good and bad canary and a sender which sends the date to an o11y cloud instance.

## Structure
`python` - contains the python requirements, listener and sender. 

`terraform` - contains all the setup for the o11y cloud (signalfx) and on-call (victorops) instance

`ansible` - contains the ansible playbooks to set the listener and sender up on an EC2 instance


`Dockerfile` - builds the container for the listener and sender; a redis container is needed for the cicd container to work

`docker-compose.yml` - runs the whole setup of cicd container and redis container


**ATENTION**: The following environment variables need to be set to run propperly

`O11YCLOUD_INGEST_TOKEN` - the o11y cloud token with ingest capabilities

`O11YCLOUD_REALM` - the o11y cloud realm the data should be send to and the ingest token is valid for

## Usage
After startup the following things can be triggered:

1. Initialise and Good Canary
```
curl -X POST http://<host_address>:6000/write/<username>/30000
```

2. Bad Canary
```
curl -X POST http://<host_address>:6000/write/<username>/31000
```

3. Health Check
```
curl -X POST http://<host_address>:6000/health/<username>
```

`<host_address>` - the address the container is running on. 

`<username>` - the value of the variable `user`, the data should be marked with. 



## THE FOLLOWING WILL NOT BE NEEDED ANYMORE: 
The following will work for a default Raspbian OS install on a Raspberry Pi.

1. Using a fresh install of Raspbian OS run `sudo apt update` and `sudo apt upgrade`

2. Install Redis `sudo apt install redis-server`. Enable keyspace events notifications `redis-cli config set notify-keyspace-events KEA`. Install git `sudo apt install git` and then install Python3 pip `sudo apt install python3-pip`

3. Clone the `field-shared` repo `git clone https://github.com/signalfx/field-shared`

4. `cd field-shared/AutoRem-Pi`

5. `pip3 install -r requirements.txt`

6. Edit the `config.yaml` file and update with your `Access Token` and `Realm`. You can leave the Redis settings alone e.g.
```
signalfx:
  token: abc123def457ghi
  realm: us0
redis:∆∆∆∆
  host: localhost
  port: 6379
  db: 0
```
 
7. Start the sender and listener server
```
nohup python3 sender.py > arlogs/sender-log.txt 2>&1 &
nohup python3 listener.py > arlogs/listener-log.txt 2>&1 &
```

8. Initialise and Good Canary
```
curl -X POST http://<pi_ip_address>:6000/write/<username>/30000
```

9. Bad Canary
```
curl -X POST http://<pi_ip_address>:6000/write/<username>/31000
```

10. Health Check
```
curl -X POST http://<pi_ip_address>:6000/health/<username>
```

You will need to enable port forwarding on your router so the detector can send to your external IP address and be routed through to your Raspberry Pi.

**TIP** To remove a user from Redis and thus stop the metrics from that user from flowing in just run `redis-cli del <username>`
