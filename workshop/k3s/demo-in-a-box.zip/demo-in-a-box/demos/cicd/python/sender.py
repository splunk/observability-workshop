import asyncio
import time
import signalfx
import random
import uuid
import logging
from logging.handlers import RotatingFileHandler
import socket
import redis
import yaml
from faker import Faker
from pyaml_env import parse_config
import os

fake = Faker()

# Load configuration file
#with open('config.yaml', 'r') as ymlfile:
#    cfg = yaml.safe_load(ymlfile)
cfg = parse_config('config.yaml') 
print ("sfx token : " + cfg['signalfx']['token'])
print ("sfx realm : " + cfg['signalfx']['realm'])
print ("redis host: " + cfg['redis']['host'])
print ("redis port: " + str(cfg['redis']['port']))
print ("redis db:   " + str(cfg['redis']['db'] ))

# if os.environ.get("O11YCLOUD_INGEST_TOKEN") != None:
#     print ("Setting current token and realm in cfg ") 
#     #] = os.environ.get("O11YCLOUD_INGEST_TOKEN")
#     #cfg['signalfx'] ['realm'] = os.environ.get("O11YCLOUD_REALM")
# else:
#     print ("Splunk Observability Realm or Access Token Missing")

# exit()
# if os.environ.get("REDIS_HOST") != None:
#     cfg['redis']['host'] = os.environ.get("REDIS_HOST")
#     cfg['redis']['port'] = os.environ.get("REDIS_PORT")
#     cfg['redis']['db']   = os.environ.get("REDIS_DB")
    
usermap = {}
hostmap = {}
loggermap = {}
userDict = {}
globalIterNum = {}
globalUserDict = {}

def event_handler(msg):
    print(msg)
    try:
        key = msg["data"]
        value = r.get(key)
        if (value==None):
            print('Deleting user ' + key)
            del userDict[key]
            del usermap[key]
            del hostmap[key]
        else:
            userDict[key] = value
            if value == 'bcanary':
                print('In bcanary', usermap[key])
                usermap[key][0] = generateUID()
                hostmap[key][0] = '192.168.1.1'
                incrementGlobalIterNum(key)
            elif value == 'rollback':
                print('In rollback', usermap[key])
                usermap[key][0] = generateUID()
                hostmap[key][0] = fake.ipv4()
            elif value == 'gcanary':
                print('In gcanary', usermap[key])
                usermap[key][0] = generateUID()
                hostmap[key][0] = '192.168.1.1'
                resetGlobalIterNum(key)
    except Exception as exp:
        pass

r = redis.Redis(host=cfg['redis']['host'], port=cfg['redis']['port'], db=cfg['redis']['db'], charset="utf-8", decode_responses=True)
pubsub = r.pubsub()
pubsub.psubscribe(**{"__keyevent@0__:*": event_handler})
pubsub.run_in_thread(sleep_time=0.01)

# Create dictionary of users from Redis
keys = r.keys('*')
for key in keys:
    val = r.get(key)
    userDict[key] = val

loop = asyncio.get_event_loop()

token = cfg['signalfx']['token']
realm = cfg['signalfx']['realm']
endpoint = 'https://ingest.'+realm+'.signalfx.com'
sfx = signalfx.SignalFx().ingest(token=token, endpoint=endpoint)

def get_custom_logger(name):
    global loggermap
    if name in loggermap:
        return loggermap[name]

    filename = 'arlogs/' + 'log-' + name + '.log'
    f = open(filename, 'a+')
    f.close()
    formatter = logging.Formatter(fmt='%(asctime)s %(levelname)-8s %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
    handler = RotatingFileHandler(filename, mode='w', maxBytes=5000000, backupCount=3)
    handler.setFormatter(formatter)
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    loggermap[name] = logger
    return loggermap[name]

def incrementGlobalIterNum(key):
    global globalIterNum
    if key in globalIterNum:
        globalIterNum[key] = globalIterNum[key] + 1
    else:
        globalIterNum[key] = 1

def getGlobalIterNum(key):
    global globalIterNum
    if key in globalIterNum:
        return globalIterNum[key]
    else:
        globalIterNum[key] = 1

def resetGlobalIterNum(key):
    if key in globalIterNum:
        globalIterNum[key] = 0

def generateUID():
    x = uuid.uuid4().hex
    return str(x)[:13]

async def createNewUser():
    global globalUserDict
    while True:
        modifiedNames = {}
        global usermap
        global hostmap
        #print('Deploy Types:', userDict)

        if not globalUserDict:
            globalUserDict = userDict

        for key, value in userDict.items():
            if key not in usermap:
                usermap[key] = [generateUID(), generateUID(), generateUID()]
                hostmap[key] = [fake.ipv4(), fake.ipv4(), fake.ipv4()]
                userDict[key] = value

        await asyncio.sleep(1)

def getTrendingRequestsProcessedValue(key):
    if not key in globalIterNum:
        incrementGlobalIterNum(key)
    if globalIterNum[key] <= 10:
        return random.randint(900, 1000)
    elif globalIterNum[key] > 10:
        lowValue = round(1200 / (1.04 ** globalIterNum[key]))
        highValue = round(1200 / (1.04 ** (globalIterNum[key] - 1)))
        return random.randint(lowValue, highValue)

def getTrendingRequestsLatencyValue(key):
    global usermap
    logger = get_custom_logger(key)
    if not key in globalIterNum:
        incrementGlobalIterNum(key)
    # 25% chance of an error (and spike between 4 to 5s)
    if random.randint(0, 100) % 4 == 0:
        logger.error(
            'host={} container={} user={} {}'.format(hostmap[key][0], usermap[key][0], key, getFakeException()))
        return random.randint(4000, 5000)
    else:
        return random.randint(500, 506)

def getFakeException():
    fakeException1 = 'Exception in thread "main" java.lang.OutOfMemoryError: Java heap space\n\t'
    fakeException2 = 'at com.requests.apiHandler.ingest.capacityAllocator(CapacityAllocator.java:132)\n\t'
    fakeException3 = 'at com.requests.apiHandler.ingest.main(ingest.java:28)'
    fakeException = fakeException1 + fakeException2 + fakeException3
    return fakeException

async def printList(sfx):
    try:
        metricName = 'requests.processed'
        latencyMetric = 'requests.latency'

        global usermap

        iterationNum = 0

        fakeException = getFakeException()

        loggingIteration = 0
        while (True):
            startTime = int(round(time.time() * 1000))

            sendList = []

            while not usermap:
                print('sleeping for 1 sec..')
                await asyncio.sleep(1)

            for user, data in usermap.items():

                logger = get_custom_logger(user)

                userData1 = {}
                userData2 = {}
                userData3 = {}

                latencyData1 = {}
                latencyData2 = {}
                latencyData3 = {}

                dim1 = {}
                dim2 = {}
                dim3 = {}

                latencyDim1 = {}
                latencyDim2 = {}
                latencyDim3 = {}

                value1 = random.randint(900, 1000)
                value2 = random.randint(900, 1000)
                value3 = random.randint(900, 1000)

                latencyValue1 = random.randint(30, 50)
                latencyValue2 = random.randint(30, 50)
                latencyValue3 = random.randint(30, 50)

                bypassLogging = False

                if user in userDict:
                    if userDict[user] == 'bcanary':
                        value1 = getTrendingRequestsProcessedValue(user)
                        latencyValue1 = getTrendingRequestsLatencyValue(user)
                        dim1['canary'] = 'true'
                        latencyDim1['canary'] = 'true'
                        if getGlobalIterNum(user) >= 10:
                            logger.info('Requests Processed:{} host={} container={}'.format(value1, hostmap[user][0], usermap[user][0]))
                            logger.info('Requests Latency:{} host={} container={}'.format(latencyValue1, hostmap[user][0], usermap[user][0]))
                            bypassLogging = True
                        incrementGlobalIterNum(user)
                    elif userDict[user] == 'gcanary':
                        dim1['canary'] = 'true'
                        latencyDim1['canary'] = 'true'

                dim1.update({'containerId': usermap[user][0], 'host': hostmap[user][0], 'user': user})
                dim2.update({'containerId': usermap[user][1], 'host': hostmap[user][1], 'user': user})
                dim3.update({'containerId': usermap[user][2], 'host': hostmap[user][2], 'user': user})

                latencyDim1.update({'containerId': usermap[user][0], 'user': user, 'customer': 'Hooli'})
                latencyDim2.update({'containerId': usermap[user][1], 'user': user, 'customer': 'Acme Corp'})
                latencyDim3.update({'containerId': usermap[user][2], 'user': user, 'customer': 'Pied Piper'})

                userData1.update({'metric': metricName, 'value': value1, 'dimensions': dim1, 'timestamp': int(time.time()*1000)})
                userData2.update({'metric': metricName, 'value': value2, 'dimensions': dim2, 'timestamp': int(time.time()*1000)})
                userData3.update({'metric': metricName, 'value': value3, 'dimensions': dim3, 'timestamp': int(time.time()*1000)})

                latencyData1.update({'metric': latencyMetric, 'value': latencyValue1, 'dimensions': latencyDim1, 'timestamp': int(time.time()*1000)})
                latencyData2.update({'metric': latencyMetric, 'value': latencyValue2, 'dimensions': latencyDim2, 'timestamp': int(time.time()*1000)})
                latencyData3.update({'metric': latencyMetric, 'value': latencyValue3, 'dimensions': latencyDim3, 'timestamp': int(time.time()*1000)})
		
                sendList.extend([userData1, userData2, userData3, latencyData1, latencyData2, latencyData3])
                
                if (loggingIteration % 10) == 0 and not bypassLogging:
                    logger.info('Requests Processed:{} host={} container={}'.format(value1, dim1['host'], dim1['containerId']))
                    logger.info('Requests Latency:{} host={} container={}'.format(latencyValue1, dim1['host'], dim1['containerId']))

                    logger.info('Requests Processed:{} host={} container={}'.format(value2, dim2['host'], dim2['containerId']))
                    logger.info('Requests Latency:{} host={} container={}'.format(latencyValue2, dim2['host'], dim2['containerId']))

                    logger.info('Requests Processed:{} host={} container={}'.format(value3, dim3['host'], dim3['containerId']))
                    logger.info('Requests Latency:{} host={} container={}'.format(latencyValue3, dim3['host'], dim3['containerId']))

            loggingIteration += 1
            bypassLogging = False

            try:
                sfx.send(counters=sendList)
            except socket.timeout as err:
                logger.error('Socket timeout while sending datapoints ', err)
                logger.info('Stopping connection ...')
                sfx.stop()
                logger.info('Re-creating connection ...')
                sfx = signalfx.SignalFx().ingest(token=token, endpoint=endpoint)
            except Exception as err:
                logger.error('An exception occurred while sending datapoints ', err)
                logger.info('Stopping connection ...')
                sfx.stop()
                logger.info('Re-creating connection ...')
                sfx = signalfx.SignalFx().ingest(token=token, endpoint=endpoint)
            endTime = int(round(time.time() * 1000))
            delta = endTime - startTime

            if delta >= 1000:
                await asyncio.sleep(1)
            else:
                sleepTime = ((1000 - delta) / 1000)
                await asyncio.sleep(sleepTime)
    except:
        sfx.stop()
    finally:
        sfx.stop()

asyncio.ensure_future(createNewUser())
asyncio.ensure_future(printList(sfx))

content = loop.run_forever()
