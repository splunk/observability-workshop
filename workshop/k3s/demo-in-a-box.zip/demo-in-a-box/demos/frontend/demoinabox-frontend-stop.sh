#!/bin/bash
if [ ! -f "demoinabox-frontend-stop.sh" ]
then
  echo "You need to run the setup script in the same directory."; exit
fi

#set up env variables for O11Y
export ACCESS_TOKEN={{token}}
export REALM={{realm}}
export RUM_TOKEN={{rum_token}}
export APM_ENV={{environment}}


# remove files required for setting up  extra's
cd terraform
terraform  destroy -auto-approve