from enum import Enum

class DemoStatus(Enum):
  UP=1
  DOWN=2