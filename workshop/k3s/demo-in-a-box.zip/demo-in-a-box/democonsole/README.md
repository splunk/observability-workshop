# democonsole

To get this working, add the following to ```/etc/systemd/system/demoinabox.service```

``` ini
[Unit]
Description=demoinabox service
After=network.target
StartLimitIntervalSec=0
[Service]
Type=simple
Restart=always
RestartSec=1
User=ubuntu
Environment="PATH=/home/ubuntu/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin"
Environment="KUBECONFIG=/home/ubuntu/.kube/config"
WorkingDirectory=/home/ubuntu/demo-in-a-box/democonsole
ExecStart=flask run -p 8081 --host=0.0.0.0

[Install]
WantedBy=multi-user.target
```

And then run:

``` bash
sudo systemctl enable --now demoinabox.service
```

You can monitor the service:

``` bash
journalctl -u demoinabox.service -f
```
