import time

import streamlit as st  # type: ignore
from lib import splunk as demo  # type: ignore
from lib.ui_helpers import debug_panel, format_description, render_card_grid

st.set_page_config(
    page_title="Demo-in-a-Box",
    page_icon=":material/box:",
    layout="wide",
    menu_items={"About": f"**Demo in a Box - Version {demo.VERSION}**"},
)

demo.init_session_state()
dm = demo.get_demo_manager()

st.image("images/splunk-logo-white.png", width=130)
st.caption(demo.CAPTION)

available_demos = dm.available_demos()
current_demo = dm.current_demo()
config = dm.get_collector_config()

# Status banner showing current state
with st.container(border=True):
    col_status, col_demo, col_collector = st.columns(3)

    with col_status:
        if current_demo["name"] != "None":
            st.markdown(":green[:material/check_circle:] **Status:** Running")
        else:
            st.markdown(":gray[:material/circle:] **Status:** No demo deployed")

    with col_demo:
        if current_demo["name"] != "None":
            st.markdown(f":blue[:material/deployed_code:] **Demo:** {current_demo['name']}")
        else:
            st.markdown(":gray[:material/deployed_code:] **Demo:** None")

    with col_collector:
        if st.session_state.collector_running:
            st.markdown(":green[:material/sensors:] **Collector:** Running")
        else:
            st.markdown(":gray[:material/sensors:] **Collector:** Stopped")

status_updates = st.container()


def deploy_demo(name, deployment, custom_values, otel_version):
    status_updates.empty()

    with status_updates.status(f"Deploying `{name}` demo...", expanded=True) as status:
        # Delete previous demo if switching
        if name != current_demo["name"] and current_demo["name"] != "None":
            status.update(label=f"Deleting `{current_demo['name']}` deployment...")
            output, code = dm.delete_demo(current_demo["deployment"])
            if code == 0:
                status.code(output)
            time.sleep(3)

        # Stop collector
        status.update(label="Stopping OpenTelemetry Collector...")
        output, _ = dm.stop_collector()
        status.code(output)
        time.sleep(2)

        # Patch secrets
        status.update(label="Patching Kubernetes secrets...")
        output, _ = dm.patch_deployment_secrets(config["instance"], name)
        status.code(output)

        # Update DB before starting collector (collector uses demo name for environment)
        dm.update_current_demo(name, deployment)

        # Start collector
        status.update(label="Starting OpenTelemetry Collector...")
        output, _ = dm.start_collector(custom_values, otel_version)
        status.code(output)

        # Wait for collector
        status.update(label="Waiting for OpenTelemetry Collector to be ready...")
        output, code = dm.wait_for_collector_ready()
        status.code(output)
        if code != 0:
            status.update(label="Failed to start OpenTelemetry Collector!", state="error")
            return

        # Deploy demo
        status.update(label=f"Deploying `{name}` demonstration...")
        output, _ = dm.deploy_demo(name, deployment)
        status.code(output)
        time.sleep(2)

        status.update(label=f"Deployed `{name}` demonstration!", state="complete", expanded=False)


def stop_demo(name, deployment):
    status_updates.empty()

    with status_updates.status(f"Stopping `{name}` demo...", expanded=True) as status:
        # Stop collector
        status.update(label="Stopping OpenTelemetry Collector...")
        output, _ = dm.stop_collector()
        status.code(output)
        time.sleep(2)

        # Delete demo
        status.update(label=f"Deleting `{deployment}` deployment...")
        output, _ = dm.delete_demo(deployment)
        status.code(output)
        time.sleep(2)

        status.update(label=f"Stopped `{name}` demonstration!", state="complete", expanded=False)


def render_demo_card(demo_item):
    """Render a single demo card."""
    environment = f"{config['instance']}-{demo_item['name']}"

    # Title with running indicator
    if current_demo["name"] == demo_item["name"]:
        st.markdown(f"##### :green[:material/play_arrow:] :blue[{demo_item['use-case']}]")
    else:
        st.markdown(f"##### :blue[{demo_item['use-case']}]")

    # Environment
    st.markdown("**Deployment Environment**")
    st.code(f"{environment}", language="text")

    # OTel Collector Version
    st.markdown(f"**OpenTelemetry Collector Version**: `{demo_item['otel_version']}`")

    # Description
    with st.expander("**Description**", expanded=False):
        st.markdown(format_description(demo_item['description']))

    # Deploy/Stop button at bottom
    if current_demo["name"] == demo_item["name"]:
        st.button(
            ":material/stop_circle: Stop",
            key=demo_item["use-case"],
            type="primary",
            width="content",
            on_click=stop_demo,
            args=(demo_item["name"], demo_item["deployment"])
        )
    else:
        st.button(
            ":material/play_circle: Deploy",
            key=demo_item["use-case"],
            type="primary",
            width="content",
            on_click=deploy_demo,
            args=(demo_item["name"], demo_item["deployment"], demo_item["custom-values"], demo_item["otel_version"]),
            help=f"Deploy the **:blue[{demo_item['use-case']}]** demonstration. The environment in Observability Cloud will be named **:violet[{environment}]**."
        )


def main():
    demo_placeholder = st.empty()

    with demo_placeholder.container():
        render_card_grid(available_demos, n_cols=4, render_card_fn=render_demo_card)

    debug_panel()


pages = {
    "Splunk - Demo in a Box": [
        st.Page(main, title="Demonstrations", icon=":material/deployed_code:"),
    ],
    "OpenTelemetry Collector": [
        st.Page("pages/collector.py", title="Configuration & Logs", icon=":material/sensors:"),
    ],
    "Kubernetes": [
        st.Page("pages/status.py", title="Pod Status", icon=":material/view_in_ar:"),
    ],
    "Chaos Engineering": [
        st.Page("pages/chaos.py", title="Experiments", icon=":material/experiment:"),
    ]
}
pg = st.navigation(pages, position='top')
pg.run()
