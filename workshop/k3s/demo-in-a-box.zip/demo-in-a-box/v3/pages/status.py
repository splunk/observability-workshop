import streamlit as st  # type: ignore
from lib import splunk as demo  # type: ignore

dm = demo.DemoManager()

current = dm.current_demo()

if "collector_running" not in st.session_state:
    dm.check_status(status="status.phase=Running")

if "pod_name" not in st.session_state:
    st.session_state.pod_name = False

# Auto-select first running pod on page load
if "auto_selected" not in st.session_state:
    st.session_state.auto_selected = False

def show_logs(pod_name):
    st.session_state.pod_name = pod_name

# Show current demo header
if current["name"] != "None":
    st.subheader(f":blue[Deployment:] {current['name']}", anchor=False, help="Current demo deployment.")
    st.divider()

    col1, col2 = st.columns([1, 2])

    with col1:
        st.markdown("#### :blue[Pod Status]")
        with st.container(border=True, height=700):
            demo_dict = dm.demo_status()

            if not demo_dict:
                st.warning("**No pods found for the current demo.**")
                st.caption("Pods may still be starting up. Try refreshing the page.")
            else:
                # Auto-select first running pod
                if not st.session_state.auto_selected:
                    for pod, state in demo_dict.items():
                        if state == "Running":
                            st.session_state.pod_name = pod
                            st.session_state.auto_selected = True
                            break

                for pod, state in demo_dict.items():
                    # Determine if this pod is selected
                    is_selected = st.session_state.pod_name == pod

                    # Pod name with status icon
                    if state == "Running":
                        status_icon = ":green[:material/check_circle:]"
                        state_text_inactive = f":green[{state}]"
                    elif state in ["Pending", "ContainerCreating"]:
                        status_icon = ":orange[:material/pending:]"
                        state_text_inactive = f":orange[{state}]"
                    elif state in ["Error", "CrashLoopBackOff", "Failed"]:
                        status_icon = ":red[:material/error:]"
                        state_text_inactive = f":red[{state}]"
                    else:
                        status_icon = ":gray[:material/help:]"
                        state_text_inactive = f":gray[{state}]"

                    # Use white text when selected (primary button), colored text when not selected
                    state_text = state if is_selected else state_text_inactive

                    # Create card-like container for each pod
                    with st.container(border=True):
                        col_icon, col_pod, col_status = st.columns([0.5, 4, 3])

                        with col_icon:
                            st.markdown(f"{status_icon}")

                        with col_pod:
                            # Left-aligned pod name
                            st.markdown(f"**{pod}**")

                        with col_status:
                            # Clickable status badge with color-coded text
                            st.button(
                                state_text,
                                key=f"select_{pod}",
                                type="primary" if is_selected else "secondary",
                                on_click=show_logs,
                                args=(pod,)
                            )

    with col2:
        #st.markdown("#### :blue[Pod Logs]")
        st.markdown(f"#### :blue[Logs for:] {st.session_state.pod_name}")
        rhs = st.container(border=True, height=700)
        log_container = rhs.container(border=False, height=600)

        if st.session_state.pod_name is not False:
            logs, code = dm.get_pod_logs(st.session_state.pod_name)

            if code == 0:
                log_container.code(logs, language="log")
            else:
                log_container.error(logs)

            rhs.button("Refresh logs", type="primary", on_click=show_logs, args=(st.session_state.pod_name,))

else:
    st.info("No demo currently deployed. Deploy a demo from the Demos page to view pod status.")

if st.secrets.debug:
    with st.container(border=True):
        st.json(st.session_state)
