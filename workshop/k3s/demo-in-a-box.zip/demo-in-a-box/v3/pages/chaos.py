import time

import streamlit as st  # type: ignore
from lib import splunk as demo  # type: ignore

if "helm_repo_updated" not in st.session_state:
    st.session_state.helm_repo_updated = False

demo.page_header("Chaos Mesh Experiments")

dm = demo.DemoManager()

available_experiments = dm.available_experiments()
current_demo = dm.current_demo()
#current_experiment = dm.current_experiment()

def deploy_chaos(name, experiment):
    status_updates.empty()

    with status_updates.status(
        f"{name}", expanded=True
    ) as status:
        #st.write(f"Deployment: {deployment}")
        #st.write(f"Current Demo Name: {current_demo['name']}")
        #st.write(f"Current Demo Deployment: {current_demo['deployment']}")
        chaos = dm.deploy_chaos(experiment)
        status.code(chaos[0])
        time.sleep(2)
        status.update(label=f"{name}", state="complete", expanded=False)

status_updates = st.container()

chaos_placeholder = st.empty()

n_cols = 3
n_rows = 1 + len(available_experiments) // int(n_cols)
rows = [st.container() for _ in range(n_rows)]
cols_per_row = [r.columns(n_cols) for r in rows]
cols = [column for row in cols_per_row for column in row]

count = 0

with chaos_placeholder.container():
    for e in available_experiments:
        with cols[count]:
            if e['deployment'] == current_demo['deployment'] or e['deployment'] == 'ALL':
                with st.container(border=True):
                    st.write(f":blue[**{e['name']}**]")
                    st.html("<style> .my_divider { margin: 0.2em 0px !important; }</style><hr class='my_divider'>")
                    st.caption(f"Deployment:  \n**:violet[{e['deployment']}]**")
                    st.html("<style> .my_divider { margin: 0.2em 0px !important; }</style><hr class='my_divider'>")

                    with st.container(height=180, border=False):
                        st.caption(f":orange[{e['description']}]")
                        st.button(f"Deploy", key=e['experiment'], help=f"Deploy the **:blue[{e['name']}]**.", on_click=deploy_chaos, args=(e["name"], e["experiment"], ))

                count += 1

if st.secrets.debug:
    st.json(st.session_state)