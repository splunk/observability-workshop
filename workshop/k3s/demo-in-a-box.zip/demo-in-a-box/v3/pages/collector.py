import time

import streamlit as st  # type: ignore
from lib import splunk as demo  # type: ignore

if "helm_repo_updated" not in st.session_state:
    st.session_state.helm_repo_updated = False

#demo.page_header("Manage OpenTelemetry Collector")

dm = demo.DemoManager()

current = dm.current_demo()

if "current_demo_is_none" not in st.session_state:
    st.session_state.current_demo_is_none = False

st.session_state.current_demo_is_none = True if current["name"] == "None" else False

if "disable_form" not in st.session_state:
    st.session_state["disable_form"] = True

if "selected_pod" not in st.session_state:
    st.session_state.selected_pod = None


def enable_form():
    st.session_state["disable_form"] = False


def click_button():
    if not st.session_state.collector_running:
        status_updates.empty()
        with status_updates.status(
            "Starting the collector...", expanded=True
        ) as status:
            status.write("Running `helm install` command...")
            start_collector, returncode = dm.start_collector()
            status.code(start_collector)
            if returncode != 0:
                status.update(label="Error starting collector", state="error", expanded=False)
            else:
                status.update(label="Collector started", state="complete", expanded=False)
            time.sleep(5)
            dm.check_status("status.phase=Running")

    elif st.session_state.collector_running:
        status_updates.empty()
        with status_updates.status(
            "Stopping the collector...", expanded=True
        ) as status:
            status.write("Running `helm delete` command...")
            status.code(dm.stop_collector()[0])
            time.sleep(5)
            dm.check_status("status.phase=Running")
            status.update(label="Collector stopped", state="complete", expanded=False)


st.subheader("OpenTelemetry Collector Management")
st.divider()

col1, col2 = st.columns([1, 3])

with col1:
    st.markdown("#### :blue[Configuration]")

    values = dm.get_collector_config()

    with st.container(border=True):
        with st.form("config_form"):
            st.session_state["valid_inputs_received"] = False
            instance = st.text_input(f"**:grey[Instance Name]**", value=values[7], disabled=True)
            realm = st.text_input(
                "**Splunk Observability Cloud Realm**",
                value=values[1],
                disabled=st.session_state["disable_form"],
            )
            ingest_token = st.text_input(
                "**Splunk Observability Cloud Ingest Token**",
                type="password",
                value=values[2],
                disabled=st.session_state["disable_form"],
            )
            rum_token = st.text_input(
                "**Splunk Observability Cloud RUM Token**",
                type="password",
                value=values[3],
                disabled=st.session_state["disable_form"],
            )
            hec_url = st.text_input(
                "**Splunk Cloud HEC URL**",
                value=values[4],
                placeholder="Splunk HEC URL",
                disabled=st.session_state["disable_form"],
            )
            hec_token = st.text_input(
                "**Splunk Cloud HEC Token**",
                type="password",
                value=values[5],
                placeholder="Splunk HEC Token",
                disabled=st.session_state["disable_form"],
            )
            splunk_index = st.text_input(
                "**Splunk Cloud Index**",
                value=values[6],
                placeholder="Splunk Index",
                disabled=st.session_state["disable_form"],
            )

            if st.session_state["disable_form"] is True:
                update_form = st.form_submit_button(":material/edit: Update", on_click=enable_form, disabled=st.session_state.collector_running)

            if st.session_state["disable_form"] is False:
                save_config = st.form_submit_button(label=":material/save: Save", type="primary")

                if save_config:
                    if (
                        realm == "" or realm is None
                        or ingest_token == "" or ingest_token is None
                        or rum_token == "" or rum_token is None
                    ):
                        st.error("All fields are required.")
                        st.stop()
                    else:
                        st.session_state["valid_inputs_received"] = True

                    st.session_state["disable_form"] = True

                    sql_result = dm.save_collector_config(
                        realm,
                        ingest_token,
                        rum_token,
                        hec_url,
                        hec_token,
                        splunk_index,
                        instance
                    )

                    st.toast(sql_result[0])
                    time.sleep(2)
                    st.rerun()

with col2:
    st.markdown("#### :blue[Console]")

    with st.container(border=True):
        toggle_text = "Start" if not st.session_state.collector_running else "Stop"
        toggle_color = "green" if not st.session_state.collector_running else "red"
        st.toggle(
            f"**:{toggle_color}[{toggle_text}] the OpenTelemetry Collector**",
            on_change=click_button,
            value=st.session_state.collector_running, disabled=st.session_state.current_demo_is_none
        )
        status = dm.check_status("Running")

        if not status.empty:
            # Use st.dataframe with on_select to capture row selection
            event = st.dataframe(
                status,
                use_container_width=True,
                hide_index=True,
                on_select="rerun",
                selection_mode="single-row"
            )

            # Update selected pod based on selection
            if event.selection.rows:
                selected_row_index = event.selection.rows[0]
                st.session_state.selected_pod = status.iloc[selected_row_index]["Name"]
            elif st.session_state.selected_pod is None and not status.empty:
                # Auto-select first pod if none selected
                st.session_state.selected_pod = status.iloc[0]["Name"]

        if st.session_state.collector_running and st.session_state.selected_pod:
            st.markdown(f"**Logs for:** `{st.session_state.selected_pod}`")
            with st.container(border=False, height=320):
                logs, code = dm.get_pod_logs(st.session_state.selected_pod)
                if code == 0:
                    st.code(logs, language="log")
                else:
                    st.error(logs)

            refresh = st.button(":material/refresh: Refresh Logs", type="primary")
            if refresh:
                logs, code = dm.get_pod_logs(st.session_state.selected_pod)

st.divider()
st.markdown("#### :blue[Status]")
status_updates = st.container(border=False)

if st.session_state.helm_repo_updated is False:
    status = st.toast("Updating Helm repository...")
    result, retuncode = dm.update_helm_repo()
    if retuncode == 0:
        st.session_state.helm_repo_updated = True
        status.toast("Helm repository updated successfully!")
    else:
        st.toast(result)

if st.secrets.debug:
    with st.container(border=True):
        st.json(st.session_state)
