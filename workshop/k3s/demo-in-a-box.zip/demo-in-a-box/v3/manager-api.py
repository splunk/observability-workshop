from flask import Flask, request, jsonify  # type: ignore
from lib import splunk as demo  # type: ignore
from waitress import serve  # type: ignore

dm = demo.DemoManager()

app = Flask(__name__)


@app.route("/", methods=["GET"])
def index():
    return f"Demo-in-a-Box v{demo.VERSION} - OK"


def validate_form_data(data):
    errors = {}

    required_fields = ["realm", "ingest_token", "instance"]

    for field in required_fields:
        if field not in data:
            errors[field] = f"{field.capitalize()} is required"
            
    return errors


@app.route("/saveConfig", methods=["POST"])
def saveConfig():
    try:
        form_data = request.form
        errors = validate_form_data(form_data)

        if errors:
            return jsonify(errors), 400

        realm = form_data.get("realm")
        ingest_token = form_data.get("ingest_token")
        rum_token = form_data.get("rum_token")
        instance = form_data.get("instance")
        hec_url = form_data.get("hec_url")
        hec_token = form_data.get("hec_token")
        splunk_index = form_data.get("splunk_index", "main")

        # If HEC URL is not provided, construct default.
        if not hec_url:
            hec_url = f"https://ingest.{realm}.signalfx.com/v1/log"
            hec_token = ingest_token

        # Save the collector configuration
        sql = dm.save_collector_config(
            realm=realm,
            ingest_token=ingest_token,
            rum_token=rum_token,
            hec_url=hec_url,
            hec_token=hec_token,
            splunk_index=splunk_index,
            instance=instance,
        )

        return jsonify({"message": "Configuration saved successfully", "sql": sql}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    serve(app, host="0.0.0.0", port=8082)
