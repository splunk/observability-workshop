"""Shared UI helper functions for Streamlit pages."""

import streamlit as st  # type: ignore


def get_status_color(status):
    """Return color name for pod status."""
    if status == "Running":
        return "green"
    elif status in ["Pending", "ContainerCreating"]:
        return "orange"
    elif status in ["Error", "CrashLoopBackOff", "Failed", "ImagePullBackOff"]:
        return "red"
    return "gray"


def render_pod_grid(pods, session_key, cols=3, truncate_len=20, show_status_color=True):
    """
    Render a grid of pod buttons with selection state.

    Args:
        pods: List of tuples (key, display_name, status) or list of dicts with 'key', 'name', 'status'
        session_key: Session state key to track selected pod
        cols: Number of columns in the grid
        truncate_len: Max length for display name before truncating
        show_status_color: Whether to color-code by status (False = always green)

    Returns:
        True if a pod was clicked (triggers rerun), False otherwise
    """
    if not pods:
        return False

    # Normalize input to list of dicts
    normalized = []
    for pod in pods:
        if isinstance(pod, tuple):
            normalized.append({"key": pod[0], "name": pod[1], "status": pod[2]})
        else:
            normalized.append(pod)

    # Auto-select first pod if none selected
    if not st.session_state.get(session_key):
        # Prefer first running pod if show_status_color is True
        if show_status_color:
            for pod in normalized:
                if pod["status"] == "Running":
                    st.session_state[session_key] = pod["key"]
                    break
        if not st.session_state.get(session_key):
            st.session_state[session_key] = normalized[0]["key"]

    clicked = False
    columns = st.columns(cols)

    for idx, pod in enumerate(normalized):
        with columns[idx % cols]:
            is_selected = st.session_state.get(session_key) == pod["key"]

            # Truncate display name
            display_name = pod["name"]
            if len(display_name) > truncate_len:
                display_name = display_name[:truncate_len - 3] + "..."

            # Determine color
            if show_status_color:
                color = get_status_color(pod["status"])
            else:
                color = "green"

            # Format label with color (unless selected - then plain)
            label = display_name if is_selected else f":{color}[{display_name}]"

            if st.button(
                label,
                key=f"pod_{pod['key']}",
                type="primary" if is_selected else "secondary",
                use_container_width=True,
                help=f"{pod['name']}\nStatus: {pod['status']}"
            ):
                st.session_state[session_key] = pod["key"]
                clicked = True

    return clicked


def format_description(text):
    """Convert newlines to markdown line breaks for proper rendering."""
    return text.replace('\n', '  \n')


def debug_panel():
    """Display session state in an expander when debug mode is enabled."""
    if st.secrets.debug:
        st.expander("Debug").json(st.session_state)


def render_card_grid(items, n_cols, render_card_fn):
    """
    Render items in a card grid layout.

    Args:
        items: List of items to render
        n_cols: Number of columns
        render_card_fn: Function that takes (item, col_context) and renders card content
    """
    rows = [items[i:i + n_cols] for i in range(0, len(items), n_cols)]

    for row in rows:
        cols = st.columns(n_cols, gap="medium")
        for idx, item in enumerate(row):
            with cols[idx]:
                with st.container(border=True):
                    render_card_fn(item)
