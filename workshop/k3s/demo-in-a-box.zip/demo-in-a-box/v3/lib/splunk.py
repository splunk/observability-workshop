import json
import pathlib
import sqlite3
import subprocess
import time
from datetime import datetime

import streamlit as st  # type: ignore
import yaml  # type: ignore
from kubernetes import client, config  # type: ignore

year = datetime.now().year

VERSION = st.secrets.version
CAPTION = f"© {year} Splunk Inc. All rights reserved. **Demo-in-a-Box v{VERSION}**"

DB_PATH = "manager.sqlite3"


def init_session_state():
    """Initialize all session state variables with defaults."""
    defaults = {
        "helm_repo_updated": False,
        "collector_running": False,
        "pod_name": None,
        "selected_pod": None,
        "disable_form": True,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def _init_database():
    """Initialize database tables if they don't exist."""
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute(
        "CREATE TABLE IF NOT EXISTS collector(id integer PRIMARY KEY, realm, ingest_token, rum_token, hec_url, hec_token, splunk_index, instance)"
    )
    cur.execute(
        "CREATE TABLE IF NOT EXISTS current_demo(id integer PRIMARY KEY, name, deployment, experiment)"
    )
    cur.execute(
        "INSERT OR IGNORE INTO collector VALUES(1, 'realm', 'ingest_token', 'rum_token', 'hec_url', 'hec_token', 'splunk_index', 'instance')"
    )
    cur.execute("INSERT OR IGNORE INTO current_demo VALUES(1, 'None', 'None', 'None')")
    con.commit()
    con.close()


# Initialize database on module load
_init_database()


class DemoManager:
    """Manages demo deployments, K8s operations, and collector configuration."""

    _kube_config_loaded = False

    @classmethod
    def _ensure_kube_config(cls):
        """Load kube config only once across all instances."""
        if not cls._kube_config_loaded:
            config.load_kube_config()
            cls._kube_config_loaded = True

    def __init__(self):
        DemoManager._ensure_kube_config()
        self.v1 = client.CoreV1Api()
        self._update_collector_status()

    def _get_db(self):
        """Get a database connection with row factory."""
        con = sqlite3.connect(DB_PATH)
        con.row_factory = sqlite3.Row
        return con

    def _execute_query(self, query, params=None, commit=False):
        """Execute a SQL query and return the cursor result."""
        con = self._get_db()
        cur = con.cursor()
        try:
            cur.execute(query, params or ())
            if commit:
                con.commit()
            result = cur.fetchall()
            return result
        finally:
            con.close()

    def _execute_update(self, query, params=None):
        """Execute a SQL update/insert and commit."""
        con = self._get_db()
        cur = con.cursor()
        try:
            cur.execute(query, params or ())
            con.commit()
        finally:
            con.close()

    def _load_yaml_docs(self, filename):
        """Load all YAML documents from a file."""
        with open(f"{pathlib.Path().resolve()}/{filename}", "r") as f:
            return list(yaml.safe_load_all(f))

    def _run_command(self, args):
        """Run a subprocess command and return (output, return_code)."""
        try:
            result = subprocess.run(args, check=True, text=True, capture_output=True)
            return result.stdout, result.returncode
        except subprocess.CalledProcessError as e:
            return e.stderr, e.returncode

    def _run_kubectl(self, *args):
        """Run a kubectl command and return (output, return_code)."""
        return self._run_command(["kubectl", *args])

    def _patch_k8s_secret(self, secret_name, string_data):
        """Patch a Kubernetes secret with the given data."""
        payload = json.dumps({"stringData": string_data})
        return self._run_kubectl("patch", "secret", secret_name, f"-p={payload}")

    def _update_collector_status(self):
        """Update session state with current collector running status."""
        st.session_state.collector_running = bool(self.get_collector_pods())

    def available_demos(self):
        return self._load_yaml_docs("use-cases.yaml")

    def available_experiments(self):
        return self._load_yaml_docs("chaos-mesh.yaml")

    def update_helm_repo(self):
        if st.session_state.helm_repo_updated is False:
            return self._run_command(["helm", "repo", "update"])
        return "Helm repo already updated!", 0

    def demo_status(self):
        """Get status of all demo pods across all namespaces.

        Excludes:
        - kube-system and chaos-mesh namespaces
        - Pods with names starting with 'splunk-otel-collector'

        Returns dict with key = "namespace/pod_name", value = status
        """
        demo_dict = {}
        pods = self.v1.list_pod_for_all_namespaces()

        for pod in pods.items:
            namespace = pod.metadata.namespace
            pod_name = pod.metadata.name

            # Skip system namespaces
            if namespace in ["kube-system", "chaos-mesh"]:
                continue

            # Skip collector pods
            if pod_name.startswith("splunk-otel-collector"):
                continue

            # Determine pod status
            status = pod.status.phase

            # Check container status for more detail
            if pod.status.container_statuses:
                container_status = pod.status.container_statuses[0]

                if container_status.state.waiting:
                    status = container_status.state.waiting.reason
                elif container_status.state.running:
                    status = "Running"

            demo_dict[f"{namespace}/{pod_name}"] = status

        return demo_dict

    def get_collector_pods(self):
        """Get list of running collector pods as list of dicts."""
        pods = []
        all_pods = self.v1.list_namespaced_pod(namespace="default")

        for pod in all_pods.items:
            if pod.status.phase == "Running":
                if "splunk-otel-collector" in pod.metadata.labels.values():
                    pods.append({
                        "key": pod.metadata.name,
                        "name": pod.metadata.name.replace("splunk-otel-collector-", ""),
                        "status": "Running",
                        "ip": pod.status.pod_ip
                    })

        return pods

    def get_collector_config(self):
        result = self._execute_query("SELECT * FROM collector WHERE id = 1")
        return result[0] if result else None

    def save_collector_config(
        self, realm, ingest_token, rum_token, hec_url, hec_token, splunk_index, instance
    ):
        try:
            self._execute_update(
                "UPDATE collector SET realm = ?, ingest_token = ?, rum_token = ?, hec_url = ?, hec_token = ?, splunk_index = ?, instance = ? WHERE id = 1",
                (realm, ingest_token, rum_token, hec_url, hec_token, splunk_index, instance),
            )
            self.patch_collector_secrets(realm, rum_token)
            return "OpenTelemetry configuration saved!", 200
        except Exception:
            return "Failed to save configuration", 500

    def start_collector(self, custom_values_file="values.yaml", otel_version="0.141.0"):
        db_config = self.get_collector_config()
        current = self.current_demo()

        values_path = f"{pathlib.Path().resolve()}/opentelemetry-collector/{custom_values_file}"

        try:
            result = subprocess.run(
                [
                    "helm",
                    "install",
                    "splunk-otel-collector",
                    "--version",
                    otel_version,
                    "--set=operatorcrds.install=true",
                    "--set=operator.enabled=true",
                    f"--set=splunkObservability.realm={db_config['realm']}",
                    f"--set=splunkObservability.accessToken={db_config['ingest_token']}",
                    f"--set=clusterName={db_config['instance']}-k3d-cluster",
                    f"--set=environment={db_config['instance']}-{current['name']}",
                    "--set=splunkObservability.profilingEnabled=true",
                    f"--set=splunkPlatform.endpoint={db_config['hec_url']}",
                    f"--set=splunkPlatform.token={db_config['hec_token']}",
                    f"--set=splunkPlatform.index={db_config['splunk_index']}",
                    "splunk-otel-collector-chart/splunk-otel-collector",
                    "-f",
                    values_path,
                ],
                check=True,
                text=True,
                capture_output=True,
            )
            return result.stdout, result.returncode
        except subprocess.CalledProcessError as e:
            return e.stderr, e.returncode

    def wait_for_collector_ready(self, max_wait_time=120, poll_interval=5):
        """
        Wait for ALL collector pods (operator + collector) to be in Running state with all containers ready.
        Returns: (message, return_code) - return_code is 0 on success, 1 on timeout
        """
        elapsed = 0

        while elapsed < max_wait_time:
            pods = self.v1.list_namespaced_pod(namespace="default")
            collector_pods = []
            all_pods_ready = True

            # Find all collector-related pods
            for pod in pods.items:
                if "splunk-otel-collector" in pod.metadata.labels.values():
                    collector_pods.append(pod)

            # Check if we found any collector pods
            if not collector_pods:
                all_pods_ready = False
            else:
                # Check each collector pod
                for pod in collector_pods:
                    # Check if pod is running
                    if pod.status.phase != "Running":
                        all_pods_ready = False
                        break

                    # Check if all containers in this pod are ready
                    if pod.status.container_statuses:
                        ready_containers = sum(1 for cs in pod.status.container_statuses if cs.ready)
                        total_containers = len(pod.status.container_statuses)

                        if ready_containers != total_containers:
                            all_pods_ready = False
                            break
                    else:
                        all_pods_ready = False
                        break

            # If all pods are ready, return success
            if all_pods_ready and len(collector_pods) > 0:
                st.session_state.collector_running = True
                return f"All {len(collector_pods)} collector pod(s) are running and ready! (waited {elapsed}s)", 0

            # Wait and try again
            time.sleep(poll_interval)
            elapsed += poll_interval

        # Timeout - collector didn't start
        st.session_state.collector_running = False
        return f"Timeout: Not all collector pods reached fully ready state within {max_wait_time} seconds", 1

    def stop_collector(self):
        return self._run_command(["helm", "delete", "splunk-otel-collector", "-n", "default"])

    def get_pod_logs(self, pod_name, namespace="default"):
        return self._run_kubectl("logs", pod_name, "-n", namespace, "--tail=150")

    def patch_deployment_secrets(self, instance, current_demo):
        env = f"{instance}-{current_demo}"
        return self._patch_k8s_secret("workshop-secret", {
            "app": f"{env}-store",
            "deployment": f"deployment.environment={env}",
            "env": env,
            "instance": env
        })

    def patch_collector_secrets(self, realm, rum_token):
        return self._patch_k8s_secret("workshop-secret", {
            "realm": realm,
            "rum_token": rum_token
        })

    def deploy_chaos(self, experiment):
        experiment_file = f"{pathlib.Path().resolve()}/chaos-mesh/{experiment}.yaml"
        return self._run_kubectl("apply", "-f", experiment_file)

    def deploy_demo(self, name, deployment):
        deployment_file = f"{pathlib.Path().resolve()}/deployments/{deployment}.yaml"
        output, code = self._run_kubectl("apply", "-f", deployment_file)

        if code == 0:
            self._execute_update(
                "UPDATE current_demo SET name = ?, deployment = ? WHERE id = 1",
                (name, deployment),
            )

        return output, code

    def delete_demo(self, deployment):
        deployment_file = f"{pathlib.Path().resolve()}/deployments/{deployment}.yaml"
        output, code = self._run_kubectl("delete", "-f", deployment_file)

        if code == 0:
            self._execute_update("UPDATE current_demo SET name = 'None', deployment = 'None' WHERE id = 1")

        return output, code

    def current_demo(self):
        result = self._execute_query("SELECT name, deployment FROM current_demo WHERE id = 1")
        return result[0] if result else {"name": "None", "deployment": "None"}

    def update_current_demo(self, name, deployment):
        """Update current demo state. Called before collector starts to set environment."""
        self._execute_update(
            "UPDATE current_demo SET name = ?, deployment = ? WHERE id = 1",
            (name, deployment),
        )


@st.cache_resource
def get_demo_manager():
    """Get a cached DemoManager instance (singleton per Streamlit session)."""
    return DemoManager()
