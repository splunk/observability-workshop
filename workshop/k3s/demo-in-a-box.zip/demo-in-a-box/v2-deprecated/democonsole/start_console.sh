#!/bin/bash
if [ ! -f "start_console.sh" ]
then
  echo "You need to run the startup script in the same directory."; exit
fi

export FLASK_APP=app.py
source venv/bin/activate
flask run -p 8081 --host=0.0.0.0

# NOTE: If you are running this with systemd you should use the
#       example written in README.md
