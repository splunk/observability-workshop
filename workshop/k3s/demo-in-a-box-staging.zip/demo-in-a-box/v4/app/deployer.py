from __future__ import annotations

import logging
import os
import uuid
import yaml
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Awaitable

from jinja2 import Template
from sqlalchemy import select

from db import async_session, CollectorConfig, DeploymentState, ChaosState
from k8s import (
    ensure_namespace,
    apply_manifest,
    apply_manifest_content,
    delete_manifest,
    delete_manifest_content,
    helm_repo_add,
    helm_install_collector,
    helm_uninstall,
    wait_for_pods_ready,
    wait_for_pods_terminated,
    delete_namespace,
    delete_webhook_configs,
)

logger = logging.getLogger("demo-in-a-box.deployer")

BASE_DIR = Path(__file__).parent.parent
DEMOS_DIR = BASE_DIR / "demos"
CHAOS_DIR = BASE_DIR / "chaos"
COLLECTOR_DIR = BASE_DIR / "collector"
COLLECTOR_NAMESPACE = "splunk"

EventCallback = Callable[[str, str, str], Awaitable[None]]


async def _noop_emit(step, status, msg): pass


async def _delete_chaos_manifest(exp: dict, namespace: str) -> None:
    manifest_rel = exp.get("manifest")
    if not manifest_rel or not namespace:
        return
    manifest_path = str(BASE_DIR / manifest_rel)
    if not os.path.exists(manifest_path):
        return
    with open(manifest_path) as f:
        rendered = Template(f.read()).render(namespace=namespace)
    await delete_manifest_content(rendered)


_yaml_cache: dict[Path, tuple[float, list[dict]]] = {}


def _load_yaml_dir(directory: Path) -> list[dict]:
    if not directory.exists():
        return []

    mtime = max((f.stat().st_mtime for f in directory.glob("*.yaml")), default=0)
    cached = _yaml_cache.get(directory)
    if cached and cached[0] == mtime:
        return [item.copy() for item in cached[1]]

    items = []
    for f in sorted(directory.glob("*.yaml")):
        try:
            with open(f) as fh:
                item = yaml.safe_load(fh)
                item["id"] = f.stem
                item["yaml_file"] = str(f)
                items.append(item)
        except Exception as e:
            logger.error(f"Failed to load {f}: {e}")

    _yaml_cache[directory] = (mtime, items)
    return [item.copy() for item in items]


def load_demos() -> list[dict]:
    return _load_yaml_dir(DEMOS_DIR)


def load_chaos_experiments() -> list[dict]:
    return _load_yaml_dir(CHAOS_DIR)


def _get_by_id(loader, item_id: str) -> dict | None:
    return next((i for i in loader() if i["id"] == item_id), None)


def get_demo_by_id(demo_id: str) -> dict | None:
    return _get_by_id(load_demos, demo_id)


def get_chaos_by_id(chaos_id: str) -> dict | None:
    return _get_by_id(load_chaos_experiments, chaos_id)


async def get_collector_config() -> dict:
    async with async_session() as session:
        config = await session.get(CollectorConfig, "default")
        return config.to_dict() if config else {}


async def get_deployment_state() -> dict:
    async with async_session() as session:
        state = await session.get(DeploymentState, "active")
        return state.to_dict() if state else {"status": "idle"}


async def render_collector_values(demo: dict, config: dict) -> str | None:
    values_path = demo.get("collector", {}).get("values")
    full_path = (BASE_DIR / values_path) if values_path else None
    if not full_path or not full_path.exists():
        full_path = COLLECTOR_DIR / "values-template.yaml"
    if not full_path.exists():
        return None
    with open(full_path) as f:
        rendered = Template(f.read()).render(**config, demo=demo)
    tmp = tempfile.NamedTemporaryFile(mode="w", suffix="-values.yaml", delete=False, dir="/tmp")
    tmp.write(rendered)
    tmp.close()
    return tmp.name


def build_workshop_secret(demo: dict, config: dict, namespace: str) -> str:
    instance_name = config.get("instance", "demo")
    demo_id = demo.get("id", namespace)
    env_name = demo.get("environment") or f"{instance_name}-{demo_id}"
    app_suffix = demo.get("app_suffix", "app")
    app_name = f"{env_name}-{app_suffix}"
    url = demo.get("url", "http://frontend:80")

    return yaml.dump({
        "apiVersion": "v1",
        "kind": "Secret",
        "metadata": {
            "name": "workshop-secret",
            "namespace": namespace,
        },
        "type": "Opaque",
        "stringData": {
            "instance": env_name,
            "env": env_name,
            "app": app_name,
            "deployment": f"deployment.environment={env_name}",
            "ingest_token": config.get("ingest_token", ""),
            "api_token": config.get("api_token", ""),
            "realm": config.get("realm", "us1"),
            "rum_token": config.get("rum_token", ""),
            "url": url,
        },
    }, default_flow_style=False)


async def deploy_demo(demo_id: str, emit: EventCallback = None):
    emit = emit or _noop_emit

    demo = get_demo_by_id(demo_id)
    if not demo:
        return False, f"Demo '{demo_id}' not found"

    config_dict = await get_collector_config()
    namespace = demo.get("namespace", "default")
    extra_namespaces = demo.get("extra_namespaces", [])
    manifest = demo.get("manifest")
    collector_cfg = demo.get("collector", {})
    collector_version = collector_cfg.get("version")

    steps_completed = []
    values_file = None

    try:
        await emit("validate_config", "running", "Validating collector configuration...")
        if not config_dict.get("ingest_token"):
            raise DeployError("Collector access token not configured. Go to Settings to configure.")
        if not config_dict.get("realm"):
            raise DeployError("Collector realm not configured. Go to Settings to configure.")
        await emit("validate_config", "done", "Configuration valid")

        await emit("create_collector_ns", "running", f"Creating namespace '{COLLECTOR_NAMESPACE}'...")
        ok, msg = await ensure_namespace(COLLECTOR_NAMESPACE)
        if not ok:
            raise DeployError(msg)
        steps_completed.append("collector_namespace")
        await emit("create_collector_ns", "done", msg)

        all_demo_ns = [namespace] + extra_namespaces
        ns_list = ", ".join(all_demo_ns)
        await emit("create_namespace", "running", f"Creating namespace(s): {ns_list}...")
        for ns in all_demo_ns:
            ok, msg = await ensure_namespace(ns)
            if not ok:
                raise DeployError(msg)
        steps_completed.append("namespace")
        await emit("create_namespace", "done", f"Namespace(s) ready: {ns_list}")

        await emit("deploy_secret", "running", "Deploying workshop secret...")
        for ns in all_demo_ns + [COLLECTOR_NAMESPACE]:
            secret_yaml = build_workshop_secret(demo, config_dict, ns)
            ok, msg = await apply_manifest_content(secret_yaml, ns)
            if not ok:
                raise DeployError(msg)
        steps_completed.append("secret")
        await emit("deploy_secret", "done", "Workshop secret deployed to all namespaces")

        await emit("helm_repo", "running", "Adding Splunk OTel Collector Helm repo...")
        ok, msg = await helm_repo_add()
        if not ok:
            raise DeployError(msg)
        await emit("helm_repo", "done", msg)

        await emit("render_values", "running", "Rendering collector values...")
        values_file = await render_collector_values(demo, config_dict)
        await emit("render_values", "done", "Collector values rendered")

        await emit("deploy_collector", "running", f"Installing Splunk OTel Collector into '{COLLECTOR_NAMESPACE}'...")
        instance_name = config_dict.get("instance", "demo")
        env_tag = demo.get("environment") or f"{instance_name}-{demo_id}"

        ok, msg = await helm_install_collector(
            release_name="splunk-otel-collector",
            realm=config_dict.get("realm", "us1"),
            ingest_token=config_dict.get("ingest_token", ""),
            instance=instance_name,
            hec_url=config_dict.get("hec_url", ""),
            hec_token=config_dict.get("hec_token", ""),
            splunk_index=config_dict.get("splunk_index", "o11y-demo-eu"),
            environment=env_tag,
            values_file=values_file,
            namespace=COLLECTOR_NAMESPACE,
            version=collector_version,
        )
        if not ok:
            raise DeployError(msg)
        steps_completed.append("collector")
        await emit("deploy_collector", "done", "Collector installed")

        await emit("deploy_app", "running", f"Deploying {demo.get('name', demo_id)}...")
        manifest_path = str(BASE_DIR / manifest) if manifest else None
        if manifest_path and not os.path.exists(manifest_path):
            raise DeployError(f"Manifest not found: {manifest}")
        if manifest_path:
            # If the manifest defines its own namespaces, don't pass -n (it would conflict)
            apply_ns = None if extra_namespaces else namespace
            ok, msg = await apply_manifest(manifest_path, apply_ns)
            if not ok:
                raise DeployError(msg)
            steps_completed.append("app")
            await emit("deploy_app", "done", f"{demo.get('name', demo_id)} deployed")
        else:
            await emit("deploy_app", "done", "No application manifest (collector-only deploy)")

        await emit("wait_pods", "running", "Waiting for pods to become ready...")
        ok, msg = await wait_for_pods_ready(COLLECTOR_NAMESPACE, timeout=300)
        if not ok:
            raise DeployError(f"Collector pods: {msg}")
        for ns in all_demo_ns:
            ok, msg = await wait_for_pods_ready(ns, timeout=420, allow_empty=True)
            if not ok:
                raise DeployError(f"Pods in {ns}: {msg}")
        await emit("wait_pods", "done", "All pods ready")

        await emit("complete", "done", f"Deployment of {demo.get('name', demo_id)} complete!")

        async with async_session() as session:
            state = await session.get(DeploymentState, "active")
            state.status = "running"
            state.deployed_at = datetime.now(timezone.utc)
            state.error_message = None
            await session.commit()


    except Exception as e:
        error_msg = str(e) if isinstance(e, DeployError) else f"Unexpected error: {e}"
        logger.exception(f"Deployment failed: {error_msg}")
        await emit("error", "error", f"Deployment failed: {error_msg}")
        await emit("rollback", "running", "Rolling back deployment...")
        await _rollback(demo, namespace, steps_completed)
        await emit("rollback", "done", "Rollback complete")
        async with async_session() as session:
            state = await session.get(DeploymentState, "active")
            state.status = "error"
            state.error_message = error_msg
            await session.commit()

    finally:
        if values_file and os.path.exists(values_file):
            os.unlink(values_file)


async def teardown_demo(emit: EventCallback = None):
    emit = emit or _noop_emit
    async with async_session() as session:
        state = await session.get(DeploymentState, "active")
        if not state or state.status == "idle":
            return False, "No demo is currently running"

        demo_id = state.demo_id
        namespace = state.namespace

    demo = get_demo_by_id(demo_id)
    extra_namespaces = demo.get("extra_namespaces", []) if demo else []

    try:
        await emit("stop_chaos", "running", "Stopping chaos experiments...")
        async with async_session() as session:
            result = await session.execute(
                select(ChaosState).where(ChaosState.demo_id == demo_id, ChaosState.status == "running")
            )
            active_chaos = result.scalars().all()
            for chaos in active_chaos:
                exp = get_chaos_by_id(chaos.chaos_id)
                if exp:
                    await _delete_chaos_manifest(exp, namespace)
                chaos.status = "stopped"
            await session.commit()
        await emit("stop_chaos", "done", "Chaos experiments stopped")

        await emit("remove_collector", "running", f"Uninstalling Splunk OTel Collector from '{COLLECTOR_NAMESPACE}'...")
        ok, msg = await helm_uninstall("splunk-otel-collector", COLLECTOR_NAMESPACE)
        if not ok:
            logger.warning(f"Collector uninstall warning: {msg}")
        await emit("remove_collector", "done", "Collector removed")

        if demo and demo.get("manifest"):
            await emit("remove_app", "running", f"Removing {demo.get('name', demo_id)}...")
            manifest_path = str(BASE_DIR / demo["manifest"])
            delete_ns = None if extra_namespaces else namespace
            if os.path.exists(manifest_path):
                await delete_manifest(manifest_path, delete_ns)
            await emit("remove_app", "done", "Application removed")

        all_demo_ns = [namespace] + extra_namespaces
        await emit("wait_terminate", "running", "Waiting for pods to terminate...")
        for ns in all_demo_ns:
            ok, msg = await wait_for_pods_terminated(ns)
            if not ok:
                logger.warning(f"Pod termination warning ({ns}): {msg}")
        ok, msg = await wait_for_pods_terminated(COLLECTOR_NAMESPACE)
        if not ok:
            logger.warning(f"Collector pods termination warning: {msg}")
        await emit("wait_terminate", "done", "All pods terminated")

        for ns in all_demo_ns:
            if ns and ns != "default":
                await emit("delete_namespace", "running", f"Deleting namespace '{ns}'...")
                ok, msg = await delete_namespace(ns)
                await emit("delete_namespace", "done", msg)
            else:
                await emit("delete_namespace", "done", "Cleaned resources from default namespace")

        await emit("delete_collector_ns", "running", f"Deleting namespace '{COLLECTOR_NAMESPACE}'...")
        ok, msg = await delete_namespace(COLLECTOR_NAMESPACE)
        await emit("delete_collector_ns", "done", msg)

        await emit("cleanup_webhooks", "running", "Cleaning up orphaned webhook configs...")
        ok, msg = await delete_webhook_configs()
        await emit("cleanup_webhooks", "done", msg)

        await emit("complete", "done", "Teardown complete!")

        async with async_session() as session:
            state = await session.get(DeploymentState, "active")
            state.reset()
            await session.commit()

        return True, "Teardown complete"

    except Exception as e:
        error_msg = f"Teardown error: {str(e)}"
        logger.exception("Teardown failed")
        await emit("error", "error", error_msg)

        async with async_session() as session:
            state = await session.get(DeploymentState, "active")
            state.status = "error"
            state.error_message = error_msg
            await session.commit()

        return False, error_msg


async def run_chaos(chaos_id: str, emit: EventCallback = None) -> tuple[bool, str]:
    emit = emit or _noop_emit
    exp = get_chaos_by_id(chaos_id)
    if not exp:
        return False, f"Chaos experiment '{chaos_id}' not found"

    deployment = await get_deployment_state()
    if deployment["status"] != "running":
        return False, "No demo is currently running"

    applies_to = exp.get("applies_to", [])
    if applies_to and deployment["demo_id"] not in applies_to:
        return False, f"This experiment only applies to: {', '.join(applies_to)}"

    async with async_session() as session:
        existing = await session.execute(
            select(ChaosState).where(ChaosState.chaos_id == chaos_id, ChaosState.status == "running")
        )
        if existing.scalars().first():
            return False, f"Chaos experiment '{chaos_id}' is already running"

    namespace = deployment["namespace"]
    manifest = exp.get("manifest")

    try:
        await emit("apply_chaos", "running", f"Applying {exp.get('name', chaos_id)}...")
        if manifest:
            manifest_path = str(BASE_DIR / manifest)
            if os.path.exists(manifest_path):
                with open(manifest_path) as f:
                    rendered = Template(f.read()).render(namespace=namespace)
                ok, msg = await apply_manifest_content(rendered)
                if not ok:
                    raise DeployError(msg)

        duration = exp.get("duration")
        chaos_state_id = str(uuid.uuid4())
        async with async_session() as session:
            session.add(ChaosState(
                id=chaos_state_id,
                chaos_id=chaos_id,
                chaos_name=exp.get("name", chaos_id),
                demo_id=deployment["demo_id"],
                duration=str(duration) if duration else None,
            ))
            await session.commit()

        duration_msg = f" ({duration}s)" if duration else ""
        await emit("complete", "done", f"{exp.get('name', chaos_id)} is running{duration_msg}")
        return True, "Chaos experiment started"

    except DeployError as e:
        await emit("error", "error", str(e))
        return False, str(e)


async def stop_chaos(chaos_id: str, emit: EventCallback = None) -> tuple[bool, str]:
    emit = emit or _noop_emit

    exp = get_chaos_by_id(chaos_id)
    deployment = await get_deployment_state()
    namespace = deployment.get("namespace")

    try:
        await emit("remove_chaos", "running", f"Removing {exp.get('name', chaos_id) if exp else chaos_id}...")
        if exp:
            await _delete_chaos_manifest(exp, namespace)

        async with async_session() as session:
            result = await session.execute(
                select(ChaosState).where(ChaosState.chaos_id == chaos_id, ChaosState.status == "running")
            )
            for chaos in result.scalars().all():
                chaos.status = "stopped"
            await session.commit()

        await emit("complete", "done", "Chaos experiment stopped")
        return True, "Chaos experiment stopped"

    except Exception as e:
        await emit("error", "error", str(e))
        return False, str(e)


async def get_active_chaos() -> list[dict]:
    async with async_session() as session:
        result = await session.execute(
            select(ChaosState).where(ChaosState.status == "running")
        )
        return [c.to_dict() for c in result.scalars().all()]


async def _rollback(demo: dict, namespace: str, steps_completed: list[str]):
    logger.info(f"Rolling back: steps completed = {steps_completed}")
    if "app" in steps_completed and demo and demo.get("manifest"):
        manifest_path = str(BASE_DIR / demo["manifest"])
        extra = demo.get("extra_namespaces", [])
        delete_ns = None if extra else namespace
        if os.path.exists(manifest_path):
            await delete_manifest(manifest_path, delete_ns)

    if "collector" in steps_completed:
        await helm_uninstall("splunk-otel-collector", COLLECTOR_NAMESPACE)

    if "namespace" in steps_completed:
        extra_namespaces = demo.get("extra_namespaces", []) if demo else []
        for ns in [namespace] + extra_namespaces:
            if ns and ns != "default":
                await delete_namespace(ns)

    if "collector_namespace" in steps_completed:
        await delete_namespace(COLLECTOR_NAMESPACE)




class DeployError(Exception):
    pass
