import os
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy import Column, String, DateTime, Text
from datetime import datetime, timezone

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./data/demo-in-a-box.db")

engine = create_async_engine(DATABASE_URL, echo=False)
async_session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


class CollectorConfig(Base):
    __tablename__ = "collector_config"

    id = Column(String, primary_key=True, default="default")
    realm = Column(String, default="us1")
    access_token = Column(String, default="")
    rum_token = Column(String, default="")
    instance = Column(String, default="")
    hec_url = Column(String, default="")
    hec_token = Column(String, default="")
    splunk_index = Column(String, default="o11y-demo-eu")
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self):
        return {
            "realm": self.realm,
            "access_token": self.access_token,
            "rum_token": self.rum_token,
            "instance": self.instance,
            "hec_url": self.hec_url,
            "hec_token": self.hec_token,
            "splunk_index": self.splunk_index,
            "updated_at": (self.updated_at.isoformat() + "Z") if self.updated_at else None,
        }


class DeploymentState(Base):
    __tablename__ = "deployment_state"

    id = Column(String, primary_key=True, default="active")
    demo_id = Column(String, nullable=True)
    demo_name = Column(String, nullable=True)
    namespace = Column(String, nullable=True)
    status = Column(String, default="idle")  # idle, deploying, running, tearing_down, error
    deployed_at = Column(DateTime, nullable=True)
    error_message = Column(Text, nullable=True)

    def reset(self):
        self.demo_id = None
        self.demo_name = None
        self.namespace = None
        self.status = "idle"
        self.deployed_at = None
        self.error_message = None

    def to_dict(self):
        return {
            "demo_id": self.demo_id,
            "demo_name": self.demo_name,
            "namespace": self.namespace,
            "status": self.status,
            "deployed_at": (self.deployed_at.isoformat() + "Z") if self.deployed_at else None,
            "error_message": self.error_message,
        }


class ChaosState(Base):
    __tablename__ = "chaos_state"

    id = Column(String, primary_key=True)
    chaos_id = Column(String, nullable=False)
    chaos_name = Column(String, nullable=False)
    demo_id = Column(String, nullable=False)
    status = Column(String, default="running")  # running, stopped
    started_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    duration = Column(String, nullable=True)  # seconds, null = manual stop only

    def to_dict(self):
        return {
            "id": self.id,
            "chaos_id": self.chaos_id,
            "chaos_name": self.chaos_name,
            "demo_id": self.demo_id,
            "status": self.status,
            "started_at": (self.started_at.isoformat() + "Z") if self.started_at else None,
            "duration": int(self.duration) if self.duration else None,
        }


async def init_db():
    os.makedirs("data", exist_ok=True)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async with async_session() as session:
        config = await session.get(CollectorConfig, "default")
        if not config:
            session.add(CollectorConfig(id="default"))
            await session.commit()

        state = await session.get(DeploymentState, "active")
        if not state:
            session.add(DeploymentState(id="active"))
            await session.commit()
