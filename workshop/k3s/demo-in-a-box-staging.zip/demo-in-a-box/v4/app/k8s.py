from __future__ import annotations

import asyncio
import logging
import os
import tempfile
from typing import AsyncGenerator

logger = logging.getLogger("demo-in-a-box.k8s")

KUBECTL = os.getenv("KUBECTL_PATH", "kubectl")
HELM = os.getenv("HELM_PATH", "helm")


def _sanitize_cmd(cmd: list[str]) -> str:
    sanitized = []
    for arg in cmd:
        if "=" in arg and any(k in arg.lower() for k in ("token=", "accesstoken=", "password=")):
            key, _, _ = arg.partition("=")
            sanitized.append(f"{key}=***")
        else:
            sanitized.append(arg)
    return " ".join(sanitized)


async def run_cmd(cmd: list[str], timeout: int = 120, quiet: bool = False) -> tuple[int, str, str]:
    if not quiet:
        logger.info(f"Running: {_sanitize_cmd(cmd)}")
    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        return proc.returncode, stdout.decode(), stderr.decode()
    except asyncio.TimeoutError:
        proc.kill()
        return -1, "", "Command timed out"


async def ensure_namespace(namespace: str) -> tuple[bool, str]:
    code, _, _ = await run_cmd([KUBECTL, "get", "namespace", namespace])
    if code != 0:
        code, out, err = await run_cmd([KUBECTL, "create", "namespace", namespace])
        if code != 0:
            return False, f"Failed to create namespace {namespace}: {err}"
    return True, f"Namespace {namespace} ready"


async def apply_manifest(manifest_path: str, namespace: str | None = None) -> tuple[bool, str]:
    cmd = [KUBECTL, "apply", "-f", manifest_path]
    if namespace:
        cmd.extend(["-n", namespace])
    code, out, err = await run_cmd(cmd)
    if code != 0:
        return False, f"Failed to apply manifest: {err}"
    return True, out.strip()


async def apply_manifest_content(content: str, namespace: str | None = None) -> tuple[bool, str]:
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        f.write(content)
        f.flush()
        try:
            return await apply_manifest(f.name, namespace)
        finally:
            os.unlink(f.name)


async def delete_manifest(manifest_path: str, namespace: str | None = None) -> tuple[bool, str]:
    cmd = [KUBECTL, "delete", "-f", manifest_path, "--ignore-not-found"]
    if namespace:
        cmd.extend(["-n", namespace])
    code, out, err = await run_cmd(cmd, timeout=60)
    if code != 0:
        return False, f"Failed to delete manifest: {err}"
    return True, out.strip()


async def delete_manifest_content(content: str, namespace: str | None = None) -> tuple[bool, str]:
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        f.write(content)
        f.flush()
        try:
            return await delete_manifest(f.name, namespace)
        finally:
            os.unlink(f.name)


async def delete_webhook_configs(label_selector: str = "app.kubernetes.io/instance=splunk-otel-collector") -> tuple[bool, str]:
    removed = []
    for kind in ("mutatingwebhookconfiguration", "validatingwebhookconfiguration"):
        code, out, err = await run_cmd(
            [KUBECTL, "delete", kind, "-l", label_selector, "--ignore-not-found"],
        )
        if code == 0 and out.strip():
            removed.append(out.strip())
    if removed:
        return True, "Removed webhook configs: " + "; ".join(removed)
    return True, "No orphaned webhook configs found"


async def delete_namespace(namespace: str, wait: bool = True) -> tuple[bool, str]:
    code, out, err = await run_cmd(
        [KUBECTL, "delete", "namespace", namespace, "--ignore-not-found"],
        timeout=120,
    )
    if code != 0:
        return False, f"Failed to delete namespace: {err}"

    if wait:
        # Poll until the namespace is actually gone
        for _ in range(60):
            check_code, _, _ = await run_cmd(
                [KUBECTL, "get", "namespace", namespace],
            )
            if check_code != 0:
                break
            await asyncio.sleep(2)
        else:
            return False, f"Namespace {namespace} still terminating after 120s"

    return True, f"Namespace {namespace} deleted"


async def wait_for_pods_ready(namespace: str, timeout: int = 180, retries: int = 3, allow_empty: bool = False) -> tuple[bool, str]:
    per_attempt_timeout = timeout // retries
    for attempt in range(retries):
        cmd = [
            KUBECTL, "wait", "--for=condition=ready", "pod", "--all",
            "-n", namespace, f"--timeout={per_attempt_timeout}s",
        ]
        code, out, err = await run_cmd(cmd, timeout=per_attempt_timeout + 10)
        if code == 0:
            return True, f"All pods ready in {namespace}"
        if allow_empty and "no matching resources found" in err:
            return True, f"No pods in {namespace} (skipped)"
        if attempt < retries - 1:
            reason = "Pod disappeared" if "NotFound" in err else "Timed out"
            logger.warning(f"{reason} during wait (attempt {attempt + 1}/{retries}), retrying...")
            await asyncio.sleep(3)
            continue
        _, status_out, _ = await run_cmd(
            [KUBECTL, "get", "pods", "-n", namespace, "-o", "wide"]
        )
        return False, f"Pods not ready in {namespace}:\n{err}\n{status_out}"
    return False, f"Pods not ready in {namespace} after {retries} attempts"


async def wait_for_pods_terminated(namespace: str, timeout: int = 120) -> tuple[bool, str]:
    for i in range(timeout // 3):
        code, out, _ = await run_cmd([
            KUBECTL, "get", "pods", "-n", namespace,
            "-o", "jsonpath={.items[*].metadata.name}",
        ])
        if code != 0 or not out.strip():
            return True, f"All pods terminated in {namespace}"
        remaining = len(out.strip().split())
        logger.info(f"Waiting for {remaining} pod(s) to terminate in {namespace}...")
        await asyncio.sleep(3)
    return False, f"Pods still terminating in {namespace} after {timeout}s"


async def helm_repo_add() -> tuple[bool, str]:
    code, out, err = await run_cmd([
        HELM, "repo", "add", "splunk-otel-collector-chart",
        "https://signalfx.github.io/splunk-otel-collector-chart",
    ])
    if code != 0 and "already exists" not in err:
        return False, f"Failed to add Helm repo: {err}"
    code, out, err = await run_cmd([HELM, "repo", "update"])
    if code != 0:
        return False, f"Failed to update Helm repo: {err}"
    return True, "Helm repo ready"


def _build_collector_helm_args(
    realm: str,
    ingest_token: str,
    instance: str,
    hec_url: str,
    hec_token: str,
    splunk_index: str,
    environment: str = "",
    values_file: str = None,
    namespace: str = "default",
    version: str = None,
) -> list[str]:
    env_value = environment or f"{instance}-workshop"
    args = [
        "--set", "operatorcrds.install=true",
        "--set", "operator.enabled=true",
        "--set", f"splunkObservability.realm={realm}",
        "--set", f"splunkObservability.accessToken={ingest_token}",
        "--set", f"clusterName={instance}-k3s-cluster",
        "--set", "splunkObservability.profilingEnabled=true",
        "--set", f"environment={env_value}",
        "--set", f"splunkPlatform.endpoint={hec_url}",
        "--set", f"splunkPlatform.token={hec_token}",
        "--set", f"splunkPlatform.index={splunk_index}",
        "-n", namespace,
    ]
    if values_file and os.path.exists(values_file):
        args.extend(["-f", values_file])
    if version:
        args.extend(["--version", version])
    return args


async def helm_install_collector(
    release_name: str, **kwargs,
) -> tuple[bool, str]:
    args = _build_collector_helm_args(**kwargs)
    cmd = [HELM, "install", release_name, "splunk-otel-collector-chart/splunk-otel-collector"] + args
    code, out, err = await run_cmd(cmd, timeout=180)
    if code != 0:
        return False, f"Helm install failed: {err}"
    return True, out.strip()


async def helm_uninstall(release_name: str, namespace: str = "default") -> tuple[bool, str]:
    code, out, err = await run_cmd(
        [HELM, "uninstall", release_name, "-n", namespace],
        timeout=120,
    )
    if code != 0:
        return False, f"Helm uninstall failed: {err}"
    return True, out.strip()


async def _stream_kubectl_logs(cmd: list[str], skip_no_resources: bool = False) -> AsyncGenerator[str, None]:
    logger.info(f"Streaming logs: {' '.join(cmd)}")
    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    try:
        while proc.returncode is None:
            try:
                line = await asyncio.wait_for(proc.stdout.readline(), timeout=30)
            except asyncio.TimeoutError:
                yield "[log stream idle — no new logs for 30s]"
                continue
            if not line:
                break
            decoded = line.decode().rstrip()
            if skip_no_resources and "No resources found" in decoded:
                continue
            if decoded:
                yield decoded
    except asyncio.CancelledError:
        pass
    finally:
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        await proc.wait()
        logger.debug(f"Log stream ended, kubectl exit code: {proc.returncode}")


async def stream_logs(namespace: str, label_selector: str = "app") -> AsyncGenerator[str, None]:
    cmd = [
        KUBECTL, "logs", "-f", "--tail=100", "--all-containers=true",
        "--prefix=true", "--max-log-requests=20", "-n", namespace,
        "-l", label_selector,
    ]
    async for line in _stream_kubectl_logs(cmd, skip_no_resources=True):
        yield line


async def stream_pod_logs(namespace: str, pod_name: str) -> AsyncGenerator[str, None]:
    cmd = [
        KUBECTL, "logs", "-f", "--tail=200", "--all-containers=true",
        "--prefix=true", pod_name, "-n", namespace,
    ]
    async for line in _stream_kubectl_logs(cmd):
        yield line
