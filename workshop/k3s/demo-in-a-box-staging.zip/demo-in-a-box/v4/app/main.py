from __future__ import annotations

import asyncio
import json
import logging
import os
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy import delete as sql_delete, select

from db import init_db, async_session, CollectorConfig, DeploymentState, ChaosState
from deployer import (
    load_demos,
    load_chaos_experiments,
    get_demo_by_id,
    get_chaos_by_id,
    deploy_demo,
    teardown_demo,
    run_chaos,
    stop_chaos,
    get_deployment_state,
    get_collector_config,
    get_active_chaos,
    COLLECTOR_NAMESPACE,
    BASE_DIR,
)
from k8s import stream_logs, stream_pod_logs, run_cmd, KUBECTL, helm_uninstall, delete_namespace, delete_manifest, delete_webhook_configs

LOG_FORMAT = "%(asctime)s [%(levelname)s] %(message)s"
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT, datefmt="%H:%M:%S")
logger = logging.getLogger("demo-in-a-box")
logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
logging.getLogger("uvicorn.error").setLevel(logging.WARNING)


class _DropInvalidHTTP(logging.Filter):
    """Suppress 'Invalid HTTP request received' noise from bot/scanner traffic."""
    def filter(self, record: logging.LogRecord) -> bool:
        return "Invalid HTTP request" not in record.getMessage()


logging.getLogger("uvicorn.error").addFilter(_DropInvalidHTTP())


DIAB_LOG_FILE = Path(__file__).parent.parent / "diab.log"

STATIC_DIR = Path(__file__).parent / "static"
TEMPLATES_DIR = Path(__file__).parent / "templates"
HELP_FILE = Path(__file__).parent / "help.yaml"
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

def _load_help():
    import yaml
    if HELP_FILE.exists():
        with open(HELP_FILE) as f:
            return yaml.safe_load(f)
    return {}
_deploy_lock = asyncio.Lock()


class ConnectionManager:
    def __init__(self):
        self._pools: dict[str, list[WebSocket]] = {"events": [], "collector": [], "app": []}

    async def connect(self, pool: str, ws: WebSocket):
        await ws.accept()
        self._pools[pool].append(ws)

    def disconnect(self, ws: WebSocket):
        for pool in self._pools.values():
            if ws in pool:
                pool.remove(ws)

    async def _broadcast(self, pool: str, sender):
        dead = []
        for ws in self._pools[pool]:
            try:
                await sender(ws)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws)

    async def broadcast_event(self, data: dict):
        await self._broadcast("events", lambda ws: ws.send_json(data))


manager = ConnectionManager()
_background_tasks: set[asyncio.Task] = set()


def _make_emitter(event_type: str, **extra):
    async def emit(step, status, msg):
        await manager.broadcast_event({
            "type": event_type,
            "step": step,
            "status": status,
            "message": msg,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            **extra,
        })
    return emit


def _launch_background(coro):
    task = asyncio.create_task(coro)
    _background_tasks.add(task)
    task.add_done_callback(_background_tasks.discard)


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    logger.info("Demo-in-a-Box started on port %s", os.getenv("PORT", "8082"))
    yield


app = FastAPI(title="Demo-in-a-Box", version="4.0.0", lifespan=lifespan)

# ---------------------------------------------------------------------------
# Lightweight scanner/bot blocking middleware
# ---------------------------------------------------------------------------
_SCANNER_PREFIXES = (
    "/.env", "/.git", "/wp-", "/wordpress", "/phpmyadmin", "/phpMyAdmin",
    "/admin", "/cgi-bin", "/vendor", "/telescope", "/debug", "/actuator",
    "/solr", "/console", "/manager", "/shell", "/backup", "/config.json",
    "/login.action", "/setup.cgi", "/boaform", "/HNAP1",
)

@app.middleware("http")
async def block_scanners(request: Request, call_next):
    path = request.url.path
    if path.startswith(_SCANNER_PREFIXES):
        return PlainTextResponse("", status_code=404)
    return await call_next(request)

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request, "help": _load_help()})


@app.get("/api/demos")
async def list_demos():
    demos = load_demos()
    state = await get_deployment_state()
    for demo in demos:
        demo["status"] = state["status"] if state.get("demo_id") == demo["id"] else "stopped"
    return demos


@app.get("/api/demos/active")
async def active_demo():
    return await get_deployment_state()


@app.get("/api/yaml/demo/{demo_id}/files")
async def list_demo_yaml_files(demo_id: str):
    item = get_demo_by_id(demo_id)
    if not item:
        raise HTTPException(404, f"Demo '{demo_id}' not found")
    manifest_rel = item.get("manifest")
    if not manifest_rel:
        raise HTTPException(404, f"No manifest defined for '{demo_id}'")
    manifest_path = BASE_DIR / manifest_rel
    if not manifest_path.exists():
        raise HTTPException(404, f"Manifest not found: {manifest_rel}")
    if manifest_path.is_dir():
        files = sorted(f.name for f in manifest_path.glob("*.yaml"))
    else:
        files = [manifest_path.name]
    return JSONResponse({"id": demo_id, "name": item.get("name", demo_id), "files": files})


@app.get("/api/yaml/{kind}/{item_id}")
async def get_yaml_source(kind: str, item_id: str, file: str = ""):
    if kind == "demo":
        item = get_demo_by_id(item_id)
    elif kind == "chaos":
        item = get_chaos_by_id(item_id)
    else:
        raise HTTPException(404, "Unknown kind")
    if not item:
        raise HTTPException(404, f"{kind} '{item_id}' not found")
    manifest_rel = item.get("manifest")
    if not manifest_rel:
        raise HTTPException(404, f"No manifest defined for '{item_id}'")
    manifest_path = BASE_DIR / manifest_rel
    if not manifest_path.exists():
        raise HTTPException(404, f"Manifest not found: {manifest_rel}")
    if manifest_path.is_dir():
        if file:
            target = manifest_path / file
        else:
            yamls = sorted(manifest_path.glob("*.yaml"))
            target = yamls[0] if yamls else None
        if not target or not target.exists() or not target.is_file():
            raise HTTPException(404, f"File not found: {file}")
        if not target.resolve().is_relative_to(manifest_path.resolve()):
            raise HTTPException(400, "Invalid file path")
        return JSONResponse({"id": item_id, "name": item.get("name", item_id), "file": target.name, "content": target.read_text()})
    return JSONResponse({"id": item_id, "name": item.get("name", item_id), "file": manifest_path.name, "content": manifest_path.read_text()})


@app.post("/api/demos/{demo_id}/deploy")
async def api_deploy_demo(demo_id: str):
    async with _deploy_lock:
        state = await get_deployment_state()
        if state["status"] in ("running", "deploying"):
            raise HTTPException(400, "A demo is already running. Tear it down first.")

        demo = get_demo_by_id(demo_id)
        if not demo:
            raise HTTPException(404, f"Demo '{demo_id}' not found")

        async with async_session() as session:
            db_state = await session.get(DeploymentState, "active")
            db_state.demo_id = demo_id
            db_state.demo_name = demo.get("name", demo_id)
            db_state.namespace = demo.get("namespace", "default")
            db_state.status = "deploying"
            db_state.error_message = None
            await session.commit()

    emit = _make_emitter("deployment", demo_id=demo_id)

    async def run():
        try:
            await deploy_demo(demo_id, emit)
        except Exception as e:
            logger.exception("Background deploy failed")
            await emit("error", "error", str(e))

    _launch_background(run())
    return {"status": "deploying", "demo_id": demo_id}


@app.post("/api/demos/teardown")
async def api_teardown_demo():
    async with _deploy_lock:
        state = await get_deployment_state()
        if state["status"] not in ("running", "error"):
            raise HTTPException(400, "No demo to tear down")

        async with async_session() as session:
            db_state = await session.get(DeploymentState, "active")
            db_state.status = "tearing_down"
            await session.commit()

    emit = _make_emitter("teardown")

    async def run():
        try:
            await teardown_demo(emit)
        except Exception as e:
            logger.exception("Background teardown failed")
            await emit("error", "error", str(e))

    _launch_background(run())
    return {"status": "tearing_down"}


@app.get("/api/chaos")
async def list_chaos():
    experiments = load_chaos_experiments()
    active = await get_active_chaos()
    now = datetime.now(timezone.utc)

    # Auto-expire chaos experiments that have exceeded their duration
    expired = []
    for c in active:
        if c.get("duration") and c.get("started_at"):
            started = datetime.fromisoformat(c["started_at"])
            if (now - started).total_seconds() >= c["duration"]:
                expired.append(c["chaos_id"])

    if expired:
        async with async_session() as session:
            for cid in expired:
                result = await session.execute(
                    select(ChaosState).where(ChaosState.chaos_id == cid, ChaosState.status == "running")
                )
                for row in result.scalars().all():
                    row.status = "stopped"
            await session.commit()
        active = [c for c in active if c["chaos_id"] not in expired]

    active_map = {c["chaos_id"]: c for c in active}
    for exp in experiments:
        ac = active_map.get(exp["id"])
        exp["running"] = ac is not None
        exp["startedAt"] = ac["started_at"] if ac else None
        exp["activeDuration"] = ac.get("duration") if ac else None
    return experiments


@app.post("/api/chaos/{chaos_id}/run")
async def api_run_chaos(chaos_id: str):
    exp = get_chaos_by_id(chaos_id)
    if not exp:
        raise HTTPException(404, f"Chaos experiment '{chaos_id}' not found")
    deployment = await get_deployment_state()
    if deployment["status"] != "running":
        raise HTTPException(400, "No demo is currently running")

    emit = _make_emitter("chaos", action="start", chaos_id=chaos_id)

    async def run():
        try:
            ok, msg = await run_chaos(chaos_id, emit)
            if not ok:
                logger.warning(f"Chaos run failed: {msg}")
                await emit("error", "error", msg)
        except Exception as e:
            logger.exception("Background chaos run failed")
            await emit("error", "error", str(e))

    _launch_background(run())
    return {"status": "starting", "chaos_id": chaos_id}


@app.post("/api/chaos/{chaos_id}/stop")
async def api_stop_chaos(chaos_id: str):
    emit = _make_emitter("chaos", action="stop", chaos_id=chaos_id)

    async def run():
        try:
            ok, msg = await stop_chaos(chaos_id, emit)
            if not ok:
                logger.warning(f"Chaos stop failed: {msg}")
                await emit("error", "error", msg)
        except Exception as e:
            logger.exception("Background chaos stop failed")
            await emit("error", "error", str(e))

    _launch_background(run())
    return {"status": "stopping", "chaos_id": chaos_id}


@app.get("/api/config")
async def get_config():
    return await get_collector_config()


@app.post("/api/config")
async def save_config_json(request: Request):
    try:
        data = await request.json()
    except Exception:
        raise HTTPException(400, "Invalid JSON body")
    if not isinstance(data, dict):
        raise HTTPException(400, "Expected a JSON object")
    return await _save_config(data)


@app.post("/saveConfig")
async def save_config_form(
    realm: str = Form("us1"),
    ingest_token: str = Form(""),
    api_token: str = Form(""),
    rum_token: str = Form(""),
    instance: str = Form(""),
    hec_url: str = Form(""),
    hec_token: str = Form(""),
    splunk_index: str = Form("o11y-demo-eu"),
):
    return await _save_config({
        "realm": realm,
        "ingest_token": ingest_token,
        "api_token": api_token,
        "rum_token": rum_token,
        "instance": instance,
        "hec_url": hec_url,
        "hec_token": hec_token,
        "splunk_index": splunk_index,
    })


async def _save_config(data: dict) -> dict:
    async with async_session() as session:
        config = await session.get(CollectorConfig, "default")
        if not config:
            config = CollectorConfig(id="default")
            session.add(config)

        if "realm" in data:
            config.realm = data["realm"]
        if "ingest_token" in data:
            config.ingest_token = data["ingest_token"]
        if "api_token" in data:
            config.api_token = data["api_token"]
        if "rum_token" in data:
            config.rum_token = data["rum_token"]
        if "instance" in data:
            config.instance = data["instance"]
        if "hec_url" in data:
            config.hec_url = data["hec_url"]
        if "hec_token" in data:
            config.hec_token = data["hec_token"]
        if "splunk_index" in data:
            config.splunk_index = data["splunk_index"]
        config.updated_at = datetime.now(timezone.utc)

        await session.commit()
        logger.info(f"Config saved: realm={config.realm}, instance={config.instance}, token={'***' if config.ingest_token else '(empty)'}")

        await manager.broadcast_event({
            "type": "config_updated",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

        return config.to_dict()


@app.post("/api/reset")
async def reset_deployments():
    async with _deploy_lock:
        logger.info("Reset: starting full cleanup...")
        await helm_uninstall("splunk-otel-collector", COLLECTOR_NAMESPACE)

        for demo in load_demos():
            ns = demo.get("namespace", "default")
            extra_ns = demo.get("extra_namespaces", [])
            if ns == "default":
                manifest = demo.get("manifest")
                if manifest:
                    manifest_path = str(BASE_DIR / manifest)
                    if os.path.exists(manifest_path):
                        logger.info(f"Reset: deleting resources from default for {demo['id']}...")
                        await delete_manifest(manifest_path, "default")
            else:
                logger.info(f"Reset: deleting namespace {ns}...")
                await delete_namespace(ns, wait=False)
            for ens in extra_ns:
                logger.info(f"Reset: deleting extra namespace {ens}...")
                await delete_namespace(ens, wait=False)

        await delete_namespace(COLLECTOR_NAMESPACE, wait=False)
        await run_cmd([KUBECTL, "delete", "clusterrole", "splunk-otel-collector", "--ignore-not-found"])
        await run_cmd([KUBECTL, "delete", "clusterrolebinding", "splunk-otel-collector", "--ignore-not-found"])
        await delete_webhook_configs()

        async with async_session() as session:
            db_state = await session.get(DeploymentState, "active")
            if db_state:
                db_state.reset()
            await session.execute(sql_delete(ChaosState))
            await session.commit()

        logger.info("Reset completed")
        return {"status": "ok", "message": "Reset complete"}


@app.get("/api/health")
async def health():
    return {"status": "ok", "timestamp": datetime.now(timezone.utc).isoformat()}


async def _get_pods_in_namespace(namespace: str) -> list[dict]:
    code, out, err = await run_cmd([KUBECTL, "get", "pods", "-n", namespace, "-o", "json"], quiet=True)
    if code != 0:
        return []
    try:
        data = json.loads(out)
    except json.JSONDecodeError:
        return []

    pods = []
    for item in data.get("items", []):
        name = item["metadata"]["name"]
        labels = item["metadata"].get("labels", {})
        phase = item.get("status", {}).get("phase", "Unknown")
        containers = [c["name"] for c in item.get("spec", {}).get("containers", [])]
        app_label = labels.get("app") or labels.get("app.kubernetes.io/name") or labels.get("app.kubernetes.io/component") or ""
        node = item.get("spec", {}).get("nodeName", "")
        container_statuses = item.get("status", {}).get("containerStatuses", [])
        restart_count = sum(cs.get("restartCount", 0) for cs in container_statuses)
        ready_count = sum(1 for cs in container_statuses if cs.get("ready", False))
        total_containers = len(containers)
        ready = ready_count == total_containers and total_containers > 0
        start_time = item.get("status", {}).get("startTime", "")
        pods.append({
            "name": name, "app": app_label, "phase": phase, "containers": containers,
            "namespace": namespace, "node": node,
            "restartCount": restart_count, "ready": ready,
            "readyCount": ready_count, "totalContainers": total_containers,
            "startTime": start_time,
        })
    return pods


@app.get("/api/pods")
async def list_pods():
    state = await get_deployment_state()
    if state["status"] != "running" or not state.get("namespace"):
        return {"collector": [], "app": []}
    demo = get_demo_by_id(state["demo_id"]) if state.get("demo_id") else None
    extra_ns = demo.get("extra_namespaces", []) if demo else []
    all_app_ns = [state["namespace"]] + extra_ns
    results = await asyncio.gather(
        _get_pods_in_namespace(COLLECTOR_NAMESPACE),
        *(_get_pods_in_namespace(ns) for ns in all_app_ns),
    )
    app_pods = [p for ns_pods in results[1:] for p in ns_pods]
    return {"collector": results[0], "app": app_pods}


@app.get("/api/pods/{pod_name}/describe")
async def describe_pod(pod_name: str, ns: str = ""):
    state = await get_deployment_state()
    if state["status"] != "running" or not state.get("namespace"):
        return PlainTextResponse("[No deployment running]")
    namespace = ns or state["namespace"]
    demo = get_demo_by_id(state["demo_id"]) if state.get("demo_id") else None
    extra_ns = demo.get("extra_namespaces", []) if demo else []
    allowed_ns = {COLLECTOR_NAMESPACE, state["namespace"]} | set(extra_ns)
    if namespace not in allowed_ns:
        return PlainTextResponse(f"[Namespace '{namespace}' not allowed]", status_code=403)
    code, stdout, stderr = await run_cmd(
        [KUBECTL, "describe", "pod", pod_name, "-n", namespace], quiet=True
    )
    if code != 0:
        return PlainTextResponse(
            stderr or f"[kubectl describe failed with code {code}]", status_code=500
        )
    return PlainTextResponse(stdout)


@app.websocket("/ws/events")
async def ws_events(ws: WebSocket):
    await manager.connect("events", ws)
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(ws)


@app.websocket("/ws/logs/diab")
async def ws_diab_logs(ws: WebSocket):
    await ws.accept()
    try:
        if not DIAB_LOG_FILE.exists():
            await ws.send_text("[diab.log not found]")
            while True:
                await ws.receive_text()

        proc = await asyncio.create_subprocess_exec(
            "tail", "-n", "200", "-f", str(DIAB_LOG_FILE),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )
        try:
            assert proc.stdout is not None
            async for raw in proc.stdout:
                line = raw.decode("utf-8", errors="replace").rstrip("\n")
                await ws.send_text(line)
        finally:
            proc.kill()
            await proc.wait()
    except WebSocketDisconnect:
        pass
    except Exception:
        logger.exception("DIAB log WebSocket error")


@app.websocket("/ws/logs/{log_type}")
async def ws_logs(ws: WebSocket, log_type: str):
    await manager.connect(log_type if log_type == "collector" else "app", ws)

    try:
        state = await get_deployment_state()
        if state["status"] != "running" or not state.get("namespace"):
            await ws.send_text("[No deployment running — waiting...]")
            while True:
                await ws.receive_text()

        namespace = COLLECTOR_NAMESPACE if log_type == "collector" else state["namespace"]
        pod_name = ws.query_params.get("pod", "")

        if pod_name:
            pod_ns = ws.query_params.get("ns", namespace)
            demo = get_demo_by_id(state["demo_id"]) if state.get("demo_id") else None
            extra_ns = demo.get("extra_namespaces", []) if demo else []
            allowed_ns = {COLLECTOR_NAMESPACE, state["namespace"]} | set(extra_ns)
            if pod_ns not in allowed_ns:
                await ws.send_text(f"[Namespace '{pod_ns}' not allowed]")
                return
            async for line in stream_pod_logs(pod_ns, pod_name):
                await ws.send_text(line)
        else:
            async for line in stream_logs(namespace, label_selector="app"):
                await ws.send_text(line)

        await ws.send_text("[Log stream ended]")
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        pass
    except Exception:
        logger.exception("WebSocket log stream error")
    finally:
        manager.disconnect(ws)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", "8082")),
        reload=os.getenv("DEV", "false").lower() == "true",
        log_config=None,
    )
