function podLogPanel() {
  return {
    connected: false,
    searchQuery: '',
    lineCount: 0,
    wrap: false,
    _ws: null,
    _rawLines: [],

    openPod(pod) {
      if (!pod) return;
      Alpine.store('app').diabLogsOpen = false;
      this._rawLines = [];
      this.$nextTick(() => {
        this._connect(pod);
      });
    },

    openDiabLogs() {
      this._rawLines = [];
      this.$nextTick(() => {
        this._connectDiab();
      });
    },

    closePod() {
      this._disconnect();
    },

    toggleWrap() {
      const el = this.$refs.logView;
      const ratio = el && el.scrollHeight > el.clientHeight
        ? el.scrollTop / (el.scrollHeight - el.clientHeight)
        : 1;
      this.wrap = !this.wrap;
      this.$nextTick(() => {
        if (el && el.scrollHeight > el.clientHeight) {
          el.scrollTop = ratio * (el.scrollHeight - el.clientHeight);
        }
      });
    },

    _render() {
      const el = this.$refs.logView;
      if (!el) return;
      el.innerHTML = this._rawLines.map(l => this._colorLine(l)).join('\n');
      el.scrollTop = el.scrollHeight;
    },

    _appendLine(text) {
      const el = this.$refs.logView;
      if (!el) return;
      const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 40;
      if (this._rawLines.length > 1) el.innerHTML += '\n';
      el.innerHTML += this._colorLine(text);
      if (atBottom) el.scrollTop = el.scrollHeight;
    },

    _connect(pod) {
      this._disconnect();
      if (!pod) return;
      this.lineCount = 0;
      this._rawLines = [];
      const el = this.$refs.logView;
      if (el) el.innerHTML = '';

      const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ns = pod.namespace || '';
      const logType = ns === 'splunk' ? 'collector' : 'app';
      const params = new URLSearchParams();
      params.set('pod', pod.name);
      if (ns) params.set('ns', ns);

      this._ws = new WebSocket(`${proto}//${location.host}/ws/logs/${logType}?${params}`);
      this._ws.onopen = () => { this.connected = true; };
      this._ws.onclose = () => { this.connected = false; };
      this._ws.onmessage = (e) => {
        this._rawLines.push(e.data);
        this.lineCount++;
        this._appendLine(e.data);
      };
    },

    _connectDiab() {
      this._disconnect();
      this.lineCount = 0;
      this._rawLines = [];
      const el = this.$refs.logView;
      if (el) el.innerHTML = '';

      const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
      this._ws = new WebSocket(`${proto}//${location.host}/ws/logs/diab`);
      this._ws.onopen = () => { this.connected = true; };
      this._ws.onclose = () => { this.connected = false; };
      this._ws.onmessage = (e) => {
        this._rawLines.push(e.data);
        this.lineCount++;
        this._appendLine(e.data);
      };
    },

    _disconnect() {
      if (this._ws) { this._ws.close(); this._ws = null; }
      this.connected = false;
    },

    _esc(text) {
      return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    },

    _colorLine(text) {
      const safe = this._esc(text);
      const braceIdx = text.indexOf('{');
      const prefix = (braceIdx > -1 ? text.slice(0, braceIdx) : text).toLowerCase();
      if (prefix.includes('error') || prefix.includes('fatal') || prefix.includes('panic')) {
        return `<span class="log-error">${safe}</span>`;
      } else if (prefix.includes('warn')) {
        return `<span class="log-warn">${safe}</span>`;
      } else if (prefix.includes('debug') || prefix.includes('trace')) {
        return `<span class="log-debug">${safe}</span>`;
      }
      return safe;
    },

    doSearch() {
      if (!this.searchQuery || !window.find) return;
      window.find(this.searchQuery, false, false, true);
    },

    clearTerminal() {
      this._rawLines = [];
      this.lineCount = 0;
      const el = this.$refs.logView;
      if (el) el.innerHTML = '';
    },
  };
}
