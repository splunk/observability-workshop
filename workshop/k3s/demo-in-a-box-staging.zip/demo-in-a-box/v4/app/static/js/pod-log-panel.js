function podLogPanel() {
  return {
    connected: false,
    paused: false,
    searchQuery: '',
    lineCount: 0,
    wrap: false,
    loading: false,
    copied: false,
    _ws: null,
    _rawLines: [],
    _pauseBuffer: [],
    _describeContent: '',

    _currentMode: null,  // 'pod', 'diab', 'describe'
    _currentPod: null,

    openPod(pod) {
      if (!pod) return;
      if (this._currentMode === 'pod' && this._currentPod === pod.name) return;
      this._currentMode = 'pod';
      this._currentPod = pod.name;
      Alpine.store('app').diabLogsOpen = false;
      Alpine.store('app').describePod = null;
      this._rawLines = [];
      this.$nextTick(() => {
        this._connect(pod);
      });
    },

    openDiabLogs() {
      if (this._currentMode === 'diab') return;
      this._currentMode = 'diab';
      this._currentPod = null;
      Alpine.store('app').describePod = null;
      this._rawLines = [];
      this.$nextTick(() => {
        this._connectDiab();
      });
    },

    async openDescribe(pod) {
      if (!pod) return;
      if (this._currentMode === 'describe' && this._currentPod === pod.name) return;
      this._currentMode = 'describe';
      this._currentPod = pod.name;
      Alpine.store('app').logPod = null;
      Alpine.store('app').diabLogsOpen = false;
      this._disconnect();
      this.loading = true;
      this.copied = false;
      this._describeContent = '';
      const el = this.$refs.logView;
      if (el) el.textContent = '';
      await this._fetchDescribe(pod);
    },

    closePanel() {
      this._currentMode = null;
      this._currentPod = null;
      this.paused = false;
      this._pauseBuffer = [];
      this._disconnect();
      this._describeContent = '';
    },

    togglePause() {
      this.paused = !this.paused;
      if (!this.paused) {
        const el = this.$refs.logView;
        for (const line of this._pauseBuffer) {
          this._rawLines.push(line);
          this.lineCount++;
          if (el) {
            if (this._rawLines.length > 1) el.innerHTML += '\n';
            el.innerHTML += this._colorLine(line);
          }
        }
        this._pauseBuffer = [];
        if (el) el.scrollTop = el.scrollHeight;
      }
    },

    async refreshDescribe() {
      const pod = Alpine.store('app').describePod;
      if (!pod) return;
      this.loading = true;
      this.copied = false;
      await this._fetchDescribe(pod);
    },

    async _fetchDescribe(pod) {
      const el = this.$refs.logView;
      try {
        const ns = pod.namespace || '';
        const params = new URLSearchParams({ ns });
        const res = await fetch(`/api/pods/${encodeURIComponent(pod.name)}/describe?${params}`);
        const text = await res.text();
        this._describeContent = text;
        this.$nextTick(() => { if (el) el.textContent = text; });
      } catch (e) {
        this._describeContent = `[Error: ${e.message}]`;
        if (el) el.textContent = this._describeContent;
      } finally {
        this.loading = false;
      }
    },

    async copyContent() {
      const text = this._currentMode === 'describe'
        ? this._describeContent
        : this._rawLines.join('\n');
      try {
        await navigator.clipboard.writeText(text);
        this.copied = true;
        setTimeout(() => { this.copied = false; }, 2000);
      } catch {
        Alpine.store('app').toast('Failed to copy to clipboard', 'error');
      }
    },

    toggleWrap() {
      const el = this.$refs.logView;
      const ratio = el && el.scrollHeight > el.clientHeight
        ? el.scrollTop / (el.scrollHeight - el.clientHeight)
        : 1;
      this.wrap = !this.wrap;
      this.$nextTick(() => {
        if (el && el.scrollHeight > el.clientHeight) {
          el.scrollTop = ratio * (el.scrollHeight - el.clientHeight);
        }
      });
    },

    _appendLine(text) {
      const el = this.$refs.logView;
      if (!el) return;
      const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 40;
      if (this._rawLines.length > 1) el.innerHTML += '\n';
      el.innerHTML += this._colorLine(text);
      if (atBottom) el.scrollTop = el.scrollHeight;
    },

    _connect(pod) {
      this._disconnect();
      if (!pod) return;
      this.lineCount = 0;
      this._rawLines = [];
      const el = this.$refs.logView;
      if (el) el.innerHTML = '';

      const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ns = pod.namespace || '';
      const logType = ns === 'splunk' ? 'collector' : 'app';
      const params = new URLSearchParams();
      params.set('pod', pod.name);
      if (ns) params.set('ns', ns);

      this._ws = new WebSocket(`${proto}//${location.host}/ws/logs/${logType}?${params}`);
      this._ws.onopen = () => { this.connected = true; };
      this._ws.onclose = () => { this.connected = false; };
      this._ws.onmessage = (e) => {
        if (this.paused) { this._pauseBuffer.push(e.data); return; }
        this._rawLines.push(e.data);
        this.lineCount++;
        this._appendLine(e.data);
      };
    },

    _connectDiab() {
      this._disconnect();
      this.lineCount = 0;
      this._rawLines = [];
      const el = this.$refs.logView;
      if (el) el.innerHTML = '';

      const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
      this._ws = new WebSocket(`${proto}//${location.host}/ws/logs/diab`);
      this._ws.onopen = () => { this.connected = true; };
      this._ws.onclose = () => { this.connected = false; };
      this._ws.onmessage = (e) => {
        if (this.paused) { this._pauseBuffer.push(e.data); return; }
        this._rawLines.push(e.data);
        this.lineCount++;
        this._appendLine(e.data);
      };
    },

    _disconnect() {
      if (this._ws) { this._ws.close(); this._ws = null; }
      this.connected = false;
    },

    _esc(text) {
      return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    },

    _colorLine(text) {
      const safe = this._esc(text);
      const braceIdx = text.indexOf('{');
      const prefix = (braceIdx > -1 ? text.slice(0, braceIdx) : text).toLowerCase();
      if (prefix.includes('error') || prefix.includes('fatal') || prefix.includes('panic')) {
        return `<span class="log-error">${safe}</span>`;
      } else if (prefix.includes('warn')) {
        return `<span class="log-warn">${safe}</span>`;
      } else if (prefix.includes('debug') || prefix.includes('trace')) {
        return `<span class="log-debug">${safe}</span>`;
      }
      return safe;
    },

    _lastSearch: '',
    _searchMatches: [],
    _searchIdx: -1,
    doSearch() {
      if (!this.searchQuery) return;
      const el = this.$refs.logView;
      if (!el) return;

      // Rebuild matches if query changed
      if (this.searchQuery !== this._lastSearch) {
        this._clearHighlights(el);
        this._searchMatches = [];
        this._searchIdx = -1;
        this._lastSearch = this.searchQuery;
        const query = this.searchQuery.toLowerCase();
        const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
        const hits = [];
        let node;
        while ((node = walker.nextNode())) {
          const text = node.textContent;
          const lower = text.toLowerCase();
          let start = 0;
          let idx;
          while ((idx = lower.indexOf(query, start)) !== -1) {
            hits.push({ node, offset: idx, length: query.length });
            start = idx + query.length;
          }
        }
        // Highlight all matches (wrap in <mark>)
        for (let i = hits.length - 1; i >= 0; i--) {
          const h = hits[i];
          const range = document.createRange();
          range.setStart(h.node, h.offset);
          range.setEnd(h.node, h.offset + h.length);
          const mark = document.createElement('mark');
          mark.className = 'bg-orange/30 text-text-1 rounded-sm';
          mark.dataset.searchHit = i;
          range.surroundContents(mark);
        }
        this._searchMatches = el.querySelectorAll('mark[data-search-hit]');
      }

      if (!this._searchMatches.length) return;

      // Advance to next match
      this._searchIdx = (this._searchIdx + 1) % this._searchMatches.length;
      // Remove active highlight from previous
      el.querySelectorAll('mark.!bg-accent/40').forEach(m => {
        m.classList.remove('!bg-accent/40');
        m.classList.add('bg-orange/30');
      });
      // Highlight current match
      const current = this._searchMatches[this._searchIdx];
      current.classList.remove('bg-orange/30');
      current.classList.add('!bg-accent/40');
      current.scrollIntoView({ block: 'center', behavior: 'smooth' });
    },

    _clearHighlights(el) {
      el.querySelectorAll('mark[data-search-hit]').forEach(mark => {
        const parent = mark.parentNode;
        parent.replaceChild(document.createTextNode(mark.textContent), mark);
        parent.normalize();
      });
    },

    clearTerminal() {
      if (this._currentMode === 'describe') {
        this._describeContent = '';
      } else {
        this._rawLines = [];
        this.lineCount = 0;
      }
      this._lastSearch = '';
      this._searchMatches = [];
      this._searchIdx = -1;
      const el = this.$refs.logView;
      if (el) el.innerHTML = '';
    },
  };
}
