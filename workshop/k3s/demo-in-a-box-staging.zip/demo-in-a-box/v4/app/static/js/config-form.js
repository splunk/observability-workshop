function configForm() {
  return {
    form: { realm: '', access_token: '', rum_token: '', instance: '', hec_url: '', hec_token: '', splunk_index: '' },
    savedForm: {},
    saving: false,
    dirty: false,
    _watchInit: false,

    async loadConfig() {
      try {
        const c = await api('/api/config');
        this.form = {
          realm: c.realm || 'us1',
          access_token: c.access_token || '',
          rum_token: c.rum_token || '',
          instance: c.instance || '',
          hec_url: c.hec_url || '',
          hec_token: c.hec_token || '',
          splunk_index: c.splunk_index || 'o11y-demo-eu',
        };
        this.savedForm = { ...this.form };
        this.dirty = false;
        if (!this._watchInit) {
          this._watchInit = true;
          this.$watch('form', () => {
            this.dirty = JSON.stringify(this.form) !== JSON.stringify(this.savedForm);
          }, { deep: true });
        }
      } catch (e) {
        console.error('Failed to load config:', e);
      }
    },

    async save() {
      this.saving = true;
      try {
        await api('/api/config', { method: 'POST', body: JSON.stringify(this.form) });
        this.savedForm = { ...this.form };
        this.dirty = false;
        Alpine.store('app').toast('Configuration saved', 'success');
        await Alpine.store('app').refreshState();
        this.loadConfig();
      } catch (e) {
        Alpine.store('app').toast('Failed to save: ' + e.message, 'error');
      } finally {
        this.saving = false;
      }
    },

    async closeSettings() {
      if (this.dirty) {
        const ok = await Alpine.store('app').appConfirm('Unsaved Changes', 'You have unsaved changes. Discard them?', 'Discard', 'warn');
        if (!ok) return;
      }
      Alpine.store('app').settingsOpen = false;
    },

    async resetAll() {
      const ok = await Alpine.store('app').appConfirm('Reset Deployments', 'This will tear down any running demo and collector. Your settings will be kept.', 'Reset');
      if (!ok) return;
      try {
        await api('/api/reset', { method: 'POST' });
        Alpine.store('app').toast('Reset complete — all deployments cleared', 'success');
        await Alpine.store('app').refreshState();
      } catch (e) {
        Alpine.store('app').toast('Reset failed: ' + e.message, 'error');
      }
    },
  };
}
