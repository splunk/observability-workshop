let eventsWs = null;

const iconMap = {
  'rocket': 'rocket_launch', 'web': 'language', 'microservices': 'hub', 'store': 'storefront',
  'network': 'lan', 'cpu': 'memory', 'latency': 'network_check', 'fire': 'local_fire_department',
  'bug': 'bug_report', 'disk': 'hard_drive', 'globe': 'public', 'gear': 'settings',
  'package': 'deployed_code',
};

const chaosCategories = [
  { id: 'pod-lifecycle', label: 'Pod Lifecycle', icon: 'restart_alt' },
  { id: 'resource',      label: 'Resource Pressure', icon: 'memory' },
  { id: 'network',       label: 'Network', icon: 'lan' },
  { id: 'application',   label: 'Application', icon: 'code' },
  { id: '_other',        label: 'Other', icon: 'more_horiz' },
];

function groupChaosByCategory(experiments) {
  const map = {};
  for (const exp of experiments) {
    const cat = exp.category || '_other';
    if (!map[cat]) map[cat] = [];
    map[cat].push(exp);
  }
  const result = [];
  for (const def of chaosCategories) {
    if (map[def.id]) {
      result.push({ ...def, experiments: map[def.id] });
      delete map[def.id];
    }
  }
  // Any unknown categories go at the end
  for (const [id, exps] of Object.entries(map)) {
    result.push({ id, label: id, icon: 'more_horiz', experiments: exps });
  }
  return result;
}

const POLL_INTERVAL_MS = 5000;
const TOAST_DURATION_MS = 4000;
const WS_RETRY_INITIAL_MS = 3000;
const WS_RETRY_MAX_MS = 60000;
const ACTIVITY_AUTO_COLLAPSE_MS = 1500;
