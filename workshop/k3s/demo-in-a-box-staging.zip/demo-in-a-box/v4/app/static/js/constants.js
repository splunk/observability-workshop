let eventsWs = null;

const iconMap = {
  'shopping_cart': 'shopping_cart', 'auto_awesome': 'auto_awesome', 'directions_car': 'directions_car', 'waving_hand': 'waving_hand',
  'rocket': 'rocket_launch', 'web': 'language', 'cloud': 'cloud', 'database': 'database',
  'api': 'api', 'microservices': 'hub', 'monitoring': 'monitoring', 'store': 'storefront',
  'skull': 'skull', 'network': 'lan', 'cpu': 'memory', 'latency': 'network_check',
  'fire': 'local_fire_department', 'bomb': 'bomb', 'bug': 'bug_report', 'warning': 'warning',
  'disk': 'hard_drive', 'dns': 'dns', 'traffic': 'traffic',
  'bolt': 'bolt', 'globe': 'public', 'gear': 'settings', 'package': 'deployed_code',
};

const POLL_INTERVAL_MS = 5000;
const TOAST_DURATION_MS = 4000;
const WS_RETRY_INITIAL_MS = 3000;
const WS_RETRY_MAX_MS = 60000;
const MODAL_AUTO_CLOSE_MS = 1500;
