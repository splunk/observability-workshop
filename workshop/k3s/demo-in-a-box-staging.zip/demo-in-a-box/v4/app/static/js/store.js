document.addEventListener('alpine:init', () => {
  Alpine.store('app', {
    VERSION: '4.0.0',
    view: 'demos',
    demos: [],
    chaos: [],
    config: {},
    deployment: { status: 'idle', demo_id: null, demo_name: null },
    collectorPods: { total: 0, ready: 0 },
    helpOpen: false,
    confirmOpen: false,
    confirmTitle: '',
    confirmMessage: '',
    confirmAction: 'Confirm',
    confirmVariant: 'danger',
    _confirmResolve: null,
    modalOpen: false,
    modalDone: false,
    modalTitle: '',
    modalSteps: [],
    toasts: [],
    setupRequired: false,
    settingsOpen: false,
    yamlOpen: false,
    yamlTitle: '',
    yamlContent: '',
    yamlHighlighted: '',
    yamlCopied: false,
    logPod: null,

    stepLabels: {
      validate_config: 'Validating configuration',
      create_collector_ns: 'Creating splunk namespace',
      create_namespace: 'Creating demo namespace',
      deploy_secret: 'Deploying workshop secret',
      helm_repo: 'Adding Helm repository',
      render_values: 'Rendering collector values',
      deploy_collector: 'Installing OTel Collector',
      deploy_app: 'Deploying application',
      wait_pods: 'Waiting for pods',
      complete: 'Complete',
      error: 'Error',
      rollback: 'Rolling back',
      stop_chaos: 'Stopping chaos experiments',
      remove_collector: 'Removing collector',
      remove_app: 'Removing application',
      delete_namespace: 'Deleting demo namespace',
      wait_terminate: 'Waiting for pods to terminate',
      delete_collector_ns: 'Deleting splunk namespace',
      apply_chaos: 'Applying chaos experiment',
      remove_chaos: 'Removing chaos experiment',
    },

    async init() {
      this.connectEventStream();
      await this.refreshState();
      if (!localStorage.getItem('diab-setup-done') && (!this.config.access_token || !this.config.realm)) {
        this.setupRequired = true;
      }
      this._pollInterval = setInterval(() => this.refreshState(), POLL_INTERVAL_MS);
      this.setupKeyboard();
      if (!localStorage.getItem('diab-kb-hint')) {
        setTimeout(() => this.toast('Press ? for keyboard shortcuts', 'info'), 2000);
        localStorage.setItem('diab-kb-hint', '1');
      }
      const validViews = ['demos', 'chaos', 'cluster'];
      const hash = location.hash.slice(1);
      if (validViews.includes(hash)) this.view = hash;
      window.addEventListener('hashchange', () => {
        const h = location.hash.slice(1);
        if (validViews.includes(h)) this.view = h;
      });
    },

    navigate(view) {
      this.view = view;
      location.hash = view;
    },

    _refreshing: false,
    async refreshState() {
      if (this._refreshing) return;
      this._refreshing = true;
      try {
        const [demos, deployment, chaos, config] = await Promise.all([
          api('/api/demos'), api('/api/demos/active'), api('/api/chaos'), api('/api/config'),
        ]);
        this.demos = demos;
        this.deployment = deployment;
        this.chaos = chaos;
        this.config = config;
        if (deployment.status === 'running' || deployment.status === 'deploying') {
          try {
            const pods = await api('/api/pods');
            const cp = pods.collector || [];
            this.collectorPods = { total: cp.length, ready: cp.filter(p => p.phase === 'Running').length };
          } catch { this.collectorPods = { total: 0, ready: 0 }; }
        } else {
          this.collectorPods = { total: 0, ready: 0 };
        }
      } catch (e) { console.error('Refresh failed:', e); }
      finally { this._refreshing = false; }
    },

    async deployDemo(id) {
      try {
        this.showModal('Deploying...');
        await api(`/api/demos/${id}/deploy`, { method: 'POST' });
      } catch (e) {
        this.hideModal();
        this.toast(e.message, 'error');
      }
    },

    async teardownDemo() {
      try {
        this.showModal('Tearing Down...');
        await api('/api/demos/teardown', { method: 'POST' });
      } catch (e) {
        this.hideModal();
        this.toast(e.message, 'error');
      }
    },

    async runChaos(id) {
      try {
        this.showModal('Starting Chaos...');
        await api(`/api/chaos/${id}/run`, { method: 'POST' });
      } catch (e) {
        this.hideModal();
        this.toast(e.message, 'error');
      }
    },

    async stopChaos(id) {
      try {
        this.showModal('Stopping Chaos...');
        await api(`/api/chaos/${id}/stop`, { method: 'POST' });
      } catch (e) {
        this.hideModal();
        this.toast(e.message, 'error');
      }
    },

    appConfirm(title, message, action = 'Confirm', variant = 'danger') {
      return new Promise((resolve) => {
        this.confirmTitle = title;
        this.confirmMessage = message;
        this.confirmAction = action;
        this.confirmVariant = variant;
        this._confirmResolve = resolve;
        this.confirmOpen = true;
      });
    },

    confirmResolve(result) {
      this.confirmOpen = false;
      if (this._confirmResolve) {
        this._confirmResolve(result);
        this._confirmResolve = null;
      }
    },

    showModal(title) {
      this.modalSteps = [];
      this.modalTitle = title;
      this.modalDone = false;
      this.modalOpen = true;
    },

    hideModal() {
      this.modalOpen = false;
    },

    async showYaml(kind, id) {
      try {
        const data = await api(`/api/yaml/${kind}/${id}`);
        this.yamlTitle = data.name;
        this.yamlContent = data.content;
        this.yamlHighlighted = Prism.highlight(data.content, Prism.languages.yaml, 'yaml');
        this.yamlCopied = false;
        this.yamlOpen = true;
      } catch (e) {
        this.toast('Failed to load YAML: ' + e.message, 'error');
      }
    },

    async copyYaml() {
      try {
        await navigator.clipboard.writeText(this.yamlContent);
        this.yamlCopied = true;
        setTimeout(() => { this.yamlCopied = false; }, 2000);
      } catch {
        this.toast('Failed to copy to clipboard', 'error');
      }
    },

    _wsRetryDelay: WS_RETRY_INITIAL_MS,
    connectEventStream() {
      if (eventsWs) { eventsWs.onclose = null; eventsWs.close(); }
      const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
      eventsWs = new WebSocket(`${proto}//${location.host}/ws/events`);
      eventsWs.onopen = () => { this._wsRetryDelay = WS_RETRY_INITIAL_MS; };
      eventsWs.onmessage = (e) => {
        let data;
        try { data = JSON.parse(e.data); } catch { return; }
        if (data.type === 'deployment' || data.type === 'teardown' || data.type === 'chaos') {
          const existing = this.modalSteps.find(s => s.key === data.step);
          if (existing) {
            existing.status = data.status;
            existing.message = data.message;
          } else {
            this.modalSteps.push({ key: data.step, status: data.status, message: data.message });
          }
          if (data.step === 'complete') {
            this.modalDone = true;
            setTimeout(() => this.refreshState(), 500);
            setTimeout(() => { this.modalOpen = false; }, MODAL_AUTO_CLOSE_MS);
          }
          if (data.step === 'error' || (data.step === 'rollback' && data.status === 'done')) {
            this.modalDone = true;
            setTimeout(() => this.refreshState(), 500);
          }
        }
        if (data.type === 'config_updated') {
          this.refreshState();
        }
      };
      eventsWs.onclose = () => {
        setTimeout(() => this.connectEventStream(), this._wsRetryDelay);
        this._wsRetryDelay = Math.min(this._wsRetryDelay * 2, WS_RETRY_MAX_MS);
      };
      eventsWs.onerror = () => eventsWs.close();
    },

    toast(message, type = 'info') {
      const id = Date.now() + Math.random();
      const t = { id, message, type, visible: true };
      this.toasts.push(t);
      setTimeout(() => {
        t.visible = false;
        setTimeout(() => {
          this.toasts = this.toasts.filter(x => x.id !== id);
        }, 300);
      }, TOAST_DURATION_MS);
    },

    _keyboardReady: false,
    setupKeyboard() {
      if (this._keyboardReady) return;
      this._keyboardReady = true;
      document.addEventListener('keydown', (e) => {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
        const views = { '1': 'demos', '2': 'chaos', '3': 'cluster' };
        if (e.key === '?') { this.helpOpen = !this.helpOpen; if (this.helpOpen) this.settingsOpen = false; }
        else if (e.key === '4') { this.settingsOpen = !this.settingsOpen; if (this.settingsOpen) this.helpOpen = false; }
        else if (views[e.key]) this.navigate(views[e.key]);
        else if (e.key === 'Escape') { this.helpOpen = false; }
      });
    },
  });
});
