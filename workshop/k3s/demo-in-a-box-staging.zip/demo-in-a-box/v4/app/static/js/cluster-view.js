function clusterView() {
  const HEALTH = {
    healthy:   { label: 'Running', cls: 'bg-green', textCls: 'text-green' },
    starting:  { label: 'Starting', cls: 'bg-yellow', textCls: 'text-yellow' },
    pending:   { label: 'Pending', cls: 'bg-yellow', textCls: 'text-yellow' },
    warning:   { label: 'Restarting', cls: 'bg-orange', textCls: 'text-orange' },
    crashloop: { label: 'CrashLoop', cls: 'bg-red', textCls: 'text-red' },
    failed:    { label: 'Failed', cls: 'bg-red', textCls: 'text-red' },
    unknown:   { label: 'Unknown', cls: 'bg-text-3', textCls: 'text-text-3' },
  };

  return {
    pods: [],
    _pollTimer: null,

    healthOf(pod) {
      if (pod.restartCount > 5) return HEALTH.crashloop;
      if (pod.phase === 'Failed') return HEALTH.failed;
      if (pod.restartCount > 0) return HEALTH.warning;
      if (pod.phase === 'Pending') return HEALTH.pending;
      if (pod.phase === 'Running' && pod.ready) return HEALTH.healthy;
      if (pod.phase === 'Running') return HEALTH.starting;
      return HEALTH.unknown;
    },

    formatAge(iso) {
      if (!iso) return '—';
      const s = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
      if (s < 60) return s + 's';
      if (s < 3600) return Math.floor(s / 60) + 'm';
      if (s < 86400) return Math.floor(s / 3600) + 'h ' + Math.floor((s % 3600) / 60) + 'm';
      return Math.floor(s / 86400) + 'd';
    },

    get nodeCount() {
      return new Set(this.pods.map(p => p.node).filter(Boolean)).size;
    },

    get statusCounts() {
      const counts = {};
      for (const p of this.pods) {
        const h = this.healthOf(p);
        counts[h.label] = counts[h.label] || { label: h.label, cls: h.cls, count: 0 };
        counts[h.label].count++;
      }
      const order = ['Running', 'Starting', 'Pending', 'Restarting', 'CrashLoop', 'Failed', 'Unknown'];
      return Object.values(counts).sort((a, b) => order.indexOf(a.label) - order.indexOf(b.label));
    },

    get podsByNamespace() {
      const groups = {};
      for (const p of this.pods) {
        const ns = p.namespace || 'unknown';
        if (!groups[ns]) groups[ns] = [];
        groups[ns].push(p);
      }
      const severity = (p) => {
        const order = { CrashLoop: 0, Failed: 1, Restarting: 2, Pending: 3, Starting: 4, Unknown: 5, Running: 6 };
        return order[this.healthOf(p).label] ?? 6;
      };
      for (const ns in groups) {
        groups[ns].sort((a, b) => severity(a) - severity(b) || (a.app || a.name).localeCompare(b.app || b.name));
      }
      return Object.entries(groups).sort((a, b) => {
        if (a[0] === 'splunk') return -1;
        if (b[0] === 'splunk') return 1;
        return a[0].localeCompare(b[0]);
      });
    },

    async activate() {
      await this.fetchPods();
      this._pollTimer = setInterval(() => this.fetchPods(), POLL_INTERVAL_MS);
    },

    deactivate() {
      if (this._pollTimer) { clearInterval(this._pollTimer); this._pollTimer = null; }
    },

    async fetchPods() {
      try {
        const data = await api('/api/pods');
        this.pods = [...(data.collector || []), ...(data.app || [])];
      } catch { this.pods = []; }
    },
  };
}
