# Deployment Guide

Demo-in-a-Box runs directly on a machine with access to a
Kubernetes cluster. It requires `kubectl`, `helm`, and
Python 3.14+.

## Prerequisites

| Tool       | Version | Purpose                        |
| ---------- | ------- | ------------------------------ |
| Python     | 3.14+   | Application runtime            |
| uv         | Latest  | Python package manager         |
| kubectl    | Latest  | Kubernetes cluster access      |
| helm       | 3.x     | Splunk OTel Collector install  |
| Kubernetes | 1.24+   | Target for demo deployments    |

Ensure `kubectl` is configured and can reach your cluster:

```bash
kubectl cluster-info
```

## Quick Start

```bash
cd demo-in-a-box/v4
./diab.sh start
```

The startup script handles everything:

1. Validates prerequisites (kubectl, helm, uv, cluster)
2. Creates a Python virtual environment via `uv`
3. Installs dependencies from `requirements.txt`
4. Adds the Splunk OTel Collector Helm repo
5. Starts the application on port 8082

Open `http://localhost:8082` in your browser.

## Manual Start

If you prefer to run manually:

```bash
cd demo-in-a-box/v4

# Create venv and install deps
uv venv --python 3.14 .venv
source .venv/bin/activate
uv pip install -r requirements.txt

# Create data directory
mkdir -p data

# Start
export PORT=8082
export DATABASE_URL="sqlite+aiosqlite:///./data/demo-in-a-box.db"
python app/main.py
```

## Environment Variables

| Variable       | Default                  | Description          |
| -------------- | ------------------------ | -------------------- |
| `PORT`         | `8082`                   | HTTP server port     |
| `DATABASE_URL` | `sqlite+aiosqlite:///..` | SQLite database path |
| `KUBECONFIG`   | `~/.kube/config`         | Kubeconfig file path |
| `KUBECTL_PATH` | `kubectl`                | kubectl binary path  |
| `HELM_PATH`    | `helm`                   | helm binary path     |
| `DEV`          | `false`                  | Enable auto-reload   |

## First-Time Setup

On first launch, the app shows a setup modal prompting you
to configure Splunk credentials.

**Required fields (all marked with *):**

- **Realm** — Splunk Observability Cloud realm
  (e.g., `us1`, `eu0`)
- **Ingest Token** — Token with ingest scope
- **API Token** — Token with API scope
- **RUM Token** — For Real User Monitoring
- **Instance Name** — Used for cluster name and env tags
- **HEC URL** — Splunk Platform HTTP Event Collector URL
- **HEC Token** — Splunk Platform HEC authentication token

**Optional fields:**

- **Splunk Index** — HEC target index (defaults to
  `o11y-demo-eu`)

## Deploying on a Remote Server

### Syncing to a Remote Host

Use `sync.sh` to push the project to any SSH host:

```bash
./sync.sh <hostname>
```

This rsyncs the project (excluding `.venv`, `data`,
`__pycache__`, `.git*`, `.claude`) to
`~/demo-in-a-box-v4/` on the target. The hostname must
be configured in your `~/.ssh/config`.

### EC2 / VM

1. Sync the project: `./sync.sh my-ec2-host`
2. SSH into the server
3. Install prerequisites: Python 3.14, kubectl, helm
4. Configure kubectl to reach your K8s cluster
5. Start: `./diab.sh start`
6. Access via `http://<server-ip>:8082`

### K3s on the Same Machine

Demo-in-a-Box works well alongside a local K3s cluster:

```bash
# Install K3s
curl -sfL https://get.k3s.io | sh -

# Copy kubeconfig
mkdir -p ~/.kube
sudo cp /etc/rancher/k3s/k3s.yaml ~/.kube/config
sudo chown $(id -u):$(id -g) ~/.kube/config

# Start Demo-in-a-Box
./diab.sh start
```

## Managing the Application

Use `diab.sh` to manage the background process:

```bash
./diab.sh start     # pre-flight checks + background launch
./diab.sh stop      # graceful shutdown
./diab.sh restart   # stop + start
./diab.sh status    # show running state and PID
./diab.sh logs      # tail the log file
```

PID is stored in `.diab.pid`, logs in `diab.log`.

## Data Persistence

- **SQLite database** — Stored in `data/demo-in-a-box.db`.
  Contains credentials, deployment state, and chaos state.
  The `data/` directory is created automatically.
- **Demo/chaos definitions** — Read from `demos/` and
  `chaos/` directories on each request (supports hot-reload).

## Troubleshooting

### Cannot connect to Kubernetes cluster

Verify kubectl access: `kubectl cluster-info`. Check that
`KUBECONFIG` points to a valid config file.

### Collector ingest token not configured

Open Settings (gear icon) and fill in all required fields
(marked with *): Realm, Ingest Token, API Token, RUM Token,
Instance Name, HEC URL, and HEC Token.

### Deployment stuck in "Deploying" state

Use the Reset button in Settings to force-clear all state.
This tears down running resources and resets the database.

### Pods not becoming ready

Check pod status directly:

```bash
kubectl get pods -n <namespace> -o wide
```

Common issues: image pull failures, resource limits,
node capacity.

### Port already in use

Set a different port: `PORT=9090 ./diab.sh start`
