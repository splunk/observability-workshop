#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

PORT="${PORT:-8082}"
VENV_DIR=".venv"
PID_FILE="$SCRIPT_DIR/.diab.pid"
LOG_FILE="$SCRIPT_DIR/diab.log"

GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

_is_running() {
    [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null
}

_setup() {
    echo -e "${YELLOW}[1/3]${NC} Checking prerequisites..."

    if ! command -v kubectl &> /dev/null; then
        echo "  ✗ kubectl not found."; exit 1
    fi
    echo "  ✓ kubectl"

    if ! command -v helm &> /dev/null; then
        echo "  ✗ helm not found."; exit 1
    fi
    echo "  ✓ helm"

    if ! kubectl cluster-info &> /dev/null; then
        echo "  ✗ Cannot connect to Kubernetes cluster."; exit 1
    fi
    echo "  ✓ Kubernetes cluster reachable"

    if ! command -v python3 &> /dev/null; then
        echo "  ✗ python3 not found."; exit 1
    fi
    echo "  ✓ python3 $(python3 --version 2>&1 | awk '{print $2}')"

    echo -e "${YELLOW}[2/3]${NC} Setting up Python environment..."
    if [ ! -d "$VENV_DIR" ]; then
        python3 -m venv "$VENV_DIR"
        echo "  ✓ Created virtual environment"
    else
        echo "  ✓ Virtual environment exists"
    fi
    source "$VENV_DIR/bin/activate"
    pip install -q --upgrade pip
    pip install -q -r requirements.txt
    echo "  ✓ Dependencies installed"

    mkdir -p data
}

cmd_start() {
    if _is_running; then
        echo -e "${YELLOW}Demo-in-a-Box is already running (PID $(cat "$PID_FILE"))${NC}"
        exit 0
    fi

    echo -e "${CYAN}╔══════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║        Demo-in-a-Box - Startup       ║${NC}"
    echo -e "${CYAN}╚══════════════════════════════════════╝${NC}"
    echo ""

    _setup

    echo -e "${YELLOW}[3/3]${NC} Starting Demo-in-a-Box..."

    export PORT
    export DATABASE_URL="sqlite+aiosqlite:///./data/demo-in-a-box.db"

    source "$VENV_DIR/bin/activate"
    nohup python app/main.py > "$LOG_FILE" 2>&1 &
    echo $! > "$PID_FILE"

    sleep 1
    if _is_running; then
        echo ""
        echo -e "${GREEN}══════════════════════════════════════${NC}"
        echo -e "${GREEN}  Demo-in-a-Box running on port ${PORT}${NC}"
        echo -e "${GREEN}  PID: $(cat "$PID_FILE")${NC}"
        echo -e "${GREEN}  Log: ${LOG_FILE}${NC}"
        echo -e "${GREEN}══════════════════════════════════════${NC}"
    else
        echo -e "${RED}Failed to start. Check ${LOG_FILE}${NC}"
        rm -f "$PID_FILE"
        exit 1
    fi
}

cmd_stop() {
    if ! _is_running; then
        echo -e "${YELLOW}Demo-in-a-Box is not running${NC}"
        rm -f "$PID_FILE"
        exit 0
    fi

    local pid
    pid=$(cat "$PID_FILE")
    echo -e "Stopping Demo-in-a-Box (PID ${pid})..."
    kill "$pid" 2>/dev/null
    for i in $(seq 1 10); do
        if ! kill -0 "$pid" 2>/dev/null; then
            break
        fi
        sleep 0.5
    done
    if kill -0 "$pid" 2>/dev/null; then
        echo -e "${YELLOW}Force killing...${NC}"
        kill -9 "$pid" 2>/dev/null
    fi
    rm -f "$PID_FILE"
    echo -e "${GREEN}Stopped${NC}"
}

cmd_restart() {
    cmd_stop
    cmd_start
}

cmd_status() {
    if _is_running; then
        local pid
        pid=$(cat "$PID_FILE")
        echo -e "${GREEN}Running${NC} (PID ${pid}, port ${PORT})"
    else
        echo -e "${RED}Not running${NC}"
        rm -f "$PID_FILE"
    fi
}

cmd_logs() {
    if [ ! -f "$LOG_FILE" ]; then
        echo "No log file found"
        exit 1
    fi
    tail -f "$LOG_FILE"
}

case "${1:-}" in
    start)   cmd_start ;;
    stop)    cmd_stop ;;
    restart) cmd_restart ;;
    status)  cmd_status ;;
    logs)    cmd_logs ;;
    *)
        echo "Usage: $0 {start|stop|restart|status|logs}"
        exit 1
        ;;
esac
