#!/usr/bin/env bash
set -euo pipefail

if [ -z "${1:-}" ]; then
    echo "Usage: $0 <hostname>"
    echo "Example: $0 demo"
    echo "         $0 diab-v4"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
rsync -avz --delete \
    --exclude '.venv' \
    --exclude '.git*' \
    --exclude '.claude' \
    --exclude 'data' \
    --exclude '__pycache__' \
    --exclude 'diab.log' \
    --exclude '.diab.pid' \
    --exclude '*.db' \
    "$SCRIPT_DIR/" "$1":~/demo-in-a-box-v4/
