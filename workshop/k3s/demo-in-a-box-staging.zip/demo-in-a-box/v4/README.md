# Demo-in-a-Box v4

A web UI for deploying Splunk Observability demo applications
onto Kubernetes clusters. Deploys demo apps and the Splunk
OpenTelemetry Collector, streams real-time logs, and supports
chaos engineering experiments.

## Features

- **Demo Deployments** — One-click deploy of pre-configured
  demo apps with the Splunk OTel Collector
- **Chaos Engineering** — Inject CPU stress, network latency,
  and pod failures into running demos
- **Real-time Log Streaming** — WebSocket-powered log viewer
  for collector and application pods with search and wrap toggle
- **YAML Viewer** — Syntax-highlighted Kubernetes manifest
  inspector with copy-to-clipboard
- **Configuration Management** — Splunk Observability Cloud
  and Splunk Platform (HEC) credentials stored in SQLite
- **Remote Config API** — Configure credentials via curl for
  headless/automated setups
- **Keyboard Shortcuts** — `1-3` for views, `4` for settings,
  `?` for help

## Architecture

```text
┌──────────────────────────────────────────────┐
│  Browser (Alpine.js + Tailwind CSS)          │
│  Single-page app: /templates/index.html      │
└─────────┬─────────────────────┬──────────────┘
          │ REST API            │ WebSocket
          │                     │
┌─────────▼─────────────────────▼──────────────┐
│  FastAPI (Python 3.14)                       │
│  app/main.py      — routes, WebSocket        │
│  app/deployer.py  — deploy/teardown/chaos    │
│  app/k8s.py       — kubectl/helm wrappers    │
│  app/db.py        — SQLAlchemy + SQLite      │
└─────────┬────────────────────────────────────┘
          │ kubectl / helm
          ▼
┌──────────────────────────────────────────────┐
│  Kubernetes Cluster                          │
│  - splunk namespace (OTel Collector)         │
│  - demo namespace (application pods)         │
└──────────────────────────────────────────────┘
```

## Project Structure

```text
v4/
├── app/
│   ├── main.py          # FastAPI routes + WebSockets
│   ├── deployer.py      # Deploy/teardown/chaos logic
│   ├── k8s.py           # kubectl and helm wrappers
│   ├── db.py            # SQLAlchemy models + DB init
│   ├── help.yaml        # Help panel content
│   ├── templates/
│   │   └── index.html   # SPA frontend (Jinja2)
│   └── static/
│       └── js/          # Alpine.js components
├── demos/               # Demo definition YAMLs
├── demo-manifests/      # K8s manifests (one subdir per demo)
│   ├── hello-world/     #   kubectl apply -f demo-manifests/hello-world
│   ├── online-boutique/ #   supports multiple manifests per demo
│   └── .../
├── chaos/               # Chaos experiment definitions
├── chaos-manifests/     # Chaos Mesh manifest templates
├── collector/           # OTel Collector Helm values
├── requirements.txt     # Python dependencies
├── diab.sh              # start/stop/restart/status/logs
├── sync.sh              # rsync to remote host
└── .env.example         # Environment variable reference
```

## Adding Demos

### 1. Create the demo definition

Create a YAML file in `demos/` (the filename becomes the demo ID):

```yaml
name: "My Demo"
description: |
  Markdown description shown on the card.
icon: "shopping_cart"              # Material Symbols icon name
namespace: "my-demo"
manifest: "demo-manifests/my-demo" # points to a directory
collector:
  version: "0.145.0"
  values: "collector/values-template.yaml"
tags:
  - microservices
  - grpc
# Optional fields:
extra_namespaces:       # if manifest creates own namespaces
  - api-gateway-system
environment: "custom"   # override environment tag name
app_suffix: "app"       # override app name suffix
url: "http://frontend"  # override workshop secret URL
```

### 2. Create the manifest directory

Each demo has its own subdirectory under `demo-manifests/`.
All `.yaml` files in the directory are applied together via
`kubectl apply -f <dir>`:

```text
demo-manifests/
└── my-demo/
    ├── deployment.yaml    # single file is fine too
    ├── service.yaml       # or split resources across files
    └── configmap.yaml     # kubectl applies all of them
```

A single manifest file per directory works — this just gives
you the option to split large manifests into separate files
when it makes sense.

### Demo notes

- When a manifest hardcodes `metadata.namespace` on its
  resources (e.g., Silk), declare those namespaces in
  `extra_namespaces`. The deploy flow will create them
  beforehand, skip the `-n` flag during `kubectl apply`,
  and clean them up on teardown.
- The `icon` field uses [Material Symbols](https://fonts.google.com/icons)
  icon names (e.g., `shopping_cart`, `pets`, `satellite_alt`).

## Adding Chaos Experiments

### 1. Create the chaos definition

Create a YAML file in `chaos/` (the filename becomes the experiment ID):

```yaml
name: "CPU Stress"
description: "Generates CPU load on targeted pods."
icon: "local_fire_department"      # Material Symbols icon name
severity: "medium"                 # low, medium, or high
applies_to:                        # restrict to specific demo IDs
  - online-boutique
  - astronomy-shop
manifest: "chaos-manifests/cpu-stress.yaml"
# Optional fields:
waitForPods: false  # skip pod readiness check (default: true)
duration: 600       # auto-stop after N seconds (optional)
```

### 2. Create the chaos manifest

Place a single Chaos Mesh manifest in `chaos-manifests/`.
Use `{{ namespace }}` as a Jinja2 template variable — it is
replaced with the running demo's namespace at apply time:

```yaml
apiVersion: chaos-mesh.org/v1alpha1
kind: StressChaos
metadata:
  name: cpu-stress
spec:
  mode: one
  selector:
    namespaces:
      - "{{ namespace }}"
    labelSelectors: {}
  stressors:
    cpu:
      workers: 2
      load: 80
  duration: "120s"
```

### Chaos notes

- Chaos manifests are single files (not directories) because
  they require Jinja2 rendering before apply.
- Set `waitForPods: false` for experiments that intentionally
  create broken pods (crash loops, image pull failures, stuck
  init). Omit or set `true` for Chaos Mesh experiments that
  modify existing running pods.
- The `applies_to` list uses demo IDs (the filename stem from
  `demos/`, e.g., `astronomy-shop`, `online-boutique`).
- The `duration` field (in seconds) is tracked in the UI. If
  omitted, the experiment runs until manually stopped.

## API Reference

| Method | Endpoint                 | Description                   |
| ------ | ------------------------ | ----------------------------- |
| GET    | `/api/demos`             | List all demos with status    |
| GET    | `/api/demos/active`      | Get current deployment state  |
| POST   | `/api/demos/{id}/deploy` | Deploy a demo                 |
| POST   | `/api/demos/teardown`    | Tear down the running demo    |
| GET    | `/api/chaos`             | List chaos experiments        |
| POST   | `/api/chaos/{id}/run`    | Start a chaos experiment      |
| POST   | `/api/chaos/{id}/stop`   | Stop a chaos experiment       |
| GET    | `/api/config`            | Get Splunk configuration      |
| POST   | `/api/config`            | Save configuration (JSON)     |
| POST   | `/saveConfig`            | Save configuration (form)     |
| GET    | `/api/yaml/{kind}/{id}`  | Get manifest YAML source      |
| GET    | `/api/pods`              | List pods by namespace        |
| POST   | `/api/reset`             | Reset all deployments         |
| GET    | `/api/health`            | Health check                  |
| WS     | `/ws/events`             | Real-time deployment events   |
| WS     | `/ws/logs/{type}`        | Stream pod logs               |

## Remote Configuration

Configure credentials via curl for automated setups.
Required fields are `realm`, `ingest_token`, `api_token`,
`rum_token`, `instance`, `hec_url`, and `hec_token`. The `splunk_index`
field is optional (defaults to `o11y-demo-eu`):

```bash
curl -X POST http://localhost:8082/saveConfig \
  -d "realm=us1" \
  -d "ingest_token=YOUR_INGEST_TOKEN" \
  -d "api_token=YOUR_API_TOKEN" \
  -d "rum_token=YOUR_RUM_TOKEN" \
  -d "instance=my-instance" \
  -d "hec_url=https://splunk:8088/services/collector/event" \
  -d "hec_token=YOUR_HEC_TOKEN" \
  -d "splunk_index=o11y-demo-eu"
```
