# Demo-in-a-Box v3

Demo-in-a-Box (DIAB) v3 is a comprehensive demonstration platform for Splunk Observability Cloud that provides a streamlined interface for deploying, managing, and demonstrating various observability use cases using OpenTelemetry and Kubernetes.

## Overview

DIAB v3 is built with Streamlit and Flask, providing both a web-based UI and a RESTful API for managing demonstration environments. It automates the deployment of multiple demo applications with pre-configured OpenTelemetry collectors, making it easy to showcase different observability scenarios and capabilities.

## Features

- **Web-Based UI**: Intuitive Streamlit interface for managing demo deployments
- **Multiple Use Cases**: Pre-configured demonstrations for various observability scenarios
- **OpenTelemetry Integration**: Automated OpenTelemetry Collector configuration and deployment
- **Chaos Engineering**: Built-in chaos experiments using Chaos Mesh
- **Kubernetes Native**: Fully integrated with Kubernetes for container orchestration
- **RESTful API**: Programmatic access to configuration and management functions
- **Real-Time Monitoring**: View pod status, logs, and collector health in real-time
- **Multi-Demo Support**: Deploy and switch between different demo applications seamlessly

## Architecture

DIAB v3 consists of the following components:

- **Manager UI** (`manager-ui.py`): Streamlit-based web interface running on port 8501
- **Manager API** (`manager-api.py`): Flask REST API running on port 8082
- **Demo Library** (`lib/splunk.py`): Core functionality for managing deployments and configurations
- **Use Cases** (`use-cases.yaml`): Configuration file defining available demonstrations
- **Deployments** (`deployments/`): Kubernetes manifests for various demo applications
- **OpenTelemetry Collector** (`opentelemetry-collector/`): Custom values files for OTel collector configurations
- **Chaos Engineering** (`chaos-mesh/`): Pre-configured chaos experiments

## Prerequisites

- Kubernetes cluster (v1.20+)
- `kubectl` configured to access your cluster
- `helm` (v3.0+)
- Python 3.8 or higher
- Splunk Observability Cloud account with:
  - Access Token (ingest token)
  - Realm information
  - (Optional) RUM token for Real User Monitoring demos
  - (Optional) HEC endpoint and token for log ingestion

## Installation

### 1. Clone the Repository

```bash
cd /path/to/demo-in-a-box/v3
```

### 2. Run Setup Script

```bash
./scripts/setup.sh
```

This will:

- Create a Python virtual environment
- Install required dependencies from `requirements.txt`

### 3. Configure Secrets

Create or update `.streamlit/secrets.toml` with your configuration:

```toml
version = "3.0.0"
debug = false

# Add other configuration as needed
```

### 4. Start the Services

Start the Manager API:

```bash
./scripts/run-manager-api.sh
```

Start the Manager UI:

```bash
./scripts/run-manager-ui.sh
```

If running as systemd services:

```bash
sudo systemctl start diab-manager-api
sudo systemctl start diab-manager-ui
```

## Configuration

### Using the Manager API

Configure the OpenTelemetry Collector using the `/saveConfig` endpoint:

```bash
curl -X POST http://localhost:8082/saveConfig \
  -d "realm=us1" \
  -d "ingest_token=YOUR_INGEST_TOKEN" \
  -d "rum_token=YOUR_RUM_TOKEN" \
  -d "instance=my-demo-instance"
```

#### Optional HEC Configuration

For log ingestion to Splunk Platform:

```bash
curl -X POST http://localhost:8082/saveConfig \
  -d "realm=us1" \
  -d "ingest_token=YOUR_INGEST_TOKEN" \
  -d "rum_token=YOUR_RUM_TOKEN" \
  -d "instance=my-demo-instance" \
  -d "hec_url=https://your-hec-endpoint.com:8088/services/collector/event" \
  -d "hec_token=YOUR_HEC_TOKEN" \
  -d "splunk_index=demo_logs"
```

## Using DIAB v3

### Deploying a Demo

1. Access the web UI at `http://localhost:8501`
2. Review available use cases on the main page
3. Click "Deploy" on your desired use case
4. Wait for the deployment to complete (the UI will show progress)
5. Access the deployed application through the provided environment name

### Viewing Deployment Status

Navigate to "Kubernetes" > "Pod Status/Logs" to:

- View real-time pod status
- Access pod logs
- Monitor deployment health

### Managing the OpenTelemetry Collector

Navigate to "OpenTelemetry Collector" > "Collector Configuration/Status/Logs" to:

- View current configuration
- Check collector health and status
- Access collector logs
- Update configuration

### Stopping a Demo

1. Navigate to the main "Use Cases" page
2. Click "Stop" on the running demo
3. Wait for the resources to be cleaned up

## Chaos Engineering

DIAB v3 includes Chaos Mesh integration for testing system resilience.

### Available Chaos Experiments

Navigate to "Chaos Engineering" > "Chaos Experiments" to access:

- **Database Delays**: Inject latency into database connections
- **Network Partitions**: Simulate network failures
- **Pod Failures**: Test pod crash scenarios
- **Resource Stress**: Apply CPU/Memory pressure
- **Storage Failures**: Simulate PVC failures
- **Redis Failures**: Test cache layer resilience
- **Kafka Stress**: Apply message queue pressure

### Deploying Chaos Experiments

1. Ensure a demo is deployed first
2. Navigate to the Chaos Engineering page
3. Select an appropriate experiment for your deployment
4. Click "Deploy" to start the experiment
5. Monitor the impact in Splunk Observability Cloud

## Environment Naming Convention

Deployed demos use the following naming convention in Splunk Observability Cloud:

```text
{instance}-{demo-name}
```

For example, if your instance is `rwc` and you deploy the `frontend-ocm` demo, the environment will be named `rwc-frontend-ocm`.

### Inspect Kubernetes Secrets

```bash
kubectl get secret workshop-secret -o json | jq '.data | map_values(@base64d)'
```

---

© 2025 Splunk Inc. All rights reserved.
