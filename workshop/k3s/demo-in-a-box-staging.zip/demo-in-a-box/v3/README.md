# DIAB Manager

## Manager API Endpoint

The DIAB Manager API runs on port **8082** and provides endpoints for managing the Demo-in-a-Box configuration.

### Check API Status

Check if the API is running:

``` bash
curl http://localhost:8082/
```

**Response:**
```
Demo-in-a-Box v3.x.x - OK
```

### Save Collector Configuration

Configure the OpenTelemetry Collector settings using the `/saveConfig` endpoint.

**Required Parameters:**

- `realm` - Splunk Observability realm (e.g., us0, us1, eu0)
- `ingest_token` - Splunk Observability ingest token
- `instance` - Instance identifier/name

**Optional Parameters:**

- `rum_token` - RUM (Real User Monitoring) token
- `hec_url` - HEC (HTTP Event Collector) URL (defaults to `https://ingest.<realm>.signalfx.com/v1/log`)
- `hec_token` - HEC token (defaults to ingest_token if not provided)
- `splunk_index` - Splunk index name (defaults to `main`)

**Example curl command:**

``` bash
curl -X POST http://localhost:8082/saveConfig \
  -d "realm=us1" \
  -d "ingest_token=YOUR_INGEST_TOKEN" \
  -d "rum_token=YOUR_RUM_TOKEN" \
  -d "instance=my-demo-instance"
```

**Example with HEC configuration:**

``` bash
curl -X POST http://localhost:8082/saveConfig \
  -d "realm=us1" \
  -d "ingest_token=YOUR_INGEST_TOKEN" \
  -d "rum_token=YOUR_RUM_TOKEN" \
  -d "instance=my-demo-instance" \
  -d "hec_url=https://your-hec-endpoint.com:8088/services/collector/event" \
  -d "hec_token=YOUR_HEC_TOKEN" \
  -d "splunk_index=demo_logs"
```

**Success Response (200):**
``` json
{
  "message": "Configuration saved successfully",
  "sql": ["OpenTelemetry configuration saved!", 200]
}
```

**Error Response (400):**
``` json
{
  "realm": "Realm is required",
  "ingest_token": "Ingest_token is required",
  "instance": "Instance is required"
}
```

## Inspect Kubernetes secrets

``` bash
kubectl get secret workshop-secret -o json | jq '.data | map_values(@base64d)'
```

## Restart DIAB Manager services

``` bash
sudo systemctl restart diab-manager-api
sudo systemctl restart diab-manager-ui
```

## Secrets to be used in the YAML deployment files

``` ini
instance = 'instance-name' - 'current running demo' e.g. rwc-frontend
development = 'development.environment=instance name' - 'current running demo' e.g. rwc-frontend-store
app = 'instance name' - 'current running demo' - 'store' e.g. rwc-frontend-store (RUM)
```
