import streamlit as st  # type: ignore
from lib import splunk as demo  # type: ignore
from lib.ui_helpers import debug_panel, format_description, render_card_grid

dm = demo.get_demo_manager()
available_experiments = dm.available_experiments()
current_demo = dm.current_demo()

status_updates = st.container()


def deploy_chaos(name, experiment):
    status_updates.empty()
    with status_updates.status(f"Deploying {name}...", expanded=True) as status:
        chaos = dm.deploy_chaos(experiment)
        status.code(chaos[0])
        status.update(label=f"Deployed: {name}", state="complete", expanded=False)


# Filter experiments for current deployment
filtered_experiments = [
    e for e in available_experiments
    if e['deployment'] == current_demo['deployment'] or e['deployment'] == 'ALL'
]


def render_experiment_card(experiment):
    """Render a single chaos experiment card."""
    st.markdown(f"##### :blue[{experiment['name']}]")

    # Show target info
    target = "All deployments" if experiment['deployment'] == 'ALL' else experiment['deployment']
    st.caption(f"Target: {target}")

    with st.expander("Description", expanded=False):
        st.markdown(format_description(experiment['description']))

    st.button(
        ":material/experiment: Deploy",
        key=experiment['experiment'],
        type="primary",
        width="content",
        on_click=deploy_chaos,
        args=(experiment["name"], experiment["experiment"])
    )


if current_demo["name"] == "None":
    st.info(":material/info: Deploy a demo from the **Use Cases** page to access chaos experiments.")
elif not filtered_experiments:
    st.warning("No chaos experiments are configured for this demo.")
else:
    render_card_grid(filtered_experiments, n_cols=3, render_card_fn=render_experiment_card)

debug_panel()
