import time

import streamlit as st  # type: ignore
from lib import splunk as demo  # type: ignore

if "helm_repo_updated" not in st.session_state:
    st.session_state.helm_repo_updated = False

dm = demo.DemoManager()

available_experiments = dm.available_experiments()
current_demo = dm.current_demo()
#current_experiment = dm.current_experiment()

def deploy_chaos(name, experiment):
    status_updates.empty()

    with status_updates.status(
        f"{name}", expanded=True
    ) as status:
        chaos = dm.deploy_chaos(experiment)
        status.code(chaos[0])
        time.sleep(2)
        status.update(label=f"{name}", state="complete", expanded=False)

status_updates = st.container()

st.subheader("Available Chaos Experiments")

st.divider()

# Filter experiments for current deployment
filtered_experiments = [
    e for e in available_experiments
    if e['deployment'] == current_demo['deployment'] or e['deployment'] == 'ALL'
]

if not filtered_experiments:
    st.info("No chaos experiments available for the current deployment. Deploy a demo first.")
else:
    # Create grid layout with proper spacing
    n_cols = 3
    demos_per_row = n_cols
    experiment_rows = [filtered_experiments[i:i + demos_per_row] for i in range(0, len(filtered_experiments), demos_per_row)]

    for experiment_row in experiment_rows:
        cols = st.columns(n_cols, gap="medium")

        for idx, e in enumerate(experiment_row):
            with cols[idx]:
                # Custom styled card with button inside
                with st.container(border=True):
                    # Title
                    st.markdown(f"##### :blue[{e['name']}]")

                    # # Deployment target
                    # st.markdown("**Deployment**")
                    # st.code(e['deployment'], language=None)

                    # Description
                    with st.expander("**Description**", expanded=False):
                        # Replace newlines with proper markdown line breaks
                        description_with_breaks = e['description'].replace('\n', '  \n')
                        st.markdown(description_with_breaks)

                    # Deploy button at bottom
                    st.button(
                        ":material/experiment: Deploy Experiment",
                        key=e['experiment'],
                        type="primary",
                        width="content",
                        on_click=deploy_chaos,
                        args=(e["name"], e["experiment"])
                    )
                    time.sleep(2)
if st.secrets.debug:
    st.json(st.session_state)