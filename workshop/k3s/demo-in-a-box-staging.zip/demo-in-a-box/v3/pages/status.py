import streamlit as st  # type: ignore
from lib import splunk as demo  # type: ignore
from lib.ui_helpers import debug_panel, get_status_color, render_pod_grid

dm = demo.get_demo_manager()
current = dm.current_demo()


def parse_pod_key(pod_key):
    """Parse namespace/pod_name into tuple."""
    parts = pod_key.split("/", 1)
    return (parts[0], parts[1]) if len(parts) == 2 else ("default", pod_key)


if current["name"] == "None":
    st.info(":material/info: No demo currently deployed. Deploy a demo from the **Use Cases** page to view pod status.")
else:
    demo_dict = dm.demo_status()

    if not demo_dict:
        st.warning("No pods found. Pods may still be starting up.")
        if st.button(":material/refresh: Refresh"):
            st.rerun()
    else:
        # Group pods by namespace
        namespaces = {}
        for pod_key, state in demo_dict.items():
            namespace, pod_name = parse_pod_key(pod_key)
            if namespace not in namespaces:
                namespaces[namespace] = []
            namespaces[namespace].append({"key": pod_key, "name": pod_name, "status": state})

        # Metrics
        running = sum(1 for s in demo_dict.values() if s == "Running")
        pending = sum(1 for s in demo_dict.values() if s in ["Pending", "ContainerCreating"])
        failed = sum(1 for s in demo_dict.values() if s in ["Error", "CrashLoopBackOff", "Failed", "ImagePullBackOff"])

        m1, m2, m3, m4, m5 = st.columns(5)
        m1.metric("Demo", current["name"])
        m2.metric("Namespaces", len(namespaces))
        m3.metric(":material/check_circle: Running", running)
        m4.metric(":material/pending: Pending", pending)
        m5.metric(":material/error: Failed", failed)

        st.divider()

        col_pods, col_logs = st.columns([1, 2])

        with col_pods:
            # Render each namespace as a container with pod buttons
            for namespace, pods in sorted(namespaces.items()):
                with st.container(border=True):
                    st.markdown(f"**:blue[{namespace}]**")
                    if render_pod_grid(pods, "pod_name", cols=3, truncate_len=20, show_status_color=True):
                        st.rerun()

            if st.button(":material/refresh: Refresh", key="refresh_pods"):
                st.rerun()

        with col_logs:
            @st.fragment
            def logs_fragment():
                if st.session_state.get("pod_name"):
                    namespace, pod_name = parse_pod_key(st.session_state.pod_name)
                    logs, code = dm.get_pod_logs(pod_name, namespace)

                    with st.container(border=True, height=500):
                        if code == 0:
                            st.code(logs, language="log")
                        else:
                            st.error(logs)

                    if st.button(":material/refresh: Refresh", key="refresh_logs"):
                        st.rerun(scope="fragment")
                else:
                    st.info("Select a pod to view logs.")

            logs_fragment()

debug_panel()
