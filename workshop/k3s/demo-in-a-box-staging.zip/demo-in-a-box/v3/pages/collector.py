import time

import streamlit as st  # type: ignore
from lib import splunk as demo  # type: ignore
from lib.ui_helpers import debug_panel, render_pod_grid

dm = demo.get_demo_manager()
current = dm.current_demo()


def enable_form():
    st.session_state["disable_form"] = False


col1, col2 = st.columns([1, 2])

with col1:
    st.markdown("#### :blue[Configuration]")

    values = dm.get_collector_config()

    with st.form("config_form"):
        instance = st.text_input("**:grey[Instance Name]**", value=values["instance"], disabled=True)
        realm = st.text_input(
            "**Splunk Observability Cloud Realm**",
            value=values["realm"],
            disabled=st.session_state["disable_form"],
        )
        ingest_token = st.text_input(
            "**Splunk Observability Cloud Ingest Token**",
            type="password",
            value=values["ingest_token"],
            disabled=st.session_state["disable_form"],
        )
        rum_token = st.text_input(
            "**Splunk Observability Cloud RUM Token**",
            type="password",
            value=values["rum_token"],
            disabled=st.session_state["disable_form"],
        )
        hec_url = st.text_input(
            "**Splunk Cloud HEC URL**",
            value=values["hec_url"],
            placeholder="Splunk HEC URL",
            disabled=st.session_state["disable_form"],
        )
        hec_token = st.text_input(
            "**Splunk Cloud HEC Token**",
            type="password",
            value=values["hec_token"],
            placeholder="Splunk HEC Token",
            disabled=st.session_state["disable_form"],
        )
        splunk_index = st.text_input(
            "**Splunk Cloud Index**",
            value=values["splunk_index"],
            placeholder="Splunk Index",
            disabled=st.session_state["disable_form"],
        )

        if st.session_state["disable_form"]:
            st.form_submit_button(
                ":material/edit: Edit Configuration",
                on_click=enable_form,
                disabled=st.session_state.collector_running
            )

        if not st.session_state["disable_form"]:
            save_config = st.form_submit_button(label=":material/save: Save", type="primary")

            if save_config:
                if not realm or not ingest_token or not rum_token:
                    st.error("Realm, Ingest Token, and RUM Token are required.")
                    st.stop()

                st.session_state["disable_form"] = True

                sql_result = dm.save_collector_config(
                    realm, ingest_token, rum_token,
                    hec_url, hec_token, splunk_index, instance
                )

                st.toast(sql_result[0])
                time.sleep(1)
                st.rerun()

with col2:
    st.markdown("#### :blue[Collector Status]")

    # Fetch pods and update session state
    collector_pods = dm.get_collector_pods()
    st.session_state.collector_running = bool(collector_pods)

    # Status indicator and pods
    with st.container(border=True):
        if st.session_state.collector_running:
            st.markdown(":green[:material/check_circle:] **Collector is running**")
        else:
            st.markdown(":gray[:material/circle:] **Collector is not running**")
            if current["name"] == "None":
                st.info("Deploy a demo from the Use Cases page to start the collector.")

        if collector_pods:
            if render_pod_grid(collector_pods, "selected_pod", cols=3, truncate_len=18, show_status_color=False):
                st.rerun()

    # Logs section
    if st.session_state.collector_running and st.session_state.get("selected_pod"):
        with st.container(border=True, height=350):
            logs, code = dm.get_pod_logs(st.session_state.selected_pod)
            if code == 0:
                st.code(logs, language="log")
            else:
                st.error(logs)

        if st.button(":material/refresh: Refresh", help="Refresh logs"):
            st.rerun()

# Helm repo update on first load
if not st.session_state.helm_repo_updated:
    with st.spinner("Updating Helm repository..."):
        result, returncode = dm.update_helm_repo()
        if returncode == 0:
            st.session_state.helm_repo_updated = True
            st.toast("Helm repository updated!")
        else:
            st.toast(f"Helm update failed: {result}")

debug_panel()
