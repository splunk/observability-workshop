#!/bin/bash -x
cd /home/splunk/demo-in-a-box/v3
echo $PWD
activate () {
    . $PWD/venv/bin/activate
}
activate
nohup streamlit run manager-ui.py --server.port=8083
