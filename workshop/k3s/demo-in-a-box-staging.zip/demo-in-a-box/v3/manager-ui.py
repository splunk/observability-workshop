import time

import streamlit as st  # type: ignore
from lib import splunk as demo  # type: ignore

st.set_page_config(
    page_title=f"Demo-in-a-Box",
    page_icon=":material/box:",
    layout="wide",
    #initial_sidebar_state="auto",
    menu_items={"About": f"**Demo in a Box - Version {demo.VERSION}**"},
)

if "helm_repo_initialized" not in st.session_state:
    st.session_state.helm_repo_initialized = True

if "helm_repo_updated" not in st.session_state:
    st.session_state.helm_repo_updated = False

#demo.page_header("Manage OpenTelemetry Collector")

dm = demo.DemoManager()

# with open( "app/style.css" ) as css:
#    st.markdown( f'<style>{css.read()}</style>' , unsafe_allow_html= True)

st.image("images/splunk-logo-white.png", width=130)
st.caption(demo.CAPTION)

available_demos = dm.available_demos()
current_demo = dm.current_demo()
config = dm.get_collector_config()

status_updates = st.container()

def deploy_demo(name, deployment, custom_values, otel_version):
    status_updates.empty()

    with status_updates.status(
        f"Deploying `{name}` demo...", expanded=True
    ) as status:
        #st.write(f"Deployment: {deployment}")
        #st.write(f"Current Demo Name: {current_demo['name']}")
        #st.write(f"Current Demo Deployment: {current_demo['deployment']}")
        if name != current_demo["name"] and current_demo["name"] != "None":
            status.update(label=f"Deleting `{current_demo['name']}` deployment...")
            delete, returncode = dm.delete_demo(current_demo["deployment"])
            time.sleep(5)
            if returncode != 1:
                status.code(delete)
        status.update(label=f"Stopping OpenTelemetry Collector...")
        stop_collector, returncode = dm.stop_collector()
        time.sleep(5)
        status.code(stop_collector)
        status.update(label=f"Patching Kubernetes secrets...")
        secret = dm.patch_deployment_secrets(config["instance"], name)
        time.sleep(2)
        status.code(secret[0])
        dm.update_current_demo(name, deployment)
        status.update(label=f"Starting OpenTelemetry Collector...")
        start_collector = dm.start_collector(custom_values, otel_version)
        status.code(start_collector[0])
        status.update(label=f"Waiting for OpenTelemetry Collector to be ready...")
        wait_result = dm.wait_for_collector_ready()
        status.code(wait_result[0])
        if wait_result[1] != 0:
            status.update(label=f"Failed to start OpenTelemetry Collector!", state="error")
            return
        status.update(label=f"Deploying `{name}` demonstration...")
        deploy = dm.deploy_demo(name, deployment)
        time.sleep(5)
        status.code(deploy[0])
        status.update(label=f"Deployed `{name}` demonstration!", state="complete", expanded=False)


def stop_demo(name, deployment):
    status_updates.empty()

    with status_updates.status(
        f"Stopping `{name}` demo...", expanded=True
    ) as status:
        status.update(label="`helm delete` OpenTelemetry Collector")
        stop_collector, returncode = dm.stop_collector()
        time.sleep(2)
        status.code(stop_collector)
        status.update(label=f"Deleting `{deployment}` deployment...")
        delete, returncode = dm.delete_demo(deployment)
        time.sleep(2)
        status.code(delete)
        dm.update_current_demo("None", "None")
        time.sleep(5)
        status.update(label=f"Deleted `{name}` demonstration!", state="complete", expanded=False)

def main():
    demo_placeholder = st.empty()

    with demo_placeholder.container():
        # Create grid layout with proper spacing
        n_cols = 4
        demos_per_row = n_cols
        demo_rows = [available_demos[i:i + demos_per_row] for i in range(0, len(available_demos), demos_per_row)]

        for demo_row in demo_rows:
            cols = st.columns(n_cols, gap="medium")

            for idx, demo in enumerate(demo_row):
                if demo["name"] != "None":
                    environment = f"{config['instance']}-{demo['name']}"

                with cols[idx]:
                    # Custom styled card with button inside
                    with st.container(border=True):
                        # Title with running indicator
                        if current_demo["name"] == demo["name"]:
                            st.markdown(f"##### :green[:material/play_arrow:] :blue[{demo['use-case']}]")
                        else:
                            st.markdown(f"##### :blue[{demo['use-case']}]")

                        # Environment
                        st.markdown("**Deployment Environment**")
                        st.code(f"{environment}", language="text")
                        
                        # OTel Collector Version
                        st.markdown("**OpenTelemetry Collector Version**")
                        st.code(f"{demo['otel_version']}", language="text")

                        # Description
                        with st.expander("**Description**", expanded=False):
                            # Replace newlines with proper markdown line breaks
                            description_with_breaks = demo['description'].replace('\n', '  \n')
                            st.markdown(description_with_breaks)

                        # Deploy/Stop button at bottom
                        if current_demo["name"] == demo["name"]:
                            st.button(
                                ":material/stop_circle: Stop",
                                key=demo["use-case"],
                                type="primary",
                                width="content",
                                on_click=stop_demo,
                                args=(demo["name"], demo["deployment"])
                            )
                        else:
                            st.button(
                                ":material/play_circle: Deploy",
                                key=demo["use-case"],
                                type="primary",
                                width="content",
                                on_click=deploy_demo,
                                args=(demo["name"], demo["deployment"], demo["custom-values"], demo["otel_version"]),
                                help=f"Deploy the **:blue[{demo['use-case']}]** demonstration. The environment in Observability Cloud will be named **:violet[{environment}]**."
                            )

    if st.secrets.debug:
        st.json(st.session_state)

pages = {
    "Splunk - Demo in a Box": [
    st.Page(main, title="Use Cases", icon=":material/box:"),
    ],
    "OpenTelemetry Collector": [
    st.Page("pages/collector.py", title="Collector Configuration/Status/Logs", icon=":material/docs:"),
    ],
    "Kubernetes": [
    st.Page("pages/status.py", title="Pod Status/Logs", icon=":material/docs:"),
    ],
    "Chaos Engineering": [
    st.Page("pages/chaos.py", title="Chaos Experiments", icon=":material/grid_4x4:"),
    ]
}
pg = st.navigation(pages, position='top')
pg.run()