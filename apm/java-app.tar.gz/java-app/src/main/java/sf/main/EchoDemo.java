package sf.main;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.eclipse.jetty.server.Request;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.handler.AbstractHandler;
import org.eclipse.jetty.util.log.Log;
import org.eclipse.jetty.util.log.Logger;

public class EchoDemo {

    private static final Logger logger = Log.getLog();

    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            System.err.println("usage: EchoDemo <port>");
            System.exit(1);
        }

        new EchoServer(Integer.valueOf(args[0])).start();
    }

    /**
     * Echo server.
     *
     * An HTTP server that responds to POST requests to /echo by replying with the same content that
     * was POST-ed to it.
     */
    private static class EchoServer extends AbstractHandler {

        private EchoServer(int port) throws Exception {
            Server server = new Server(port);
            server.setHandler(this);
            server.start();
            if (!server.isFailed()) {
                server.join();
            }
        }

        @Override
        public void handle(String target, Request baseRequest, HttpServletRequest request,
                           HttpServletResponse response) throws IOException {
            if (!"POST".equals(request.getMethod())) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                baseRequest.setHandled(true);
                return;
            }

            if (!"/echo".equals(request.getRequestURI())) {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                baseRequest.setHandled(true);
                return;
            }

            String message = IOUtils.toString(request.getInputStream(), request.getCharacterEncoding());
            logger.info("< {}", message);
            respond(response, message);
            baseRequest.setHandled(true);
        }

        private void respond(HttpServletResponse response, String message) throws IOException {
            try (PrintWriter writer = new PrintWriter(response.getOutputStream())) {
                writer.printf("You said: %s", message);
            }

            response.setContentType("text/plain");
            response.setStatus(HttpServletResponse.SC_OK);
        }
    }
}
